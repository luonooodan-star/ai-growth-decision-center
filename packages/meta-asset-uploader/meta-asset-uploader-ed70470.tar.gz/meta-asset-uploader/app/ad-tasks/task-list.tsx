"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { adTaskProgress } from "../../lib/ad-task-progress";
import { AdPublishTask, sortAdTasks } from "./task-store";
import { readJsonResponse } from "../client-response";
import "./ad-tasks.css";
import "./task-groups.css";

const statusLabels: Record<AdPublishTask["status"], string> = {
  queued: "排队中", running: "发布中", interrupted: "已中断", cancelled: "已取消", complete: "已完成", failed: "失败",
};

const groups: { key: string; number: string; title: string; statuses: AdPublishTask["status"][]; empty: string }[] = [
  { key: "active", number: "01", title: "进行中与排队中", statuses: ["running", "queued"], empty: "当前没有进行中或等待中的广告任务。" },
  { key: "complete", number: "02", title: "已成功", statuses: ["complete"], empty: "当前还没有成功完成的广告任务。" },
  { key: "stopped", number: "03", title: "失败与已取消", statuses: ["failed", "interrupted", "cancelled"], empty: "当前没有失败、已中断或已取消的广告任务。" },
];

export function AdTaskList() {
  const [tasks, setTasks] = useState<AdPublishTask[]>([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    let stopped = false;
    const refresh = async () => {
      try {
        const response = await fetch("/api/meta/ad-tasks", { cache: "no-store" });
        const payload = await readJsonResponse<{ tasks?: AdPublishTask[]; error?: string }>(response, "读取广告任务失败");
        if (!response.ok) throw new Error(payload.error || "读取广告任务失败");
        if (!stopped) { setTasks(sortAdTasks(payload.tasks || [])); setMessage(""); }
      } catch (error) {
        if (!stopped) setMessage(error instanceof Error ? error.message : "读取广告任务失败");
      }
    };
    const run = async () => {
      await Promise.allSettled([0, 1, 2].map(() => fetch("/api/meta/ad-tasks/process", { method: "POST" })));
      await refresh();
    };
    void run();
    const interval = window.setInterval(() => void run(), 2500);
    return () => { stopped = true; window.clearInterval(interval); };
  }, []);

  async function taskAction(id: string, action: "cancel" | "interrupt" | "prioritize" | "retry" | "copy") {
    setMessage("");
    const response = await fetch("/api/meta/ad-tasks", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, action }) });
    const payload = await readJsonResponse<{ task?: AdPublishTask; error?: string }>(response, "任务操作失败");
    if (!response.ok || !payload.task) return setMessage(payload.error || "任务操作失败");
    setTasks((current) => action === "copy"
      ? sortAdTasks([payload.task!, ...current])
      : sortAdTasks(current.map((task) => task.id === id ? payload.task! : task)));
    if (action === "copy") setMessage("已复制为新的排队任务。");
  }

  return <main className="ad-shell">
    <TaskNavigation active="tasks" />
    <section className="ad-hero compact-hero task-library-hero"><div><p className="eyebrow">AD PUBLISH QUEUE</p><h1>广告发布，<br /><em>任务队列。</em></h1><p>按执行状态分组查看任务；进度包含 Campaign、Ad Set 和 Ad 三个层级，最多同时执行 3 条任务。</p></div><Link className="new-config-button" href="/ad-tasks/new">+ 新建广告任务</Link></section>
    {message && <p className="task-form-message task-list-message">{message}</p>}
    <div className="ad-task-groups">
      {groups.map((group) => {
        const grouped = tasks.filter((task) => group.statuses.includes(task.status)).sort((left, right) => group.key === "active" && left.status !== right.status ? (left.status === "running" ? -1 : 1) : 0);
        return <section className={`ad-task-library ad-task-group ${group.key}`} key={group.key}>
          <div className="panel-head"><div className="step-label"><span>{group.number}</span>{group.title}</div><span>{grouped.length} 个任务</span></div>
          {grouped.length ? <div className="ad-publish-task-list">{grouped.map((task) => <AdTaskCard task={task} onAction={taskAction} key={task.id} />)}</div> : <div className="empty-results">{group.empty}</div>}
        </section>;
      })}
    </div>
  </main>;
}

function AdTaskCard({ task, onAction }: { task: AdPublishTask; onAction: (id: string, action: "cancel" | "interrupt" | "prioritize" | "retry" | "copy") => Promise<void> }) {
  const progress = adTaskProgress(task);
  return <article className="ad-publish-task">
    <div className="ad-task-main"><div className="ad-task-title"><code>{task.id.slice(0, 8)}</code><div><strong>{task.configName}</strong><span>{new Date(task.createdAt).toLocaleString("zh-CN", { hour12: false })}</span></div></div><b className={`ad-task-state ${task.status}`}>{statusLabels[task.status]}</b></div>
    <div className="ad-task-facts"><span><b>{task.accountIds.length}</b> 个账户</span><span><b>{task.materials.length}</b> 条账户素材关系</span><span><b>{task.campaignCount}-{task.adSetsPerCampaign}-{task.adsPerAdSet}</b> 创建结构</span><span title={task.adSetName}>广告组：<b>{task.adSetName}</b></span><span><b>{task.pageStrategies?.reduce((total, strategy) => total + strategy.pageIds.length, 0) || 0}</b> 条粉丝页路由</span><span><b>{task.result?.completedAds || 0}/{task.result?.totalAds || task.materials.length}</b> 个广告完成</span></div>
    <div className="ad-task-progress-head"><span>创建进度 · Campaign + Ad Set + Ad</span><b>{progress.completed}/{progress.total}</b></div>
    <div className="ad-task-progress" role="progressbar" aria-label="广告任务创建进度" aria-valuemin={0} aria-valuemax={progress.total} aria-valuenow={progress.completed}><i style={{ width: `${progress.percent}%` }} /></div>
    <div className="ad-task-progress-detail"><span>{progress.campaigns} 个 Campaign</span><span>{progress.adSets} 个 Ad Set</span><span>{progress.ads} 个 Ad</span><b>{progress.percent}%</b></div>
    <div className="ad-task-meta"><span title={task.accountNames.join("、")}>{task.accountNames.join("、")}</span>{task.sourceFolders.length > 0 && <span title={task.sourceFolders.join("、")}>来源文件夹：{task.sourceFolders.join("、")}</span>}</div>
    {task.error && <p className="task-form-message">{task.error}</p>}
    {(task.status !== "complete") && <div className="ad-task-controls">
      {task.status === "running" && <button type="button" className="danger" onClick={() => void onAction(task.id, "interrupt")}>中断</button>}
      {task.status === "queued" && <><button type="button" onClick={() => void onAction(task.id, "cancel")}>取消排队</button><button type="button" onClick={() => void onAction(task.id, "prioritize")}>插队</button></>}
      {(task.status === "failed" || task.status === "interrupted") && <button type="button" onClick={() => void onAction(task.id, "retry")}>重试失败项</button>}
      {task.status === "cancelled" && <button type="button" onClick={() => void onAction(task.id, "copy")}>复制为新任务</button>}
    </div>}
    {task.status === "complete" && <div className="ad-task-controls"><Link href={`/ad-tasks/new?copy=${task.id}`}>复制并重新配置</Link></div>}
  </article>;
}

export function TaskNavigation({ active }: { active: "assets" | "apps" | "configs" | "pages" | "audiences" | "tasks" }) {
  return <header className="topbar"><div className="brand"><span className="brand-mark">M</span><span>Meta Creative Vault</span></div><nav className="top-nav"><Link className={active === "assets" ? "active" : ""} href="/">素材库</Link><Link className={active === "apps" ? "active" : ""} href="/app-configs">应用配置</Link><Link className={active === "configs" ? "active" : ""} href="/ad-upload">广告配置模版</Link><Link className={active === "pages" ? "active" : ""} href="/page-configs">粉丝页配置</Link><Link className={active === "audiences" ? "active" : ""} href="/audiences">受众生成库</Link><Link className={active === "tasks" ? "active" : ""} href="/ad-tasks">广告发布任务</Link></nav></header>;
}
