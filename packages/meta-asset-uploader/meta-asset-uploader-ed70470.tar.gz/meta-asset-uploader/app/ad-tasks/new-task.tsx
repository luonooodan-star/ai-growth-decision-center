"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { TaskNavigation } from "./task-list";
import { AdPublishTask } from "./task-store";
import type { AudienceResult, AudienceTask } from "../audiences/audience-store";
import { HistoricalMaterial, readHistoricalMaterials } from "./upload-history";
import { buildAccountPageStrategies } from "../page-configs/page-config-store";
import { readJsonResponse } from "../client-response";
import { plannedAdTaskSteps } from "../../lib/ad-task-progress";
import "./ad-tasks.css";

type Account = { id: string; name: string };
type Template = { id: string; name: string; objective: "app" | "sales"; config: Record<string, string | string[]> };
const TEMPLATE_STORAGE_KEY = "meta-creative-vault-ad-templates-v2";

export function NewAdTask() {
  const router = useRouter();
  const params = useSearchParams();
  const copyId = params.get("copy") || "";
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [materials, setMaterials] = useState<HistoricalMaterial[]>([]);
  const [selectedAccountIds, setSelectedAccountIds] = useState<string[]>([]);
  const [accountSearch, setAccountSearch] = useState("");
  const [materialMode, setMaterialMode] = useState<"name" | "folder">("name");
  const [materialSearch, setMaterialSearch] = useState("");
  const [selectedVideoKeys, setSelectedVideoKeys] = useState<string[]>([]);
  const [folderSearch, setFolderSearch] = useState("");
  const [selectedFolders, setSelectedFolders] = useState<string[]>([]);
  const [configId, setConfigId] = useState(params.get("config") || "");
  const [configSearch, setConfigSearch] = useState("");
  const [campaignCount, setCampaignCount] = useState(1);
  const [adSetsPerCampaign, setAdSetsPerCampaign] = useState(1);
  const [adsPerAdSet, setAdsPerAdSet] = useState(1);
  const [adSetName, setAdSetName] = useState(todayName());
  const [adSetNameTouched, setAdSetNameTouched] = useState(false);
  const [creationStatus, setCreationStatus] = useState<"PAUSED" | "ACTIVE">("PAUSED");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [audiences, setAudiences] = useState<AudienceResult[]>([]);
  const [audienceSearch, setAudienceSearch] = useState("");
  const [includedAudienceKeys, setIncludedAudienceKeys] = useState<string[]>([]);
  const [excludedAudienceKeys, setExcludedAudienceKeys] = useState<string[]>([]);

  useEffect(() => {
    void Promise.resolve().then(() => {
      try { setTemplates(JSON.parse(localStorage.getItem(TEMPLATE_STORAGE_KEY) || "[]") as Template[]); } catch { setTemplates([]); }
    });
    void Promise.all([fetch("/api/meta/assets", { cache: "no-store" }).then(async (response) => {
      const payload = await readJsonResponse<{ accounts?: Account[]; error?: string }>(response, "读取广告账户失败");
      if (!response.ok) throw new Error(payload.error || "读取广告账户失败");
      setAccounts(payload.accounts || []);
    }), readHistoricalMaterials().then((history) => setMaterials((current) => [...new Map([...current, ...history].map((material) => [material.key, material])).values()]))]).catch((error) => setMessage(error instanceof Error ? error.message : "读取任务选项失败")).finally(() => setLoading(false));
    void fetch("/api/meta/audience-tasks", { cache: "no-store" }).then(async (response) => { const payload = await readJsonResponse<{ tasks?: AudienceTask[]; error?: string }>(response, "读取受众历史失败"); if (!response.ok) throw new Error(payload.error || "读取受众历史失败"); setAudiences((payload.tasks || []).flatMap((task) => task.results || []).filter((item) => item.status === "success")); }).catch((error) => setMessage(error instanceof Error ? error.message : "读取受众历史失败"));
  }, []);

  useEffect(() => {
    if (!copyId) return;
    let stopped = false;
    void fetch(`/api/meta/ad-tasks?id=${encodeURIComponent(copyId)}`, { cache: "no-store" }).then(async (response) => {
      const payload = await readJsonResponse<{ task?: AdPublishTask; error?: string }>(response, "读取原广告任务失败");
      if (!response.ok || !payload.task) throw new Error(payload.error || "读取原广告任务失败");
      if (payload.task.status !== "complete") throw new Error("只有成功完成的广告任务可以进入重新配置页面");
      if (stopped) return;
      const source = payload.task;
      setTemplates((current) => current.some((template) => template.id === source.template.id) ? current : [source.template, ...current]);
      setConfigId(source.template.id);
      setSelectedAccountIds(source.accountIds);
      setMaterialMode(source.materialMode);
      setCampaignCount(source.campaignCount);
      setAdSetsPerCampaign(source.adSetsPerCampaign);
      setAdsPerAdSet(source.adsPerAdSet);
      setAdSetName(source.adSetName);
      setAdSetNameTouched(true);
      setCreationStatus(source.creationStatus);
      setSelectedVideoKeys(source.materials.map((material) => `${material.accountId}\u0000${material.mediaType}\u0000${material.mediaId}`));
      setSelectedFolders(source.sourceFolders || []);
      setIncludedAudienceKeys((source.includedAudiences || []).map((item) => `${item.accountId}:${item.audienceId}`));
      setExcludedAudienceKeys((source.excludedAudiences || []).map((item) => `${item.accountId}:${item.audienceId}`));
      setMaterials((current) => {
        const copied = source.materials.map((material): HistoricalMaterial => ({
          key: `${material.accountId}\u0000${material.mediaType}\u0000${material.mediaId}`,
          accountId: material.accountId,
          filename: material.filename,
          mediaType: material.mediaType,
          mediaId: material.mediaId,
          videoId: material.videoId,
          imageHash: material.imageHash,
          thumbnailUrl: material.thumbnailUrl,
          sourceFolder: material.sourceFolder,
          relativePath: material.filename,
          completedAt: source.createdAt,
        }));
        return [...new Map([...copied, ...current].map((material) => [material.key, material])).values()];
      });
      setMessage("已载入成功任务，可修改配置后创建新的广告发布任务。");
    }).catch((error) => { if (!stopped) setMessage(error instanceof Error ? error.message : "读取原广告任务失败"); });
    return () => { stopped = true; };
  }, [copyId]);

  const selectedAccounts = useMemo(() => accounts.filter((account) => selectedAccountIds.includes(account.id)), [accounts, selectedAccountIds]);
  const selectedTemplate = useMemo(() => templates.find((template) => template.id === configId), [configId, templates]);
  const templateMatches = useMemo(() => {
    const query = configSearch.trim().toLowerCase();
    if (!query) return [];
    return templates.filter((template) => {
      const type = readTemplateValue(template.config.template_type) === "ios14" ? "ios 14+ skadnetwork" : template.objective === "app" ? "应用安装 app" : "销量 sales";
      return template.name.toLowerCase().includes(query) || template.id.toLowerCase().includes(query) || type.includes(query);
    }).slice(0, 12);
  }, [configSearch, templates]);
  const accountMatches = useMemo(() => {
    const query = accountSearch.trim().toLowerCase();
    if (!query) return [];
    return accounts.filter((account) => account.name.toLowerCase().includes(query) || account.id.includes(query)).slice(0, 12);
  }, [accounts, accountSearch]);
  const eligibleMaterials = useMemo(() => materials.filter((material) => selectedAccountIds.includes(material.accountId)), [materials, selectedAccountIds]);
  const materialMatches = useMemo(() => {
    const query = materialSearch.trim().toLowerCase();
    if (!query) return [];
    return eligibleMaterials.filter((material) => material.filename.toLowerCase().includes(query) || material.mediaId.includes(query) || material.relativePath.toLowerCase().includes(query)).slice(0, 30);
  }, [eligibleMaterials, materialSearch]);
  const folders = useMemo(() => [...new Set(eligibleMaterials.map((material) => material.sourceFolder))].sort((a, b) => a.localeCompare(b, "zh-CN")), [eligibleMaterials]);
  const folderMatches = useMemo(() => {
    const query = folderSearch.trim().toLowerCase();
    return folders.filter((folder) => !query || folder.toLowerCase().includes(query)).slice(0, 30);
  }, [folders, folderSearch]);
  const selectedMaterials = useMemo(() => materialMode === "name"
    ? eligibleMaterials.filter((material) => selectedVideoKeys.includes(material.key))
    : eligibleMaterials.filter((material) => selectedFolders.includes(material.sourceFolder)), [eligibleMaterials, materialMode, selectedFolders, selectedVideoKeys]);
  const baseCapacity = campaignCount * adSetsPerCampaign * adsPerAdSet;
  const projectedSteps = plannedAdTaskSteps({ accountIds: selectedAccountIds, materials: selectedMaterials, adSetsPerCampaign, adsPerAdSet });
  const eligibleAudiences = useMemo(() => audiences.filter((audience) => selectedAccountIds.includes(audience.accountId)), [audiences, selectedAccountIds]);
  const audienceMatches = useMemo(() => { const query = audienceSearch.trim().toLowerCase(); return eligibleAudiences.filter((item) => !query || item.audienceName.toLowerCase().includes(query) || item.audienceId.includes(query)).slice(0, 50); }, [audienceSearch, eligibleAudiences]);
  const audienceKey = (item: AudienceResult) => `${item.accountId}:${item.audienceId}`;

  function toggleAudience(item: AudienceResult, mode: "include" | "exclude") {
    const key = audienceKey(item);
    if (mode === "include") { setIncludedAudienceKeys((current) => current.includes(key) ? current.filter((value) => value !== key) : [...current, key]); setExcludedAudienceKeys((current) => current.filter((value) => value !== key)); }
    else { setExcludedAudienceKeys((current) => current.includes(key) ? current.filter((value) => value !== key) : [...current, key]); setIncludedAudienceKeys((current) => current.filter((value) => value !== key)); }
  }

  function toggleAccount(id: string) {
    setSelectedAccountIds((current) => current.includes(id) ? current.filter((value) => value !== id) : [...current, id]);
  }

  function toggleVideo(key: string) {
    setSelectedVideoKeys((current) => current.includes(key) ? current.filter((value) => value !== key) : [...current, key]);
  }

  function toggleFolder(folder: string) {
    const next = selectedFolders.includes(folder) ? selectedFolders.filter((value) => value !== folder) : [...selectedFolders, folder];
    setSelectedFolders(next);
    if (!adSetNameTouched) setAdSetName(next.length ? next.map(folderToAdSetName).join("_") : todayName());
  }

  function chooseMaterialMode(mode: "name" | "folder") {
    setMaterialMode(mode);
    if (!adSetNameTouched) setAdSetName(mode === "folder" && selectedFolders.length ? selectedFolders.map(folderToAdSetName).join("_") : todayName());
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const template = templates.find((item) => item.id === configId);
    if (!template) return setMessage("请选择一个广告配置模版。");
    if (selectedAccountIds.length === 0) return setMessage("请至少选择一个广告账户。");
    if (selectedMaterials.length === 0) return setMessage("请选择至少一个已成功上传的视频或图片素材。");
    const accountIdsWithMaterial = new Set(selectedMaterials.map((material) => material.accountId));
    const missing = selectedAccounts.filter((account) => !accountIdsWithMaterial.has(account.id));
    if (missing.length > 0) return setMessage(`以下账户没有选中对应素材：${missing.map((account) => account.name).join("、")}`);
    const pageStrategies = buildAccountPageStrategies(selectedAccountIds);
    const accountsWithoutPage = selectedAccounts.filter((account) => !pageStrategies.find((strategy) => strategy.accountId === account.id)?.pageIds.length);
    if (accountsWithoutPage.length > 0) return setMessage(`以下账户没有启用的粉丝页配置：${accountsWithoutPage.map((account) => account.name).join("、")}`);
    if (![campaignCount, adSetsPerCampaign, adsPerAdSet].every((value) => Number.isInteger(value) && value >= 1 && value <= 100)) return setMessage("广告结构数字必须是 1–100 的整数。");
    const normalizedName = (materialMode === "folder" ? selectedFolders.map(folderToAdSetName).join("_") : adSetName).trim();
    if (!normalizedName) return setMessage("请填写广告组名称。");
    if (normalizedName.length > 255) return setMessage("广告组名称不能超过 255 个字符。");

    const now = Date.now();
    const pageIndexes = new Map<string, number>();
    const task: AdPublishTask = {
      id: crypto.randomUUID(), createdAt: now, updatedAt: now, priority: 0, status: "queued",
      configId: template.id, configName: template.name,
      template,
      accountIds: selectedAccountIds, accountNames: selectedAccountIds.map((id) => accounts.find((account) => account.id === id)?.name || `act_${id}`),
      materialMode, materials: selectedMaterials.map((material) => { const strategy = pageStrategies.find((item) => item.accountId === material.accountId)!; const index = pageIndexes.get(material.accountId) || 0; pageIndexes.set(material.accountId, index + 1); return { accountId: material.accountId, filename: material.filename, mediaType: material.mediaType, mediaId: material.mediaId, videoId: material.videoId, imageHash: material.imageHash, thumbnailUrl: material.thumbnailUrl, adName: material.filename, sourceFolder: material.sourceFolder, pageCandidateIds: strategy.pageIds, assignedPageId: strategy.pageIds[index % strategy.pageIds.length] }; }),
      sourceFolders: materialMode === "folder" ? selectedFolders : [...new Set(selectedMaterials.map((material) => material.sourceFolder))],
      pageStrategies,
      campaignCount, adSetsPerCampaign, adsPerAdSet, adSetName: normalizedName, creationStatus,
      includedAudiences: eligibleAudiences.filter((item) => includedAudienceKeys.includes(audienceKey(item))).map((item) => ({ accountId: item.accountId, audienceId: item.audienceId, audienceName: item.audienceName })),
      excludedAudiences: eligibleAudiences.filter((item) => excludedAudienceKeys.includes(audienceKey(item))).map((item) => ({ accountId: item.accountId, audienceId: item.audienceId, audienceName: item.audienceName })),
    };
    setMessage("正在提交后台任务…");
    try {
      const response = await fetch("/api/meta/ad-tasks", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(task) });
      const payload = await readJsonResponse<{ error?: string }>(response, "广告任务提交失败");
      if (!response.ok) throw new Error(payload.error || "广告任务提交失败");
      router.push("/ad-tasks");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "广告任务提交失败");
    }
  }

  const projectedAds = selectedMaterials.length;

  return <main className="ad-shell">
    <TaskNavigation active="tasks" />
    <section className="ad-hero compact-hero task-library-hero"><div><p className="eyebrow">NEW AD PUBLISH TASK</p><h1>新建广告，<br /><em>发布任务。</em></h1><p>从素材库成功记录中选择账户素材关系，再定义 Campaign → Ad Set → Ad 的创建数量。</p></div><Link className="back-to-library" href="/ad-tasks">返回任务列表</Link></section>
    <form className="new-ad-task-form" onSubmit={submit}>
      <section className="ad-card task-form-card"><div className="card-kicker">01 · 配置与账户</div><h2>选择投放目标</h2><div className="task-form-grid"><label>搜索广告配置模版<input value={configSearch} onChange={(event) => setConfigSearch(event.target.value)} placeholder="输入配置名称、ID、iOS 14+ 或营销目标" /></label><label>筛选广告账户<input value={accountSearch} onChange={(event) => setAccountSearch(event.target.value)} placeholder="输入账户名称或 Account ID" disabled={loading} /></label></div>
        {configSearch.trim() && <div className="task-search-results">{templateMatches.length ? templateMatches.map((template) => { const type = readTemplateValue(template.config.template_type) === "ios14" ? "iOS 14+" : template.objective === "app" ? "应用安装" : "销量"; return <label key={template.id} title={template.name}><input type="radio" name="selected_template" checked={configId === template.id} onChange={() => { setConfigId(template.id); setConfigSearch(""); }} /><span><b>{template.name}</b><small>{type} · {template.id.slice(0, 8)}</small></span></label>; }) : <p>未找到匹配的广告配置</p>}</div>}
        {selectedTemplate && <div className="task-selected-chips"><button type="button" onClick={() => setConfigId("")} title={selectedTemplate.name}>{selectedTemplate.name} · {readTemplateValue(selectedTemplate.config.template_type) === "ios14" ? "iOS 14+" : selectedTemplate.objective === "app" ? "应用安装" : "销量"}<i>×</i></button></div>}
        {accountSearch.trim() && <div className="task-search-results">{accountMatches.length ? accountMatches.map((account) => <label key={account.id} title={account.name} aria-label={`${account.name} act_${account.id}`}><input type="checkbox" checked={selectedAccountIds.includes(account.id)} onChange={() => toggleAccount(account.id)} /><span><b>{account.name}</b><small>act_{account.id}</small></span></label>) : <p>未找到匹配账户</p>}</div>}
        {selectedAccounts.length > 0 && <><div className="task-selected-chips">{selectedAccounts.map((account) => <button type="button" key={account.id} onClick={() => toggleAccount(account.id)} title={account.name}>{account.name} · act_{account.id}<i>×</i></button>)}</div><p className="field-note">支持多选。创建任务时会查询“粉丝页配置”，并为每个账户轮换分配其已启用的粉丝页。</p></>}
      </section>

      <section className="ad-card task-form-card"><div className="card-kicker">02 · 受众（可选）</div><h2>选择或排除账户受众</h2><label>搜索受众名称或 Audience ID<input value={audienceSearch} onChange={(event) => setAudienceSearch(event.target.value)} placeholder="只显示已选广告账户名下的受众生成历史" /></label><p className="field-note"><b>使用方式：</b>在每条受众右侧勾选“包含”或“排除”。同一受众两项互斥，切换勾选时系统会自动取消另一项；再次点击已勾选项可取消使用。受众按广告账户严格分组，多个账户不会互相串用。</p><div className="audience-pick-table"><table><thead><tr><th>受众</th><th>所属广告账户</th><th>包含该受众</th><th>排除该受众</th></tr></thead><tbody>{audienceMatches.length ? audienceMatches.map((item) => { const key = audienceKey(item); return <tr key={key}><td><b>{item.audienceName}</b><small>{item.audienceId}</small></td><td>{item.accountName}<small>act_{item.accountId}</small></td><td><label className="audience-choice"><input type="checkbox" checked={includedAudienceKeys.includes(key)} onChange={() => toggleAudience(item, "include")} /><span>包含</span></label></td><td><label className="audience-choice exclude"><input type="checkbox" checked={excludedAudienceKeys.includes(key)} onChange={() => toggleAudience(item, "exclude")} /><span>排除</span></label></td></tr>; }) : <tr><td colSpan={4}>所选账户暂无匹配的受众创建历史</td></tr>}</tbody></table></div><div className="audience-selection-summary"><span>已包含 <b>{includedAudienceKeys.filter((key) => eligibleAudiences.some((item) => audienceKey(item) === key)).length}</b> 条</span><span>已排除 <b>{excludedAudienceKeys.filter((key) => eligibleAudiences.some((item) => audienceKey(item) === key)).length}</b> 条</span></div></section>

      <section className="ad-card task-form-card"><div className="card-kicker">03 · 素材</div><h2>选择账户素材</h2><div className="material-mode"><button type="button" className={materialMode === "name" ? "selected" : ""} onClick={() => chooseMaterialMode("name")}><b>方式 A</b><span>按素材名称搜索</span></button><button type="button" className={materialMode === "folder" ? "selected" : ""} onClick={() => chooseMaterialMode("folder")}><b>方式 B</b><span>按来源文件夹选择</span></button></div>
        {materialMode === "name" ? <><label>搜索素材名称或素材 ID<input value={materialSearch} onChange={(event) => setMaterialSearch(event.target.value)} placeholder="输入素材原文件名" /></label>{materialSearch.trim() && <MaterialResults materials={materialMatches} selected={selectedVideoKeys} accounts={accounts} onToggle={toggleVideo} />}</> : <><label>搜索来源文件夹<input value={folderSearch} onChange={(event) => setFolderSearch(event.target.value)} placeholder="输入来源文件夹名称" /></label><div className="folder-results">{folderMatches.length ? folderMatches.map((folder) => <label key={folder} aria-label={folder}><input type="checkbox" checked={selectedFolders.includes(folder)} onChange={() => toggleFolder(folder)} /><span><b>{folder}</b><small>{eligibleMaterials.filter((material) => material.sourceFolder === folder).length} 条账户素材关系</small></span></label>) : <p>当前所选账户没有匹配的来源文件夹</p>}</div></>}
        <div className="material-summary"><strong>已录入 {selectedMaterials.length} 条账户素材关系</strong><span>{new Set(selectedMaterials.map((material) => `${material.mediaType}:${material.mediaId}`)).size} 个不同素材 ID · 覆盖 {new Set(selectedMaterials.map((material) => material.accountId)).size} 个账户</span></div>
      </section>

      <section className="ad-card task-form-card"><div className="card-kicker">03 · 创建结构</div><h2>定义 Campaign 层级</h2><div className="structure-grid"><label>基础广告系列数量<input type="number" min="1" max="100" value={campaignCount} onChange={(event) => setCampaignCount(Number(event.target.value))} /></label><span>×</span><label>每系列广告组数量<input type="number" min="1" max="100" value={adSetsPerCampaign} onChange={(event) => setAdSetsPerCampaign(Number(event.target.value))} /></label><span>×</span><label>每广告组广告数量<input type="number" min="1" max="100" value={adsPerAdSet} onChange={(event) => setAdsPerAdSet(Number(event.target.value))} /></label></div><div className="structure-preview"><b>{campaignCount}-{adSetsPerCampaign}-{adsPerAdSet}</b><span>基础结构每账户可容纳 {baseCapacity} 个 Ad；素材超出时自动追加 Campaign，最后一个结构允许不足。当前 {projectedAds} 条账户素材关系预计创建 {projectedSteps.campaigns} 个 Campaign、{projectedSteps.adSets} 个 Ad Set、{projectedSteps.ads} 个 Ad，共 {projectedSteps.total} 个进度步骤。</span></div>{materialMode === "name" ? <label>广告组名称<input required maxLength={255} value={adSetName} onChange={(event) => { setAdSetNameTouched(true); setAdSetName(event.target.value); }} /><small>方式 A 默认使用创建日期，可手动修改。</small></label> : <div className="structure-preview"><b>广告组自动命名</b><span>{selectedFolders.length ? selectedFolders.map(folderToAdSetName).join("_") : "选择来源文件夹后自动生成"}。文件夹模式无需手动填写广告组名称。</span></div>}<div className="task-status-setting"><strong>广告发布状态</strong><span>默认暂停，可手动选择直接启用。</span><div className="material-mode"><button type="button" className={creationStatus === "PAUSED" ? "selected" : ""} onClick={() => setCreationStatus("PAUSED")}><b>暂停</b><span>PAUSED · 创建后不立即投放</span></button><button type="button" className={creationStatus === "ACTIVE" ? "selected" : ""} onClick={() => setCreationStatus("ACTIVE")}><b>启用</b><span>ACTIVE · 创建成功后直接投放</span></button></div></div><p className="field-note">每条广告的 <code>name</code> 默认使用对应视频或图片的原始文件名。模板中的全部正文和标题会同时应用到每一个素材创意。</p></section>

      <section className="ad-task-submit"><div><strong>以 {creationStatus} 状态创建任务</strong><span>{creationStatus === "PAUSED" ? "广告创建后保持暂停。" : "广告创建成功后将直接启用投放。"} 账户、素材、粉丝页路由和创建结构均会写入任务。</span></div><div><Link href="/ad-tasks">取消</Link><button type="submit">上传广告任务</button></div></section>
      {message && <p className="task-form-message">{message}</p>}
    </form>
  </main>;
}

function MaterialResults({ materials, selected, accounts, onToggle }: { materials: HistoricalMaterial[]; selected: string[]; accounts: Account[]; onToggle: (key: string) => void }) {
  const accountNames = new Map(accounts.map((account) => [account.id, account.name]));
  return <div className="material-results">{materials.length ? materials.map((material) => <label key={material.key} title={material.relativePath} aria-label={`${material.filename} 素材 ID ${material.mediaId}`}><input type="checkbox" checked={selected.includes(material.key)} onChange={() => onToggle(material.key)} /><span><b>{material.filename}</b><small>{accountNames.get(material.accountId) || `act_${material.accountId}`} · {material.mediaType === "video" ? "Video ID" : "Image Hash"} {material.mediaId} · {material.sourceFolder}</small></span></label>) : <p>未找到匹配的成功素材记录</p>}</div>;
}

function todayName() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function readTemplateValue(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] || "" : value || "";
}

function folderToAdSetName(folder: string) {
  if (!/[\u3400-\u9fff]/.test(folder)) return folder;
  const boundaries = [
    ["A", "阿"], ["B", "芭"], ["C", "擦"], ["D", "搭"], ["E", "蛾"], ["F", "发"], ["G", "噶"], ["H", "哈"],
    ["J", "击"], ["K", "喀"], ["L", "垃"], ["M", "妈"], ["N", "拿"], ["O", "哦"], ["P", "啪"], ["Q", "期"],
    ["R", "然"], ["S", "撒"], ["T", "塌"], ["W", "挖"], ["X", "昔"], ["Y", "压"], ["Z", "匝"],
  ] as const;
  return Array.from(folder).map((character) => {
    if (!/[\u3400-\u9fff]/.test(character)) return /[A-Za-z0-9_-]/.test(character) ? character : "";
    let initial = "";
    boundaries.forEach(([letter, boundary]) => { if (character.localeCompare(boundary, "zh-CN-u-co-pinyin") >= 0) initial = letter; });
    return initial;
  }).join("") || todayName();
}
