export type HistoricalMaterial = {
  key: string;
  accountId: string;
  filename: string;
  mediaType: "video" | "image";
  mediaId: string;
  videoId?: string;
  imageHash?: string;
  thumbnailUrl?: string;
  sourceFolder: string;
  relativePath: string;
  completedAt: number;
};

type StoredUploadResult = {
  filename?: string;
  type?: "image" | "video";
  media_id?: string;
  video_id?: string;
  picture_id?: string;
  image_hash?: string;
  thumbnail_url?: string;
  account_id?: string;
  source_folder?: string;
  relative_path?: string;
  completed_at?: number;
  upload_status?: "成功" | "失败";
};

type StoredUploadTask = { results?: StoredUploadResult[] };

const DATABASE_NAME = "meta-creative-vault";
const DATABASE_VERSION = 1;

function openUploadDatabase() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains("tasks")) request.result.createObjectStore("tasks", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function readHistoricalMaterials(): Promise<HistoricalMaterial[]> {
  const database = await openUploadDatabase();
  const tasks = await new Promise<StoredUploadTask[]>((resolve, reject) => {
    const request = database.transaction("tasks", "readonly").objectStore("tasks").getAll();
    request.onsuccess = () => resolve(request.result as StoredUploadTask[]);
    request.onerror = () => reject(request.error);
  }).finally(() => database.close());

  const materials = tasks.flatMap((task) => task.results || [])
    .filter((result) => result.upload_status === "成功" && (result.type === "video" || result.type === "image") && result.account_id && (result.video_id || result.image_hash || result.picture_id || result.media_id))
    .map((result) => {
      const accountId = String(result.account_id);
      const mediaType = result.type as "video" | "image";
      const mediaId = String(result.video_id || result.image_hash || result.picture_id || result.media_id);
      const filename = String(result.filename || mediaId);
      return {
        key: `${accountId}\u0000${mediaType}\u0000${mediaId}`,
        accountId,
        filename,
        mediaType,
        mediaId,
        ...(mediaType === "video" ? { videoId: mediaId } : { imageHash: mediaId }),
        ...(result.thumbnail_url ? { thumbnailUrl: String(result.thumbnail_url) } : {}),
        sourceFolder: String(result.source_folder || "单个素材"),
        relativePath: String(result.relative_path || filename),
        completedAt: Number(result.completed_at || 0),
      };
    });

  return [...new Map(materials.sort((a, b) => b.completedAt - a.completedAt).map((material) => [material.key, material])).values()];
}
