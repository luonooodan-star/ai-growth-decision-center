export type AdTaskStatus = "queued" | "running" | "interrupted" | "cancelled" | "complete" | "failed";

export type AdTaskMaterial = {
  accountId: string;
  filename: string;
  mediaType: "video" | "image";
  mediaId: string;
  videoId?: string;
  imageHash?: string;
  thumbnailUrl?: string;
  adName: string;
  sourceFolder: string;
  pageCandidateIds: string[];
  assignedPageId: string;
};

export type AdTaskPageStrategy = { accountId: string; pageIds: string[]; pageNames: string[] };
export type AdTaskAudience = { accountId: string; audienceId: string; audienceName: string };

export type AdPublishTask = {
  id: string;
  createdAt: number;
  updatedAt: number;
  priority: number;
  status: AdTaskStatus;
  configId: string;
  configName: string;
  template: { id: string; name: string; objective: "app" | "sales"; config: Record<string, string | string[]> };
  accountIds: string[];
  accountNames: string[];
  materialMode: "name" | "folder";
  materials: AdTaskMaterial[];
  sourceFolders: string[];
  pageStrategies: AdTaskPageStrategy[];
  campaignCount: number;
  adSetsPerCampaign: number;
  adsPerAdSet: number;
  adSetName: string;
  creationStatus: "PAUSED" | "ACTIVE";
  includedAudiences?: AdTaskAudience[];
  excludedAudiences?: AdTaskAudience[];
  result?: {
    campaignIds: string[];
    adSetIds: string[];
    creativeIds: string[];
    adIds: string[];
    completedAds: number;
    totalAds: number;
    completedMaterialKeys: string[];
    logs: string[];
  };
  progressAttempt?: {
    baselineCampaigns: number;
    baselineAdSets: number;
    baselineAds: number;
    campaigns: number;
    adSets: number;
    ads: number;
    total: number;
  };
  error?: string;
};

export const AD_TASK_STORAGE_KEY = "meta-creative-vault-ad-publish-tasks-v1";

export function readAdTasks(): AdPublishTask[] {
  try {
    const stored = JSON.parse(localStorage.getItem(AD_TASK_STORAGE_KEY) || "[]") as AdPublishTask[];
    return Array.isArray(stored) ? stored : [];
  } catch {
    return [];
  }
}

export function writeAdTasks(tasks: AdPublishTask[]) {
  localStorage.setItem(AD_TASK_STORAGE_KEY, JSON.stringify(tasks));
  window.dispatchEvent(new Event("ad-publish-tasks-updated"));
}

export function sortAdTasks(tasks: AdPublishTask[]) {
  return [...tasks].sort((left, right) => {
    if (left.status === "queued" && right.status === "queued" && left.priority !== right.priority) return right.priority - left.priority;
    return right.createdAt - left.createdAt;
  });
}

/** Keep the same ad/material identity and only advance its Page ID after a Page-related API failure. */
export function rotateMaterialPageAfterFailure(material: AdTaskMaterial) {
  const candidates = material.pageCandidateIds || [];
  if (candidates.length < 2) return material;
  const currentIndex = candidates.indexOf(material.assignedPageId);
  return { ...material, assignedPageId: candidates[(currentIndex < 0 ? 0 : currentIndex + 1) % candidates.length] };
}
