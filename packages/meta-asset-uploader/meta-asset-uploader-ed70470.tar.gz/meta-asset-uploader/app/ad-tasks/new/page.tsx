import type { Metadata } from "next";
import { NewAdTask } from "../new-task";

export const metadata: Metadata = {
  title: "新建广告任务 | Meta Creative Vault",
  description: "选择广告账户、历史素材和 Campaign / Ad Set / Ad 创建结构。",
};

export default function NewAdTaskPage() { return <NewAdTask />; }
