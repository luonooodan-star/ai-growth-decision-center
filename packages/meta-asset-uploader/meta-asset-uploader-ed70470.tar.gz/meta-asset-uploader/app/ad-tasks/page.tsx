import type { Metadata } from "next";
import { AdTaskList } from "./task-list";

export const metadata: Metadata = {
  title: "广告发布任务 | Meta Creative Vault",
  description: "创建、排序和管理 Meta 广告发布任务。",
};

export default function AdTasksPage() { return <AdTaskList />; }
