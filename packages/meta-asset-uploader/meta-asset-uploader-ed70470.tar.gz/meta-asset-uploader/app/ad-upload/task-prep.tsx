"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { TaskNavigation } from "../ad-tasks/task-list";

export function TaskPrep() {
  const params = useSearchParams();
  return <main className="ad-shell"><TaskNavigation active="tasks" /><section className="task-prep"><p className="eyebrow">AD TASK PREPARATION</p><h1>广告任务，<br /><em>准备中。</em></h1><p>已选配置 ID：<code>{params.get("config") || "—"}</code></p><div className="review-note">请使用新版广告任务页面选择账户、素材与创建结构。</div><Link className="new-config-button" href={`/ad-tasks/new?config=${params.get("config") || ""}`}>进入新版任务页面</Link></section></main>;
}
