import { AdWorkspace } from "../workspace";

export default function NewAdConfigPage() { return <AdWorkspace />; }
