import { AdWorkspace } from "../../workspace";

export default function NewIos14AdConfigPage() {
  return <AdWorkspace variant="ios14" />;
}
