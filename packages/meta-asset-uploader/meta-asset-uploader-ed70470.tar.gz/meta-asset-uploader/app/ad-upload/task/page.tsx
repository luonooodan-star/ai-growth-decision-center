import { TaskPrep } from "../task-prep";

export default function AdTaskPage() { return <TaskPrep />; }
