import type { Metadata } from "next";
import { ConfigList } from "./config-list";

export const metadata: Metadata = {
  title: "广告配置模版 | Meta Creative Vault",
  description: "集中查看、创建和修改 Meta 广告配置模版。",
};

export default function AdUploadPage() { return <ConfigList />; }
