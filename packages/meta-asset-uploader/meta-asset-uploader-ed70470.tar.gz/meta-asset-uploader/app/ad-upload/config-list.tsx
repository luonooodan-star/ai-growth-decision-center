"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { TaskNavigation } from "../ad-tasks/task-list";
import "./workspace.css";

type Template = { id: string; name: string; objective: "app" | "sales"; createdAt: number; config: Record<string, string | string[]> };
const STORAGE_KEY = "meta-creative-vault-ad-templates-v2";

export function ConfigList() {
  const [templates, setTemplates] = useState<Template[]>([]);
  useEffect(() => { try { setTemplates(JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]") as Template[]); } catch { setTemplates([]); } }, []);
  function remove(id: string) { const next = templates.filter((item) => item.id !== id); localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); setTemplates(next); }
  return <main className="ad-shell">
    <TaskNavigation active="configs" />
    <section className="ad-hero compact-hero config-hero"><div><p className="eyebrow">AD CONFIGURATION LIBRARY</p><h1>全部广告，<br /><em>配置在这里。</em></h1><p>标准配置与 iOS 14+ 配置共用广告发布任务、账户筛选和粉丝页轮换。</p></div><div className="config-create-actions"><Link className="new-config-button ios14-button" href="/ad-upload/ios14/new">+ 新建 iOS 14+ 配置</Link><Link className="new-config-button" href="/ad-upload/new">+ 新建标准配置</Link></div></section>
    <section className="config-library"><div className="panel-head"><div className="step-label"><span>01</span>广告配置</div><span>{templates.length} 条</span></div>{templates.length === 0 ? <div className="empty-results">还没有广告配置。点击右上角按钮开始。</div> : <div className="config-table-wrap"><table className="config-table"><thead><tr><th>广告配置 ID</th><th>配置名称</th><th>类型</th><th>动态素材</th><th>应用名称</th><th>营销目标</th><th>地区</th><th>操作</th></tr></thead><tbody>{templates.map((template) => { const ios14 = readValue(template.config.template_type) === "ios14"; const dynamic = usesDynamicCreative(template.config); return <tr key={template.id}><td><code>{template.id.slice(0, 8)}</code></td><td>{template.name}</td><td><span className={`config-type-badge ${ios14 ? "ios14" : ""}`}>{ios14 ? "iOS 14+" : "标准"}</span></td><td><span className={`config-type-badge dynamic ${dynamic ? "enabled" : ""}`}>{dynamic ? "已开启" : "已关闭"}</span></td><td>{readValue(template.config.app_name) || "—"}</td><td>{template.objective === "app" ? "应用安装" : "销量"}</td><td>{readValue(template.config.countries) || "—"}</td><td><div className="config-actions"><Link href={`${ios14 ? "/ad-upload/ios14/new" : "/ad-upload/new"}?edit=${template.id}`}>修改</Link><Link className="task-link" href={`/ad-tasks/new?config=${template.id}`}>创建广告任务</Link><button type="button" onClick={() => remove(template.id)}>删除</button></div></td></tr>; })}</tbody></table></div>}</section>
  </main>;
}

function readValue(value: string | string[] | undefined) { return Array.isArray(value) ? value.join(", ") : value || ""; }
function usesDynamicCreative(config: Template["config"]) {
  const setting = readValue(config.dynamic_creative);
  if (setting) return setting === "1";
  return [config.creative_bodies, config.creative_titles, config.creative_descriptions].some((raw) => Array.isArray(raw) && raw.filter(Boolean).length > 1);
}
