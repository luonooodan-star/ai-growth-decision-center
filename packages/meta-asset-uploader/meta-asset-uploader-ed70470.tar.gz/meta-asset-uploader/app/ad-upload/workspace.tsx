"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { FormEvent, useEffect, useRef, useState } from "react";
import type { SharedAppConfig } from "../../lib/app-config";
import { readJsonResponse } from "../client-response";
import "./workspace.css";
import "./advantage-audience.css";

type Connection = { connected?: boolean; name?: string };
type Objective = "app" | "sales";
type DataSource = { id: string; name: string; kind: "pixel" | "dataset"; account_id: string; account_name: string };
type CtaOption = { value: string; label: string; objectives: Objective[] };
type Template = { id: string; name: string; objective: Objective; createdAt: number; config: Record<string, string | string[]> };
const STORAGE_KEY = "meta-creative-vault-ad-templates-v2";
const pattern = "xiye_fb_{APP名称}_andr_lzx_T1EN_{日期}_AEO_{三位序号}_Codex";
const ios14Pattern = "xiye_fb_{日期}_AEO_{三位序号}_Codex";
const dynamicFields = new Set(["APP名称", "日期", "三位序号", "账户ID", "账户名称", "配置名称", "营销目标", "平台", "国家"]);

export function AdWorkspace({ variant = "standard" }: { variant?: "standard" | "ios14" }) {
  const ios14 = variant === "ios14";
  const [connection, setConnection] = useState<Connection>({});
  const [objective, setObjective] = useState<Objective>("app");
  const [bidStrategy, setBidStrategy] = useState("LOWEST_COST_WITHOUT_CAP");
  const [advantageAudience, setAdvantageAudience] = useState("0");
  const [campaignPattern, setCampaignPattern] = useState(pattern);
  const [sources, setSources] = useState<DataSource[]>([]);
  const [ctaOptions, setCtaOptions] = useState<CtaOption[]>([]);
  const [appConfigs, setAppConfigs] = useState<SharedAppConfig[]>([]);
  const [selectedAppConfigId, setSelectedAppConfigId] = useState("");
  const [templates, setTemplates] = useState<Template[]>([]);
  const [editing, setEditing] = useState<Template | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const formRef = useRef<HTMLFormElement>(null);
  const router = useRouter();
  const params = useSearchParams();
  const editId = params.get("edit") || "";

  useEffect(() => { void loadMetaOptions(); }, []);
  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]") as Template[];
      setTemplates(stored);
      const current = stored.find((item) => item.id === editId) || null;
      setEditing(current);
      if (current) {
        setObjective(ios14 ? "app" : current.objective);
        setBidStrategy(readConfig(current.config.bid_strategy, "LOWEST_COST_WITHOUT_CAP"));
        setAdvantageAudience(readConfig(current.config.advantage_audience, "0"));
        setCampaignPattern(readConfig(current.config.campaign_name_pattern, ios14 ? ios14Pattern : pattern));
      } else if (ios14) { setObjective("app"); setCampaignPattern(ios14Pattern); setAdvantageAudience("0"); }
    } catch { setTemplates([]); }
  }, [editId, ios14]);
  useEffect(() => {
    if (!editing || objective !== "app") { setSelectedAppConfigId(""); return; }
    const storedId = readConfig(editing.config.app_config_id, "");
    const storedMetaId = readConfig(editing.config.app_id, "");
    const match = appConfigs.find((item) => item.id === storedId || item.metaAppId === storedMetaId);
    setSelectedAppConfigId(match?.id || (storedMetaId ? "__legacy__" : ""));
  }, [editing, appConfigs, objective]);
  useEffect(() => {
    if (!editing || !formRef.current) return;
    const form = formRef.current;
    Object.entries(editing.config).forEach(([key, raw]) => {
      const field = form.elements.namedItem(key);
      if (!field) return;
      const storedValues = Array.isArray(raw) ? raw : [raw];
      const values = key === "call_to_action_type" && objective === "app"
        ? storedValues.map((item) => item === "INSTALL_APP" ? "INSTALL_MOBILE_APP" : item)
        : storedValues;
      if (field instanceof RadioNodeList) {
        Array.from(field).forEach((node) => { if (node instanceof HTMLInputElement) node.checked = values.includes(node.value); });
      } else if (field instanceof HTMLSelectElement && field.multiple) {
        Array.from(field.options).forEach((option) => { option.selected = values.includes(option.value); });
      } else if (field instanceof HTMLInputElement || field instanceof HTMLSelectElement || field instanceof HTMLTextAreaElement) field.value = values[0] || "";
    });
  }, [editing, objective]);

  async function loadMetaOptions() {
    setLoading(true);
    try {
      const [statusResponse, optionResponse] = await Promise.all([
        fetch("/api/meta/status", { cache: "no-store" }),
        fetch("/api/meta/ad-options", { cache: "no-store" }),
      ]);
      const status = await readJsonResponse<Connection>(statusResponse, "读取 Meta 连接状态失败");
      const optionPayload = await readJsonResponse<{ cta_options?: CtaOption[] }>(optionResponse, "读取 CTA 选项失败");
      setConnection(status);
      setCtaOptions(optionPayload.cta_options || []);
      if (!status.connected) return;
      const [sourceResponse, appConfigResponse] = await Promise.all([
        fetch("/api/meta/ad-assets", { cache: "no-store" }),
        fetch("/api/meta/app-configs", { cache: "no-store" }),
      ]);
      const sourcePayload = await readJsonResponse<{ sources?: DataSource[] }>(sourceResponse, "读取数据集和像素失败");
      const appConfigPayload = await readJsonResponse<{ configs?: SharedAppConfig[]; error?: string }>(appConfigResponse, "读取应用配置失败");
      setSources(sourcePayload.sources || []);
      if (!appConfigResponse.ok) throw new Error(appConfigPayload.error || "读取应用配置失败");
      setAppConfigs(appConfigPayload.configs || []);
    } finally { setLoading(false); }
  }

  function saveTemplate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get("template_name") || "").trim();
    const costOrBid = String(form.get("bid_amount") || "").trim();
    const bodies = form.getAll("creative_bodies").map(String).map((value) => value.trim()).filter(Boolean);
    const titles = form.getAll("creative_titles").map(String).map((value) => value.trim()).filter(Boolean);
    const descriptions = form.getAll("creative_descriptions").map(String).map((value) => value.trim()).filter(Boolean);
    const dynamicCreative = String(form.get("dynamic_creative") || "0") === "1";
    if (!name) return setMessage("请填写模版名称。 ");
    if (!["0", "1"].includes(String(form.get("advantage_audience") || ""))) return setMessage("请选择启用或禁用赋能型受众。");
    if (!String(form.get("dsa_beneficiary") || "").trim()) return setMessage("请填写广告推广的个人或组织。");
    if (!form.get("call_to_action_type")) return setMessage("请选择 CTA 行动号召按钮。");
    if (bodies.length > 5) return setMessage("正文最多填写 5 条。");
    if (titles.length > 5) return setMessage("广告标题最多填写 5 条。");
    if (dynamicCreative && bodies.length <= 1 && titles.length <= 1 && descriptions.length <= 1) return setMessage("开启动态素材组合后，正文、广告标题或描述至少有一项需要填写 2 条以上。");
    const unknownFields = [...campaignPattern.matchAll(/\{([^{}]+)\}/g)].map((match) => match[1]).filter((field) => !dynamicFields.has(field));
    if (unknownFields.length) return setMessage(`广告系列名称包含不支持的动态字段：${[...new Set(unknownFields)].map((field) => `{${field}}`).join("、")}`);
    if (bidStrategy !== "LOWEST_COST_WITHOUT_CAP" && !costOrBid) return setMessage(bidStrategy === "COST_CAP" ? "请填写单次成效费用目标。" : "请填写竞价上限费用。");
    if (objective === "sales" && !form.get("data_source_id")) return setMessage("销量目标需要选择一个已授权的数据集或像素。");
    if (objective === "sales" && !String(form.get("destination_url") || "").trim()) return setMessage("销量目标需要填写落地页网址。");
    if (objective === "sales" && campaignPattern.includes("{APP名称}")) return setMessage("销量目标不使用 APP 名称；请从广告系列名称模式中移除 {APP名称}。");
    if (objective === "app" && !form.get("app_config_id")) return setMessage("应用安装目标需要选择一个应用配置。");
    if (objective === "app" && (!form.get("app_name") || !form.get("app_id") || !form.get("store_url"))) return setMessage(`所选应用缺少 ${ios14 ? "Apple App Store" : "Google Play"} 链接，请先到“应用配置”页面补充。`);
    if (ios14 && !/^https:\/\/apps\.apple\.com\//i.test(String(form.get("store_url") || ""))) return setMessage("iOS 14+ 配置必须填写完整的 https://apps.apple.com/ Apple App Store 链接。");
    const config = formDataToConfig(form);
    config.template_type = ios14 ? "ios14" : "standard";
    if (ios14) {
      config.objective = "OUTCOME_APP_PROMOTION";
      config.is_skadnetwork_attribution = "true";
      config.user_os = "iOS";
      config.os_min = "14.0";
      config.os_max = "none";
      config.device_platforms = "mobile";
    }
    const callToActionType = String(form.get("call_to_action_type"));
    const effectiveBodies = dynamicCreative ? bodies : bodies.slice(0, 1);
    const effectiveTitles = dynamicCreative ? titles : titles.slice(0, 1);
    const effectiveDescriptions = dynamicCreative ? descriptions : descriptions.slice(0, 1);
    config.asset_feed_spec = JSON.stringify({
      ...(effectiveBodies.length ? { bodies: effectiveBodies.map((text) => ({ text })) } : {}),
      ...(effectiveTitles.length ? { titles: effectiveTitles.map((text) => ({ text })) } : {}),
      ...(effectiveDescriptions.length ? { descriptions: effectiveDescriptions.map((text) => ({ text })) } : {}),
      call_to_action_types: [callToActionType],
      call_to_actions: [{ type: callToActionType }],
    });
    const saved: Template = { id: editing?.id || crypto.randomUUID(), name, objective, createdAt: editing?.createdAt || Date.now(), config };
    const next = editing ? templates.map((item) => item.id === editing.id ? saved : item) : [saved, ...templates];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); setTemplates(next); router.push("/ad-upload");
  }

  return <main className="ad-shell">
    <header className="topbar"><div className="brand"><span className="brand-mark">M</span><span>Meta Creative Vault</span></div><nav className="top-nav"><Link href="/">素材库</Link><Link href="/app-configs">应用配置</Link><Link className="active" href="/ad-upload">广告配置模版</Link><Link href="/page-configs">粉丝页配置</Link><Link href="/audiences">受众生成库</Link><Link href="/ad-tasks">广告发布任务</Link></nav><div className={`connection ${connection.connected ? "online" : ""}`}><span className="status-dot" />{connection.connected ? `已连接 ${connection.name || "Meta"}` : "未连接 Meta"}</div></header>
    <section className="ad-hero compact-hero"><div><p className="eyebrow">{ios14 ? "IOS 14+ · SKADNETWORK TEMPLATE" : "API-READY CAMPAIGN TEMPLATE"}</p><h1>{editing ? "修改广告，" : "新建广告，"}<br /><em>{ios14 ? "iOS 14+ 配置。" : "配置模版。"}</em></h1><p>{ios14 ? "专用于 iOS 14+ App Promotion；保存后可在通用广告发布页面直接搜索使用。" : "所有选项都保留对应的 Marketing API 字段。保存不会创建或发布广告。"}</p></div><Link className="back-to-library" href="/ad-upload">返回配置列表</Link></section>
    {!connection.connected && !loading && <section className="ad-connect"><div><strong>请先连接 Meta 账户</strong><span>连接后才能读取授权个号可见的像素、数据集与定向选项。</span></div><a className="primary-button" href="/api/meta/connect">使用 Meta 登录</a></section>}

    <form ref={formRef} className="template-form" onSubmit={saveTemplate}>
      <section className="ad-card template-name-card"><div className="card-kicker">01 · 模版</div><h2>{editing ? "修改广告配置" : ios14 ? "新建 iOS 14+ 配置" : "新建广告配置"}</h2><label>模版名称<input required name="template_name" defaultValue={editing?.name} placeholder={ios14 ? "例如：Data_AQ · iOS 14+ · 美国" : "例如：Data_AQ · 安卓安装 · 美国"} /></label><p className="field-note">保存后会返回广告配置列表；后续可随时修改。</p></section>
      <section className="ad-card campaign-card"><div className="card-kicker">02 · 目标与命名</div><h2>定义广告系列</h2><div className="campaign-fields"><label className="full-field">营销目标<div className={`goal-grid ${ios14 ? "" : "two-goals"}`}><button type="button" className={objective === "app" ? "selected" : ""} onClick={() => { setObjective("app"); if (!campaignPattern.includes("{APP名称}") && !ios14) setCampaignPattern(pattern); }}><span>{ios14 ? "iOS 14+ 应用推广" : "应用安装"}</span><small>OUTCOME_APP_PROMOTION{ios14 ? " · SKAdNetwork" : ""}</small></button>{!ios14 && <button type="button" className={objective === "sales" ? "selected" : ""} onClick={() => { setObjective("sales"); if (campaignPattern === pattern) setCampaignPattern(ios14Pattern); }}><span>销量</span><small>OUTCOME_SALES</small></button>}</div></label><input type="hidden" name="objective" value={objective === "app" ? "OUTCOME_APP_PROMOTION" : "OUTCOME_SALES"} />
        {ios14 && <input type="hidden" name="template_type" value="ios14" />}
        <label className="full-field">广告系列名称模式<input name="campaign_name_pattern" value={campaignPattern} onChange={(event) => setCampaignPattern(event.target.value)} /></label><p className="field-note full-field">可用动态字段：{[...dynamicFields].map((field) => <code key={field}>{`{${field}}`}</code>)}。<code>{"{三位序号}"}</code>按本次任务中 Campaign 的实际创建顺序生成 001、002、003…，不是随机数。</p>
        {objective === "sales" ? <SalesSettings sources={sources} /> : <AppSettings ios14={ios14} configs={appConfigs} selectedId={selectedAppConfigId} onChange={setSelectedAppConfigId} legacyConfig={editing?.config} />}
        <label>投放事件<input required name="app_event" defaultValue="PURCHASE" placeholder="例如：PURCHASE、INSTALL" /></label></div>
      </section>
      <CreativeCopyFields key={editing?.id || "new"} objective={objective} initialConfig={editing?.config} ctaOptions={ctaOptions} />
      <section className="ad-card budget-card"><div className="card-kicker">04 · 预算与竞价</div><h2>设置花费方式</h2><div className="split-fields"><label>预算方式<select name="budget_mode" defaultValue="CBO"><option value="CBO">CBO · 广告系列预算</option><option value="ABO">ABO · 广告组预算</option></select></label><label>每日预算<input required name="daily_budget" inputMode="decimal" placeholder="例如：100" /></label></div><label>广告系列竞价策略<select name="bid_strategy" value={bidStrategy} onChange={(event) => setBidStrategy(event.target.value)}><option value="LOWEST_COST_WITHOUT_CAP">最高数量</option><option value="COST_CAP">单次成效费用目标</option><option value="LOWEST_COST_WITH_BID_CAP">竞价上限</option></select></label>{bidStrategy === "COST_CAP" && <label>单次成效费用目标<input name="bid_amount" inputMode="decimal" placeholder="按账户币种填写，例如：15" /></label>}{bidStrategy === "LOWEST_COST_WITH_BID_CAP" && <label>竞价上限费用<input name="bid_amount" inputMode="decimal" placeholder="按账户币种填写，例如：20" /></label>}<p className="field-note">API 映射：<code>bid_strategy</code> 与 <code>bid_amount</code>；金额会在实际创建时按账户币种换算为 API 所需的最小货币单位。</p></section>
      <section className="ad-card dsa-card"><div className="card-kicker">05 · 广告披露</div><h2>广告推广的个人或组织</h2><div className="split-fields"><label>广告推广受益方<input required name="dsa_beneficiary" maxLength={255} placeholder="输入从广告中受益的个人或组织全名" /><small>提交到 Ad Set 的 <code>dsa_beneficiary</code>。</small></label><label>广告费用付款方（可选）<input name="dsa_payor" maxLength={255} placeholder="留空则与广告推广受益方相同" /><small>提交到 <code>dsa_payor</code>；留空时自动使用受益方。</small></label></div><p className="field-note">该信息用于 Meta 广告透明度披露。标准配置与 iOS 14+ 配置都会保存并在创建广告组时提交。</p></section>
      <section className="ad-card rule-card"><div className="card-kicker">05 · 投放规则</div><h2>设置受众与设备</h2><div className="rule-grid"><label>国家 / 地区<input required name="countries" defaultValue="US,GB,AU,CA,FR,JP,KR,DE" placeholder="例如：US,GB,AU" /></label><label>语言限制<input name="languages" placeholder="例如：en,ja,ko；留空则不限" /></label><label>最低年龄<select name="age_min" defaultValue="18">{[18,21,25,30,35,40,45,50,55,60,65].map((age) => <option key={age}>{age}</option>)}</select></label><label>最高年龄<select name="age_max" defaultValue="65">{[18,21,25,30,35,40,45,50,55,60,65].map((age) => <option key={age}>{age}</option>)}</select></label><label>性别<select name="genders" defaultValue="all"><option value="all">不限</option><option value="1">男性</option><option value="2">女性</option></select></label><label>位置类型<select name="location_types" defaultValue="home,recent"><option value="home,recent">居住地和最近所在地</option><option value="home">仅居住地</option></select></label></div><p className="field-note">国家使用 ISO 两位缩写，如 <code>US,GB,AU</code>；语言使用语言缩写，如 <code>en,ja,ko</code>。实际创建时会转换为 <code>geo_locations.countries</code> 与 <code>locales</code>。</p><fieldset className="rule-box audience-box"><legend>首选受众</legend><label><input type="radio" name="audience_rule" value="keep_current" defaultChecked /><span><b>保留当前设置</b><small>使用系统建议的进阶型受众。</small></span></label><label><input type="radio" name="audience_rule" value="value_rules" /><span><b>应用价值规则并开启进阶型受众</b></span></label><label><input type="radio" name="audience_rule" value="restrict" /><span><b>进一步限制广告覆盖范围</b></span></label></fieldset><DeviceSettings ios14={ios14} /></section>
      <AdvantageAudienceSettings value={advantageAudience} onChange={setAdvantageAudience} />
      <section className="save-card"><div><strong>{editing ? "保存修改" : "保存为广告配置模版"}</strong><span>当前只保存配置，不创建 Campaign、Ad Set 或广告。</span></div><div className="save-actions"><Link href="/ad-upload">取消</Link><button className="save-template" type="submit" disabled={!connection.connected}>{editing ? "保存修改" : "保存模版"}</button></div></section>{message && <p className="template-message">{message}</p>}
    </form>
  </main>;
}

function SalesSettings({ sources }: { sources: DataSource[] }) { return <div className="sales-only config-fields-grid"><label>转化发生位置<select name="conversion_location" defaultValue="website"><option value="website">网页（Web）</option></select><small>当前发布流程已完整支持网页转化；应用和消息转化需要不同的必填资产，暂不开放。</small></label><label>成效目标<select name="sales_performance_goal" defaultValue="OFFSITE_CONVERSIONS"><option value="OFFSITE_CONVERSIONS">转化量最大化</option><option value="VALUE">转化价值最大化</option></select></label><label className="full-field">网址（落地页）<input required name="destination_url" type="url" inputMode="url" placeholder="https://example.com/landing-page" /><small>保存为广告创意链接，发布时映射到 <code>asset_feed_spec.link_urls</code>。</small></label><label className="full-field">数据集 / 像素<select required name="data_source_id" defaultValue=""><option value="">选择授权个号可见的数据集或像素</option>{sources.map((source) => <option key={`${source.kind}-${source.account_id}-${source.id}`} value={source.id}>{source.name} · {source.id} · {source.account_name}（{source.kind === "pixel" ? "像素" : "数据集"}）</option>)}</select></label></div>; }
function AppSettings({ ios14, configs, selectedId, onChange, legacyConfig }: { ios14: boolean; configs: SharedAppConfig[]; selectedId: string; onChange: (id: string) => void; legacyConfig?: Record<string, string | string[]> }) {
  const legacyMetaId = readConfig(legacyConfig?.app_id, "");
  const legacyName = readConfig(legacyConfig?.app_name, "");
  const legacyStoreUrl = readConfig(legacyConfig?.store_url, "");
  const selected = configs.find((item) => item.id === selectedId);
  const appName = selected?.name || (selectedId === "__legacy__" ? legacyName : "");
  const appId = selected?.metaAppId || (selectedId === "__legacy__" ? legacyMetaId : "");
  const storeUrl = selected ? (ios14 ? selected.appleAppStoreUrl || "" : selected.googlePlayUrl) : selectedId === "__legacy__" ? legacyStoreUrl : "";
  return <div className="app-only config-fields-grid">
    <label className="full-field">APP 名称<select required name="app_config_id" value={selectedId} onChange={(event) => onChange(event.target.value)}><option value="">请选择已配置应用</option>{configs.map((config) => <option key={config.id} value={config.id} disabled={ios14 && !config.appleAppStoreUrl}>{config.name}{ios14 && !config.appleAppStoreUrl ? "（缺少 Apple App Store 链接）" : ""}</option>)}{selectedId === "__legacy__" && legacyMetaId && <option value="__legacy__">{legacyName || legacyMetaId}（旧模版快照）</option>}</select><small>应用资料由“应用配置”页面统一维护。<Link href="/app-configs">管理应用配置</Link></small></label>
    <input type="hidden" name="app_name" value={appName} /><input type="hidden" name="app_id" value={appId} /><input type="hidden" name="store_url" value={storeUrl} />
    {selectedId && <div className={`selected-app-summary full-field ${storeUrl ? "" : "missing"}`}><span><b>Meta App ID</b>{appId || "未配置"}</span><span><b>{ios14 ? "Apple App Store" : "Google Play"}</b>{storeUrl || "未配置，请先补充链接"}</span></div>}
    <label>成效目标<select name="app_performance_goal" defaultValue="APP_INSTALLS"><option value="APP_INSTALLS">应用安装量最大化</option><option value="APP_INSTALLS_AND_OFFSITE_CONVERSIONS">应用安装与应用事件最大化</option><option value="OFFSITE_CONVERSIONS">应用事件数量最大化</option><option value="VALUE">转化价值最大化</option>{!ios14 && <option value="LINK_CLICKS">链接点击量最大化</option>}</select></label>
    {ios14 && <div className="ios14-guard full-field"><strong>iOS 14+ 固定 API 设置</strong><span><code>is_skadnetwork_attribution=true</code> · <code>device_platforms=[mobile]</code> · <code>user_os=[iOS_ver_14.0_and_above]</code></span><small>应用必须已在 Meta App Dashboard 关联该 App Store 应用，并完成适用的 SKAdNetwork/应用事件配置；否则 Meta 仍可能拒绝或无法优化投放。</small></div>}
  </div>;
}
function CreativeCopyFields({ objective, initialConfig, ctaOptions }: { objective: Objective; initialConfig?: Record<string, string | string[]>; ctaOptions: CtaOption[] }) {
  const [bodies, setBodies] = useState(() => readConfigList(initialConfig?.creative_bodies));
  const [titles, setTitles] = useState(() => readConfigList(initialConfig?.creative_titles));
  const description = readConfig(initialConfig?.creative_descriptions, "");
  const initiallyDynamic = readConfig(initialConfig?.dynamic_creative, "") === "1"
    || (!initialConfig?.dynamic_creative && (bodies.filter(Boolean).length > 1 || titles.filter(Boolean).length > 1 || readConfigList(initialConfig?.creative_descriptions).filter(Boolean).length > 1));
  const [dynamicCreative, setDynamicCreative] = useState(initiallyDynamic);
  const availableCtas = ctaOptions.filter((option) => option.objectives.includes(objective));
  const storedCta = readConfig(initialConfig?.call_to_action_type, objective === "app" ? "INSTALL_MOBILE_APP" : "LEARN_MORE");
  const selectedCta = objective === "app" && storedCta === "INSTALL_APP" ? "INSTALL_MOBILE_APP" : storedCta;
  return <section className="ad-card creative-copy-card"><div className="card-kicker">03 · 创意文案</div><h2>设置广告展示内容</h2><div className={`dynamic-creative-toggle ${dynamicCreative ? "enabled" : ""}`}><div><strong>动态素材组合</strong><span>{dynamicCreative ? "已开启 · Meta 将组合多条正文、标题或描述" : "已关闭 · 每个文案栏只使用第一条内容"}</span></div><button type="button" role="switch" aria-checked={dynamicCreative} onClick={() => setDynamicCreative((current) => !current)}><i /><b>{dynamicCreative ? "开启" : "关闭"}</b></button><input type="hidden" name="dynamic_creative" value={dynamicCreative ? "1" : "0"} /></div><label>CTA 行动号召<select required name="call_to_action_type" key={`${objective}-${selectedCta}`} defaultValue={selectedCta}>{availableCtas.map((option) => <option key={option.value} value={option.value}>{option.label} · {option.value}</option>)}</select><small>由服务端按当前 Meta Marketing API 版本提供；旧的 INSTALL_APP 会自动迁移为 INSTALL_MOBILE_APP。</small></label><VariationEditor label="正文" name="creative_bodies" values={bodies} onChange={setBodies} multiline placeholder="输入广告正文" /><VariationEditor label="广告标题" name="creative_titles" values={titles} onChange={setTitles} placeholder="输入广告标题" />{objective === "sales" && <label>描述（销量目标）<textarea name="creative_descriptions" defaultValue={description} placeholder="输入广告描述；可留空" /></label>}<p className="field-note">开启时，正文、广告标题或描述至少一项必须有 2 条以上，发布时才发送 <code>DEGREES_OF_FREEDOM</code>。关闭时只提交每栏第一条，避免单份素材触发 Meta 的自由度校验错误。</p></section>;
}
function VariationEditor({ label, name, values, onChange, multiline = false, placeholder }: { label: string; name: string; values: string[]; onChange: (values: string[]) => void; multiline?: boolean; placeholder: string }) {
  return <fieldset className="variation-editor"><legend>{label}（可选，{values.filter((value) => value.trim()).length}/5）</legend><div className="variation-list">{values.map((value, index) => <div className="variation-row" key={`${name}-${index}`}>{multiline ? <textarea name={name} value={value} onChange={(event) => onChange(values.map((item, itemIndex) => itemIndex === index ? event.target.value : item))} placeholder={`${placeholder} ${index + 1}`} /> : <input name={name} value={value} onChange={(event) => onChange(values.map((item, itemIndex) => itemIndex === index ? event.target.value : item))} placeholder={`${placeholder} ${index + 1}`} />}<button type="button" aria-label={`删除${label} ${index + 1}`} disabled={values.length === 1} onClick={() => onChange(values.filter((_, itemIndex) => itemIndex !== index))}>删除</button></div>)}</div><button className="add-variation" type="button" disabled={values.length >= 5} onClick={() => onChange([...values, ""])}>+ 添加{label}</button></fieldset>;
}
function DeviceSettings({ ios14 }: { ios14: boolean }) { return <fieldset className="rule-box device-box"><legend>设备和操作系统</legend>{ios14 ? <><input type="hidden" name="user_os" value="iOS" /><input type="hidden" name="device_platforms" value="mobile" /><input type="hidden" name="os_min" value="14.0" /><input type="hidden" name="os_max" value="none" /><div className="rule-grid"><div className="readonly-field"><b>操作系统</b><span>iOS 14.0 及以上</span></div><div className="readonly-field"><b>设备范围</b><span>移动设备 · mobile</span></div><label>无线连接<select name="wireless_carrier" defaultValue="all"><option value="all">不限</option><option value="Wifi">仅在连接 Wi-Fi 时</option></select></label></div></> : <div className="rule-grid"><label>仅限操作系统<select name="user_os" defaultValue="Android"><option value="Android">Android</option><option value="iOS">iOS</option></select></label><label>设备范围<select name="device_platforms" defaultValue="mobile"><option value="mobile">移动设备 · mobile</option><option value="desktop">桌面设备 · desktop</option><option value="connected_tv">联网电视 · connected_tv</option></select></label><label>系统最低版本<select name="os_min" defaultValue="none"><option value="none">不限</option><option value="8.0">8.0</option><option value="9.0">9.0</option><option value="10.0">10.0</option><option value="11.0">11.0</option><option value="12.0">12.0</option><option value="13.0">13.0</option><option value="14.0">14.0</option></select></label><label>系统最高版本<select name="os_max" defaultValue="none"><option value="none">不限</option><option value="10.0">10.0</option><option value="11.0">11.0</option><option value="12.0">12.0</option><option value="13.0">13.0</option><option value="14.0">14.0</option></select></label><label>无线连接<select name="wireless_carrier" defaultValue="all"><option value="all">不限</option><option value="Wifi">仅在连接 Wi-Fi 时</option></select></label></div>}<p className="field-note">{ios14 ? <>该配置固定映射到 <code>user_os=[iOS_ver_14.0_and_above]</code>，并在 Campaign 层启用 SKAdNetwork attribution。</> : <><code>device_platforms</code> 只提交 Meta 支持的 <code>mobile</code>、<code>desktop</code> 或 <code>connected_tv</code>；Android/iOS 及版本限制单独映射到 <code>user_os</code>。</>}</p></fieldset>; }
function AdvantageAudienceSettings({ value, onChange }: { value: string; onChange: (value: string) => void }) { const enabled=value==="1";return <section className="ad-card advantage-card"><div className="card-kicker">06 · 赋能型受众</div><h2>选择受众投放方式</h2><div className="advantage-choice"><button type="button" className={!enabled?"selected":""} onClick={()=>onChange("0")}><b>禁用 · 传统受众</b><span>年龄、性别和纳入受众按当前定向提交，不允许系统扩展。</span></button><button type="button" className={enabled?"selected":""} onClick={()=>onChange("1")}><b>启用 · Advantage+ Audience</b><span>将年龄、性别和纳入受众作为建议，允许 Meta 扩展寻找更可能转化的人。</span></button></div><input type="hidden" name="advantage_audience" value={value}/>{enabled?<div className="advantage-details enabled"><strong>启用后提交的新字段</strong><code>targeting_automation.advantage_audience = 1</code><code>targeting_automation.individual_setting = {`{ age: 1, gender: 1 }`}</code><code>age_range = [最低年龄, 最高年龄]</code><p>地区、语言和排除受众仍会保留；广告发布任务中勾选的“选择受众”作为建议，“排除受众”继续作为排除条件。</p></div>:<div className="advantage-details"><strong>传统定向模式</strong><code>targeting_automation.advantage_audience = 0</code><p>继续使用现有年龄、性别、地区、语言以及选择/排除受众，不增加建议年龄字段。</p></div>}</section>; }
function formDataToConfig(form: FormData) { const config: Record<string, string | string[]> = {}; const creativeLists = new Set(["creative_bodies", "creative_titles", "creative_descriptions"]); form.forEach((value, key) => { const text = String(value); if (creativeLists.has(key) && !text.trim()) return; config[key] = key in config ? [...(Array.isArray(config[key]) ? config[key] : [config[key]]), text] : text; }); return config; }
function readConfig(value: string | string[] | undefined, fallback: string) { return Array.isArray(value) ? value[0] || fallback : value || fallback; }
function readConfigList(value: string | string[] | undefined) { const values = (Array.isArray(value) ? value : value ? [value] : []).map((item) => item.trim()).filter(Boolean).slice(0, 5); return values.length ? values : [""]; }
