import type { Metadata } from "next";
import { CreativeUploader } from "./uploader";

export const metadata: Metadata = {
  title: "Meta 素材库",
  description: "连接 Meta，选择广告账户，并批量上传图片与视频素材。",
};

export default function Home() {
  return <CreativeUploader />;
}
