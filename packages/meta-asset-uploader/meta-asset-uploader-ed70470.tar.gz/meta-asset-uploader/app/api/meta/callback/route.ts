import { encryptToken, metaConfig, requestOrigin, sessionCookie } from "../../../../lib/meta";

function cookieValue(request: Request, name: string) {
  const found = (request.headers.get("cookie") || "").split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return found ? decodeURIComponent(found.slice(name.length + 1)) : "";
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  if (!code || !state || state !== cookieValue(request, "meta_oauth_state")) return Response.redirect(`${requestOrigin(request)}/?error=oauth_state`, 302);
  const config = metaConfig();
  const redirectUri = `${requestOrigin(request)}/api/meta/callback`;
  const tokenUrl = new URL(`https://graph.facebook.com/${config.graphVersion}/oauth/access_token`);
  tokenUrl.searchParams.set("client_id", config.appId);
  tokenUrl.searchParams.set("client_secret", config.appSecret);
  tokenUrl.searchParams.set("redirect_uri", redirectUri);
  tokenUrl.searchParams.set("code", code);
  const tokenResponse = await fetch(tokenUrl);
  const tokenPayload = await tokenResponse.json() as { access_token?: string; error?: { message?: string } };
  if (!tokenResponse.ok || !tokenPayload.access_token) return Response.redirect(`${requestOrigin(request)}/?error=${encodeURIComponent(tokenPayload.error?.message || "oauth_token")}`, 302);
  let accessToken = tokenPayload.access_token;
  try {
    const longLivedUrl = new URL(`https://graph.facebook.com/${config.graphVersion}/oauth/access_token`);
    longLivedUrl.searchParams.set("grant_type", "fb_exchange_token");
    longLivedUrl.searchParams.set("client_id", config.appId);
    longLivedUrl.searchParams.set("client_secret", config.appSecret);
    longLivedUrl.searchParams.set("fb_exchange_token", accessToken);
    const longLivedResponse = await fetch(longLivedUrl);
    const longLivedPayload = await longLivedResponse.json() as { access_token?: string };
    if (longLivedResponse.ok && longLivedPayload.access_token) accessToken = longLivedPayload.access_token;
  } catch { /* Keep the valid short-lived token if exchange is temporarily unavailable. */ }
  const encrypted = await encryptToken(accessToken);
  return new Response(null, { status: 302, headers: { location: `${requestOrigin(request)}/`, "set-cookie": sessionCookie(encrypted) } });
}
