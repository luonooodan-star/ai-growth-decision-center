import { getMetaToken, graphAll, safeError } from "../../../../lib/meta";

type Source = { id: string; name: string; kind: "pixel" | "dataset"; account_id: string; account_name: string };

export async function GET(request: Request) {
  const token = await getMetaToken(request);
  if (!token) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });
  try {
    const accounts = await graphAll("me/adaccounts", token, "id,account_id,name");
    const sources = (await Promise.all(accounts.map(async (account) => {
      const accountId = String(account.account_id || account.id || "").replace(/^act_/, "");
      const accountName = String(account.name || `act_${accountId}`);
      if (!accountId) return [] as Source[];
      const readEdge = async (edge: string) => {
        try { return await graphAll(`act_${accountId}/${edge}`, token, "id,name"); }
        catch { return []; }
      };
      const [pixels, datasets] = await Promise.all([readEdge("adspixels"), readEdge("datasets")]);
      return [
        ...pixels.map((item) => ({ id: String(item.id), name: String(item.name || item.id), kind: "pixel" as const, account_id: accountId, account_name: accountName })),
        ...datasets.map((item) => ({ id: String(item.id), name: String(item.name || item.id), kind: "dataset" as const, account_id: accountId, account_name: accountName })),
      ];
    }))).flat();
    const unique = new Map<string, Source>();
    sources.forEach((source) => unique.set(`${source.kind}:${source.id}:${source.account_id}`, source));
    return Response.json({ sources: [...unique.values()] });
  } catch (error) {
    return Response.json({ error: safeError(error) }, { status: 502 });
  }
}
