import { clearSessionCookie, requestOrigin } from "../../../../lib/meta";

export async function GET(request: Request) {
  return new Response(null, { status: 302, headers: { location: `${requestOrigin(request)}/`, "set-cookie": clearSessionCookie() } });
}
