import { META_CTA_OPTIONS } from "../../../../lib/meta-ad-options";
import { metaConfig } from "../../../../lib/meta";

export async function GET() {
  return Response.json({
    graph_version: metaConfig().graphVersion,
    source: "Meta Business SDK · AdCreative.CallToActionType",
    cta_options: META_CTA_OPTIONS,
  });
}
