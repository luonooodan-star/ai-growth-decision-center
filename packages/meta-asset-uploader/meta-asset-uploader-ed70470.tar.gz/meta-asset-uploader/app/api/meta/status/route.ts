import { getMetaToken, graph, metaConfigured, safeError } from "../../../../lib/meta";

export async function GET(request: Request) {
  if (!metaConfigured()) return Response.json({ connected: false, configured: false });
  const token = await getMetaToken(request);
  if (!token) return Response.json({ connected: false, configured: true });
  try {
    const profile = await graph("me", token, { fields: "id,name" });
    return Response.json({ connected: true, configured: true, id: profile.id, name: profile.name });
  } catch (error) {
    return Response.json({ connected: false, configured: true, error: safeError(error) });
  }
}
