import { getMetaToken, graphAll, safeError } from "../../../../lib/meta";

export async function GET(request: Request) {
  const token = await getMetaToken(request);
  if (!token) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });
  try {
    const [accounts, pages] = await Promise.all([
      graphAll("me/adaccounts", token, "id,account_id,name,account_status,currency,timezone_name"),
      graphAll("me/accounts", token, "id,name,access_token"),
    ]);
    return Response.json({
      accounts: accounts.map((account) => ({ ...account, id: String(account.account_id || account.id || "").replace(/^act_/, "") })).filter((account) => account.id),
      pages: pages.map(({ access_token: _accessToken, ...page }) => page),
    });
  } catch (error) {
    return Response.json({ error: safeError(error) }, { status: 502 });
  }
}
