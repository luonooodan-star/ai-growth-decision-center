import type { AdPublishTask } from "../../../ad-tasks/task-store";
import { getMetaToken, encryptToken, decryptToken, graph, graphAll, safeError } from "../../../../lib/meta";
import { assignStoredTaskOwner, getStoredTask, listLegacyStoredTasks, listStoredTasks, saveStoredTask, updateStoredTask } from "../../../../lib/ad-task-db";
import { validateTaskCapacity } from "../../../../lib/meta-ads";
import { listAudienceHistory } from "../../../../lib/audience-task-db";
import type { AudienceResult } from "../../../audiences/audience-store";
import { prepareAdTaskRetry } from "../../../../lib/ad-task-progress";
import { CLIENT_RECORD_RETENTION_MS } from "../../../../lib/retention";

async function ownerIdFor(token: string) {
  const profile = await graph("me", token, { fields: "id" });
  const ownerId = String(profile.id || "");
  if (!ownerId) throw new Error("无法识别当前 Meta 用户");
  return ownerId;
}

const migratedOwners = new Set<string>();
async function migrateLegacyTasks(ownerId: string) {
  if (migratedOwners.has(ownerId)) return;
  migratedOwners.add(ownerId);
  const legacyTasks = await listLegacyStoredTasks();
  for (const task of legacyTasks) {
    try {
      const legacyToken = await decryptToken(task.encryptedToken);
      if (!legacyToken) continue;
      const profile = await graph("me", legacyToken, { fields: "id" });
      if (String(profile.id || "") === ownerId) await assignStoredTaskOwner(task.id, ownerId);
    } catch { /* Expired legacy tokens stay private and are removed after 90 days. */ }
  }
}

export async function GET(request: Request) {
  const token = await getMetaToken(request);
  if (!token) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });
  try {
    const ownerId = await ownerIdFor(token);
    await migrateLegacyTasks(ownerId);
    const id = new URL(request.url).searchParams.get("id");
    if (id) {
      const task = await getStoredTask(id, ownerId);
      if (!task) return Response.json({ error: "任务不存在" }, { status: 404 });
      const visible: Partial<typeof task> = { ...task };
      delete visible.encryptedToken;
      delete visible.ownerId;
      return Response.json({ task: visible });
    }
    return Response.json({ tasks: await listStoredTasks({ ownerId, since: Date.now() - CLIENT_RECORD_RETENTION_MS }) });
  }
  catch (error) { return Response.json({ error: safeError(error) }, { status: 500 }); }
}

export async function POST(request: Request) {
  const token = await getMetaToken(request);
  if (!token) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });
  try {
    const ownerId = await ownerIdFor(token);
    const task = await request.json() as AdPublishTask;
    if (!task.id || !task.template?.config || !Array.isArray(task.accountIds) || !Array.isArray(task.materials)) throw new Error("广告任务数据不完整");
    validateTaskCapacity(task);
    const accounts = await graphAll("me/adaccounts", token, "id,account_id");
    const allowed = new Set(accounts.map((account) => String(account.account_id || account.id || "").replace(/^act_/, "")));
    if (task.accountIds.some((id) => !allowed.has(id))) throw new Error("当前 Meta 用户无权访问任务中的广告账户");
    const history = await listAudienceHistory();
    const audienceKeys = new Set(history.map((item: AudienceResult) => `${item.accountId}:${item.audienceId}`));
    const selectedAudiences = [...(task.includedAudiences || []), ...(task.excludedAudiences || [])];
    if (selectedAudiences.some((item) => !task.accountIds.includes(item.accountId) || !audienceKeys.has(`${item.accountId}:${item.audienceId}`))) throw new Error("受众与广告账户的归属关系无效，请重新选择受众");
    const included = new Set((task.includedAudiences || []).map((item) => `${item.accountId}:${item.audienceId}`));
    if ((task.excludedAudiences || []).some((item) => included.has(`${item.accountId}:${item.audienceId}`))) throw new Error("同一受众不能同时包含和排除");
    const now = Date.now();
    const stored = { ...task, status: "queued" as const, priority: task.priority || 0, createdAt: task.createdAt || now, updatedAt: now, encryptedToken: await encryptToken(token), ownerId };
    await saveStoredTask(stored);
    const visible: Partial<typeof stored> = { ...stored };
    delete visible.encryptedToken;
    delete visible.ownerId;
    return Response.json({ task: visible }, { status: 201 });
  } catch (error) {
    return Response.json({ error: safeError(error) }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  const token = await getMetaToken(request);
  if (!token) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });
  try {
    const ownerId = await ownerIdFor(token);
    const { id, action } = await request.json() as { id?: string; action?: "cancel" | "interrupt" | "prioritize" | "retry" | "copy" };
    if (!id || !action) throw new Error("缺少任务操作参数");
    if (action === "copy") {
      const source = await getStoredTask(id, ownerId);
      if (!source) return Response.json({ error: "任务不存在" }, { status: 404 });
      if (source.status !== "cancelled") throw new Error("只有已取消的广告任务可以复制");
      const now = Date.now();
      const copied = { ...source, id: crypto.randomUUID(), status: "queued" as const, priority: now, createdAt: now, updatedAt: now, result: undefined, progressAttempt: undefined, error: undefined, encryptedToken: await encryptToken(token) };
      await saveStoredTask(copied);
      const visible: Partial<typeof copied> = { ...copied }; delete visible.encryptedToken; delete visible.ownerId;
      return Response.json({ task: visible }, { status: 201 });
    }
    const updated = await updateStoredTask(id, (task) => {
      if (action === "cancel" && task.status === "queued") return { ...task, status: "cancelled", updatedAt: Date.now() };
      if (action === "interrupt" && task.status === "running") return { ...task, status: "interrupted", updatedAt: Date.now() };
      if (action === "prioritize" && task.status === "queued") return { ...task, priority: Date.now(), updatedAt: Date.now() };
      if (action === "retry" && (task.status === "failed" || task.status === "interrupted")) return prepareAdTaskRetry(task);
      return task;
    }, ownerId);
    if (!updated) return Response.json({ error: "任务不存在" }, { status: 404 });
    if (action === "retry") {
      updated.encryptedToken = await encryptToken(token);
      await saveStoredTask(updated);
    }
    const visible: Partial<typeof updated> = { ...updated };
    delete visible.encryptedToken;
    delete visible.ownerId;
    return Response.json({ task: visible });
  } catch (error) {
    return Response.json({ error: safeError(error) }, { status: 400 });
  }
}
