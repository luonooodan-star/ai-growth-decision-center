import { decryptToken, getMetaToken, safeError } from "../../../../../lib/meta";
import { executeMetaTask } from "../../../../../lib/meta-ads";
import { getStoredTask, listStoredTasks, saveStoredTask } from "../../../../../lib/ad-task-db";
import type { AdPublishTask } from "../../../../ad-tasks/task-store";

const activeTaskIds = new Set<string>();
const MAX_PARALLEL_TASKS = 3;

class TaskStopped extends Error {}

export async function POST(request: Request) {
  if (!await getMetaToken(request)) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });
  if (activeTaskIds.size >= MAX_PARALLEL_TASKS) return Response.json({ state: "busy" }, { status: 202 });
  const visibleTasks = await listStoredTasks();
  const candidate = visibleTasks.find((task: AdPublishTask) => (task.status === "running" || task.status === "queued") && !activeTaskIds.has(task.id));
  if (!candidate) return Response.json({ state: "idle" });
  activeTaskIds.add(candidate.id);
  const task = await getStoredTask(candidate.id);
  if (!task) {
    activeTaskIds.delete(candidate.id);
    return Response.json({ state: "idle" });
  }
  try {
    const token = await decryptToken(task.encryptedToken);
    if (!token) throw new Error("任务授权已失效，请重新连接 Meta 后重试任务");
    task.status = "running";
    task.updatedAt = Date.now();
    await saveStoredTask(task);
    const completed = await executeMetaTask(task, token, async (progress) => {
      const latest = await getStoredTask(progress.id);
      if (latest?.status === "interrupted" || latest?.status === "cancelled") {
        progress.status = latest.status;
        progress.updatedAt = Date.now();
        await saveStoredTask({ ...progress, encryptedToken: task.encryptedToken });
        throw new TaskStopped(latest.status === "interrupted" ? "任务已中断" : "任务已取消");
      }
      progress.updatedAt = Date.now();
      await saveStoredTask({ ...progress, encryptedToken: task.encryptedToken });
    });
    completed.status = completed.status === "running" ? "complete" : completed.status;
    completed.updatedAt = Date.now();
    await saveStoredTask({ ...completed, encryptedToken: task.encryptedToken });
    return Response.json({ state: completed.status, taskId: task.id });
  } catch (error) {
    if (error instanceof TaskStopped) return Response.json({ state: task.status, taskId: task.id }, { status: 202 });
    task.status = "failed";
    task.error = safeError(error);
    task.updatedAt = Date.now();
    await saveStoredTask(task);
    return Response.json({ state: "failed", taskId: task.id, error: task.error }, { status: 502 });
  } finally {
    activeTaskIds.delete(task.id);
  }
}
