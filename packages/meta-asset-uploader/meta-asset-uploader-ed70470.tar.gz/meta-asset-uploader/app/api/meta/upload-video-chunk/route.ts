import { getMetaToken, graph, graphAll, metaConfig, safeError } from "../../../../lib/meta";

type MetaVideoResponse = {
  upload_session_id?: string;
  video_id?: string;
  id?: string;
  start_offset?: string | number;
  end_offset?: string | number;
  error?: { message?: string };
};

async function metaVideoRequest(path: string, body: FormData) {
  const response = await fetch(`https://graph.facebook.com/${metaConfig().graphVersion}/${path}`, { method: "POST", body });
  const text = await response.text();
  let payload: MetaVideoResponse = {};
  try { payload = JSON.parse(text) as MetaVideoResponse; } catch { /* Use the HTTP status below. */ }
  if (!response.ok) throw new Error(payload.error?.message || `Meta 视频上传失败（${response.status}）`);
  return payload;
}

async function assertAccountAccess(accountId: string, token: string) {
  const accounts = await graphAll("me/adaccounts", token, "id,account_id");
  const allowed = new Set(accounts.map((account) => String(account.account_id || account.id || "").replace(/^act_/, "")));
  if (!allowed.has(accountId)) throw new Error("当前 Meta 用户无权访问所选广告账户");
}

export async function POST(request: Request) {
  const token = await getMetaToken(request);
  if (!token) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });

  try {
    const form = await request.formData();
    const action = String(form.get("action") || "");
    const accountId = String(form.get("account_id") || "").replace(/^act_/, "").trim();
    if (!accountId) return Response.json({ error: "请选择广告账户" }, { status: 400 });

    if (action === "start") {
      const size = Number(form.get("file_size"));
      if (!Number.isFinite(size) || size <= 0 || size > 400 * 1024 * 1024) return Response.json({ error: "视频大小无效，单个文件不能超过 400 MB" }, { status: 400 });
      await assertAccountAccess(accountId, token);
      const body = new FormData();
      body.set("access_token", token);
      body.set("upload_phase", "start");
      body.set("file_size", String(size));
      const payload = await metaVideoRequest(`act_${accountId}/advideos`, body);
      if (!payload.upload_session_id) throw new Error("Meta 未返回分片上传会话");
      return Response.json({ session_id: payload.upload_session_id, video_id: payload.video_id || payload.id || "", start_offset: String(payload.start_offset || 0), end_offset: String(payload.end_offset || size) });
    }

    const sessionId = String(form.get("session_id") || "");
    if (!sessionId) return Response.json({ error: "上传会话已失效，请重新上传" }, { status: 400 });
    if (action === "transfer") {
      const chunk = form.get("chunk");
      const startOffset = String(form.get("start_offset") || "");
      if (!(chunk instanceof File) || !startOffset) return Response.json({ error: "缺少视频分片" }, { status: 400 });
      const body = new FormData();
      body.set("access_token", token);
      body.set("upload_phase", "transfer");
      body.set("start_offset", startOffset);
      body.set("upload_session_id", sessionId);
      body.set("video_file_chunk", chunk, "chunk.bin");
      // Ad-account video resumable uploads keep every phase on the account's
      // advideos edge. Calling the session ID directly makes Meta treat it as
      // a generic video update and produces "target is required".
      const payload = await metaVideoRequest(`act_${accountId}/advideos`, body);
      return Response.json({ start_offset: String(payload.start_offset || 0), end_offset: String(payload.end_offset || 0) });
    }

    if (action === "finish") {
      const title = String(form.get("title") || "未命名视频");
      const videoId = String(form.get("video_id") || "");
      const body = new FormData();
      body.set("access_token", token);
      body.set("upload_phase", "finish");
      body.set("upload_session_id", sessionId);
      body.set("title", title);
      const payload = await metaVideoRequest(`act_${accountId}/advideos`, body);
      const id = payload.video_id || payload.id || videoId;
      if (!id) throw new Error("Meta 未返回视频 ID");
      let thumbnail = "";
      try {
        const video = await graph(id, token, { fields: "id,picture,thumbnails{uri,height,width}" });
        thumbnail = String(video.picture || ((video.thumbnails as { data?: { uri?: string }[] } | undefined)?.data?.[0]?.uri || ""));
      } catch { /* Meta may still be processing the video; ad creation retries this lookup. */ }
      return Response.json({ result: { filename: title, type: "video", media_id: id, video_id: id, thumbnail_url: thumbnail, account_id: accountId } });
    }

    return Response.json({ error: "不支持的分片上传操作" }, { status: 400 });
  } catch (error) {
    return Response.json({ error: safeError(error) }, { status: 502 });
  }
}
