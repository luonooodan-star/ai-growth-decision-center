import { metaConfig, metaConfigured, requestOrigin } from "../../../../lib/meta";

export async function GET(request: Request) {
  if (!metaConfigured()) return Response.json({ error: "Meta App 尚未配置" }, { status: 503 });
  const state = crypto.randomUUID();
  const config = metaConfig();
  const redirectUri = `${requestOrigin(request)}/api/meta/callback`;
  const url = new URL(`https://www.facebook.com/${config.graphVersion}/dialog/oauth`);
  url.searchParams.set("client_id", config.appId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("state", state);
  url.searchParams.set("scope", "public_profile,ads_read,ads_management,business_management,pages_show_list,pages_read_engagement");
  return new Response(null, { status: 302, headers: { location: url.toString(), "set-cookie": `meta_oauth_state=${state}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=600` } });
}
