import { getMetaToken, graph, graphAll, metaConfig, safeError } from "../../../../lib/meta";

const MAX_TOTAL_BYTES = 400 * 1024 * 1024;
const MAX_FILES = 50;

export async function POST(request: Request) {
  const token = await getMetaToken(request);
  if (!token) return Response.json({ error: "请先连接 Meta 账户" }, { status: 401 });
  try {
    const form = await request.formData();
    const requestedAccountIds = (() => {
      const raw = String(form.get("account_ids") || form.get("account_id") || "");
      try { return Array.isArray(JSON.parse(raw)) ? JSON.parse(raw) : [raw]; } catch { return [raw]; }
    })().map((id) => String(id).replace(/^act_/, "").trim()).filter(Boolean);
    const pageId = String(form.get("page_id") || "");
    const files = form.getAll("files").filter((item): item is File => item instanceof File);
    if (requestedAccountIds.length === 0 || files.length === 0) return Response.json({ error: "请选择广告账户和素材文件" }, { status: 400 });
    if (files.length > MAX_FILES) return Response.json({ error: `每次最多上传 ${MAX_FILES} 个文件` }, { status: 400 });
    if (files.reduce((total, file) => total + file.size, 0) > MAX_TOTAL_BYTES) return Response.json({ error: "单个上传任务的文件总量不能超过 400 MB" }, { status: 413 });

    const [accounts, pages] = await Promise.all([
      graphAll("me/adaccounts", token, "id,account_id,name"),
      pageId ? graphAll("me/accounts", token, "id,name") : Promise.resolve([]),
    ]);
    const allowedIds = new Set(accounts.map((account) => String(account.account_id || account.id || "").replace(/^act_/, "")));
    if (requestedAccountIds.some((accountId) => !allowedIds.has(accountId))) return Response.json({ error: "当前 Meta 用户无权访问所选广告账户" }, { status: 403 });
    if (pageId && !pages.some((page) => String(page.id) === pageId)) return Response.json({ error: "当前 Meta 用户无权访问该粉丝页" }, { status: 403 });

    const results = [];
    for (const file of files) {
      if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) throw new Error(`${file.name} 不是支持的图片或视频格式`);
      for (const accountId of requestedAccountIds) {
        const body = new FormData();
        body.set("access_token", token);
        if (file.type.startsWith("image/")) {
          body.set("filename", file, file.name);
          const response = await fetch(`https://graph.facebook.com/${metaConfig().graphVersion}/act_${accountId}/adimages`, { method: "POST", body });
          const payload = await response.json() as { images?: Record<string, { hash?: string; url?: string; url_128?: string; permalink_url?: string }>; error?: { message?: string } };
          if (!response.ok) throw new Error(payload.error?.message || `${file.name} 上传失败`);
          const image = Object.values(payload.images || {})[0];
          if (!image?.hash) throw new Error(`${file.name} 未返回 Image Hash`);
          results.push({ filename: file.name, type: "image", media_id: image.hash, picture_id: image.hash, image_hash: image.hash, thumbnail_url: image.url_128 || image.url || image.permalink_url, account_id: accountId, ...(pageId ? { page_id: pageId } : {}) });
        } else {
          body.set("source", file, file.name);
          body.set("title", file.name);
          const response = await fetch(`https://graph.facebook.com/${metaConfig().graphVersion}/act_${accountId}/advideos`, { method: "POST", body });
          const payload = await response.json() as { id?: string; error?: { message?: string } };
          if (!response.ok || !payload.id) throw new Error(payload.error?.message || `${file.name} 上传失败`);
          let thumbnail = "";
          try {
            const video = await graph(payload.id, token, { fields: "id,title,picture,thumbnails{uri,height,width}" });
            thumbnail = String(video.picture || ((video.thumbnails as { data?: { uri?: string }[] } | undefined)?.data?.[0]?.uri || ""));
          } catch { /* Meta may still be processing the video. */ }
          results.push({ filename: file.name, type: "video", media_id: payload.id, video_id: payload.id, thumbnail_url: thumbnail, account_id: accountId, ...(pageId ? { page_id: pageId } : {}) });
        }
      }
    }
    return Response.json({ results });
  } catch (error) {
    return Response.json({ error: safeError(error) }, { status: 502 });
  }
}
