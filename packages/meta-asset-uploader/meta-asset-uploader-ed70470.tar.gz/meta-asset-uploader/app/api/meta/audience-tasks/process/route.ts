import { decryptToken,getMetaToken,safeError } from "../../../../../lib/meta";
import { getAudienceTask,listAudienceTasks,saveAudienceTask } from "../../../../../lib/audience-task-db";
import { executeAudienceTask } from "../../../../../lib/meta-audiences";
import type { AudienceTask } from "../../../../audiences/audience-store";

const active=new Set<string>();
export async function POST(request:Request) {
  if (!await getMetaToken(request)) return Response.json({error:"请先连接 Meta 账户"},{status:401});
  const candidate=(await listAudienceTasks()).find((task:AudienceTask)=>task.status==="queued"&&!active.has(task.id));
  if (!candidate) return Response.json({state:"idle"}); active.add(candidate.id);
  const task=await getAudienceTask(candidate.id); if (!task) {active.delete(candidate.id);return Response.json({state:"idle"});}
  try {
    const token=await decryptToken(task.encryptedToken); if (!token) throw new Error("任务授权已失效，请重新连接 Meta 后新建任务");
    task.status="running";task.updatedAt=Date.now();await saveAudienceTask(task);
    const done=await executeAudienceTask(task,token,async(progress)=>saveAudienceTask({...progress,encryptedToken:task.encryptedToken}));
    await saveAudienceTask({...done,encryptedToken:task.encryptedToken}); return Response.json({state:done.status,taskId:done.id});
  } catch(error) {task.status="failed";task.error=safeError(error);task.updatedAt=Date.now();await saveAudienceTask(task);return Response.json({state:"failed",error:task.error},{status:502});}
  finally {active.delete(candidate.id);}
}
