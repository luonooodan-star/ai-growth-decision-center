import type { AudienceTask } from "../../../audiences/audience-store";
import { encryptToken,getMetaToken,graphAll,safeError } from "../../../../lib/meta";
import { getAudienceTask,listAudienceTasks,saveAudienceTask } from "../../../../lib/audience-task-db";
import { prepareAudienceTaskRetry } from "../../../../lib/audience-task-retry";
import { CLIENT_RECORD_RETENTION_MS } from "../../../../lib/retention";

export async function GET(request:Request) {
  if (!await getMetaToken(request)) return Response.json({error:"请先连接 Meta 账户"},{status:401});
  try { return Response.json({tasks:await listAudienceTasks(Date.now()-CLIENT_RECORD_RETENTION_MS)}); }
  catch(error) { return Response.json({error:safeError(error)},{status:500}); }
}
export async function POST(request:Request) {
  const token=await getMetaToken(request); if (!token) return Response.json({error:"请先连接 Meta 账户"},{status:401});
  try {
    const task=await request.json() as AudienceTask;
    if (!task.id || !task.accountIds?.length || !task.name?.trim()) throw new Error("受众任务缺少账户或受众名称");
    if (task.kind==="custom" && (!task.appId?.trim() || !task.appEvent?.trim() || !Number.isInteger(task.retentionDays) || task.retentionDays!<1 || task.retentionDays!>180)) throw new Error("自定义受众需要 App ID、投放事件和 1–180 天保留期");
    if (task.kind==="lookalike" && (!/^[A-Z]{2}$/.test(task.country||"") || !task.ratioPercent || task.ratioPercent<1 || task.ratioPercent>20 || task.accountIds.some((id)=>!task.sourceAudiences?.some((source)=>source.accountId===id)))) throw new Error("类似受众需要每账户同源受众、两位国家代码和 1–20% 比例");
    const accounts=await graphAll("me/adaccounts",token,"id,account_id"); const allowed=new Set(accounts.map((account)=>String(account.account_id||account.id||"").replace(/^act_/,"")));
    if (task.accountIds.some((id)=>!allowed.has(id))) throw new Error("当前 Meta 用户无权访问任务中的广告账户");
    const now=Date.now(); const stored={...task,status:"queued" as const,createdAt:task.createdAt||now,updatedAt:now,results:[],encryptedToken:await encryptToken(token)};
    await saveAudienceTask(stored); return Response.json({task:{...stored,encryptedToken:undefined}},{status:201});
  } catch(error) { return Response.json({error:safeError(error)},{status:400}); }
}
export async function PATCH(request:Request) {
  const token=await getMetaToken(request); if (!token) return Response.json({error:"请先连接 Meta 账户"},{status:401});
  try {
    const {id,action}=await request.json() as {id?:string;action?:"retry"};
    if (!id || action!=="retry") throw new Error("缺少受众任务重试参数");
    const task=await getAudienceTask(id); if (!task) return Response.json({error:"受众任务不存在"},{status:404});
    if (task.status!=="failed" && task.status!=="partial") throw new Error("只有失败或部分完成的受众任务可以重试");
    const retried={...prepareAudienceTaskRetry(task),encryptedToken:await encryptToken(token)};
    await saveAudienceTask(retried);
    const visible:Partial<typeof retried>={...retried};delete visible.encryptedToken;
    return Response.json({task:visible});
  } catch(error) { return Response.json({error:safeError(error)},{status:400}); }
}
