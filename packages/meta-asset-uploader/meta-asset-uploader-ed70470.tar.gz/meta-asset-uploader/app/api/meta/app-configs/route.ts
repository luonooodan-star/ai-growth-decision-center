import { deleteAppConfig, listAppConfigs, saveAppConfig } from "../../../../lib/app-config-db";
import type { SharedAppConfig } from "../../../../lib/app-config";
import { getMetaToken, safeError } from "../../../../lib/meta";

type AppConfigInput = Partial<Pick<SharedAppConfig, "id" | "name" | "metaAppId" | "googlePlayUrl" | "appleAppStoreUrl">>;

async function requireSession(request: Request) {
  return Boolean(await getMetaToken(request));
}

function normalize(input: AppConfigInput) {
  return {
    id: String(input.id || "").trim(),
    name: String(input.name || "").trim(),
    metaAppId: String(input.metaAppId || "").trim(),
    googlePlayUrl: String(input.googlePlayUrl || "").trim(),
    appleAppStoreUrl: String(input.appleAppStoreUrl || "").trim(),
  };
}

function validate(input: ReturnType<typeof normalize>) {
  if (!input.name) return "请填写 APP 名称。";
  if (input.name.length > 100) return "APP 名称最多 100 个字符。";
  if (!/^\d+$/.test(input.metaAppId)) return "Meta App ID 必须是纯数字。";
  if (!/^https:\/\/play\.google\.com\/store\/apps\//i.test(input.googlePlayUrl)) return "请填写完整的 Google Play 应用链接。";
  if (input.appleAppStoreUrl && !/^https:\/\/apps\.apple\.com\//i.test(input.appleAppStoreUrl)) return "Apple App Store 链接必须以 https://apps.apple.com/ 开头。";
  return "";
}

export async function GET(request: Request) {
  if (!await requireSession(request)) return Response.json({ error: "请先连接 Meta 账户。" }, { status: 401 });
  return Response.json({ configs: await listAppConfigs() });
}

export async function POST(request: Request) {
  if (!await requireSession(request)) return Response.json({ error: "请先连接 Meta 账户。" }, { status: 401 });
  try {
    const input = normalize(await request.json() as AppConfigInput);
    const error = validate(input);
    if (error) return Response.json({ error }, { status: 400 });
    const existing = await listAppConfigs();
    if (existing.some((item) => item.name.toLocaleLowerCase() === input.name.toLocaleLowerCase())) return Response.json({ error: "已经存在同名应用配置。" }, { status: 409 });
    if (existing.some((item) => item.metaAppId === input.metaAppId)) return Response.json({ error: "该 Meta App ID 已经配置。" }, { status: 409 });
    const now = Date.now();
    const config: SharedAppConfig = { id: crypto.randomUUID(), name: input.name, metaAppId: input.metaAppId, googlePlayUrl: input.googlePlayUrl, ...(input.appleAppStoreUrl ? { appleAppStoreUrl: input.appleAppStoreUrl } : {}), createdAt: now, updatedAt: now };
    await saveAppConfig(config);
    return Response.json({ config }, { status: 201 });
  } catch (error) { return Response.json({ error: safeError(error) }, { status: 500 }); }
}

export async function PATCH(request: Request) {
  if (!await requireSession(request)) return Response.json({ error: "请先连接 Meta 账户。" }, { status: 401 });
  try {
    const input = normalize(await request.json() as AppConfigInput);
    if (!input.id) return Response.json({ error: "缺少应用配置 ID。" }, { status: 400 });
    const error = validate(input);
    if (error) return Response.json({ error }, { status: 400 });
    const existing = await listAppConfigs();
    const current = existing.find((item) => item.id === input.id);
    if (!current) return Response.json({ error: "应用配置不存在。" }, { status: 404 });
    if (existing.some((item) => item.id !== input.id && item.name.toLocaleLowerCase() === input.name.toLocaleLowerCase())) return Response.json({ error: "已经存在同名应用配置。" }, { status: 409 });
    if (existing.some((item) => item.id !== input.id && item.metaAppId === input.metaAppId)) return Response.json({ error: "该 Meta App ID 已经配置。" }, { status: 409 });
    const config: SharedAppConfig = { ...current, name: input.name, metaAppId: input.metaAppId, googlePlayUrl: input.googlePlayUrl, ...(input.appleAppStoreUrl ? { appleAppStoreUrl: input.appleAppStoreUrl } : { appleAppStoreUrl: undefined }), updatedAt: Date.now() };
    await saveAppConfig(config);
    return Response.json({ config });
  } catch (error) { return Response.json({ error: safeError(error) }, { status: 500 }); }
}

export async function DELETE(request: Request) {
  if (!await requireSession(request)) return Response.json({ error: "请先连接 Meta 账户。" }, { status: 401 });
  const id = new URL(request.url).searchParams.get("id") || "";
  if (!id) return Response.json({ error: "缺少应用配置 ID。" }, { status: 400 });
  return await deleteAppConfig(id) ? Response.json({ ok: true }) : Response.json({ error: "应用配置不存在。" }, { status: 404 });
}

