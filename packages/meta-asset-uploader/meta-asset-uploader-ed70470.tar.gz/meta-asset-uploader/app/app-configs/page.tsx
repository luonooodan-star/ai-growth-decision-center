import type { Metadata } from "next";
import { AppConfigLibrary } from "./app-config-library";

export const metadata: Metadata = {
  title: "应用配置 | Meta Creative Vault",
  description: "集中维护广告配置所使用的 Meta 应用与应用商店链接。",
};

export default function AppConfigsPage() { return <AppConfigLibrary />; }

