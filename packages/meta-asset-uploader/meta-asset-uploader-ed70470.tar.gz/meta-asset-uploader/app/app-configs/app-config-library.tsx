"use client";

import { FormEvent, useEffect, useState } from "react";
import type { SharedAppConfig } from "../../lib/app-config";
import { readJsonResponse } from "../client-response";
import { TaskNavigation } from "../ad-tasks/task-list";
import "./app-configs.css";

type ConfigPayload = { configs?: SharedAppConfig[]; config?: SharedAppConfig; error?: string };

export function AppConfigLibrary() {
  const [configs, setConfigs] = useState<SharedAppConfig[]>([]);
  const [editing, setEditing] = useState<SharedAppConfig | null>(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { void refresh(); }, []);

  async function refresh() {
    setLoading(true);
    try {
      const response = await fetch("/api/meta/app-configs", { cache: "no-store" });
      const payload = await readJsonResponse<ConfigPayload>(response, "读取应用配置失败");
      if (!response.ok) throw new Error(payload.error || "读取应用配置失败");
      setConfigs(payload.configs || []);
      setMessage("");
    } catch (error) { setMessage(error instanceof Error ? error.message : "读取应用配置失败"); }
    finally { setLoading(false); }
  }

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    setMessage("");
    const form = new FormData(formElement);
    const body = {
      ...(editing ? { id: editing.id } : {}),
      name: String(form.get("name") || ""),
      metaAppId: String(form.get("meta_app_id") || ""),
      googlePlayUrl: String(form.get("google_play_url") || ""),
      appleAppStoreUrl: String(form.get("apple_app_store_url") || ""),
    };
    const response = await fetch("/api/meta/app-configs", { method: editing ? "PATCH" : "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const payload = await readJsonResponse<ConfigPayload>(response, "保存应用配置失败");
    if (!response.ok || !payload.config) return setMessage(payload.error || "保存应用配置失败");
    setEditing(null);
    formElement.reset();
    await refresh();
    setMessage(editing ? "应用配置已更新。" : "应用配置已保存，所有已登录用户现在都可以使用。 ");
  }

  async function remove(config: SharedAppConfig) {
    if (!window.confirm(`确定删除应用配置“${config.name}”吗？已经保存的广告模版不会被改动。`)) return;
    const response = await fetch(`/api/meta/app-configs?id=${encodeURIComponent(config.id)}`, { method: "DELETE" });
    const payload = await readJsonResponse<{ ok?: boolean; error?: string }>(response, "删除应用配置失败");
    if (!response.ok) return setMessage(payload.error || "删除应用配置失败");
    if (editing?.id === config.id) setEditing(null);
    await refresh();
    setMessage("应用配置已删除。已有广告模版仍保留保存时的 App 信息。 ");
  }

  return <main className="ad-shell">
    <TaskNavigation active="apps" />
    <section className="ad-hero compact-hero app-config-hero"><div><p className="eyebrow">SHARED APP LIBRARY</p><h1>应用资料，<br /><em>统一配置。</em></h1><p>应用配置保存在服务器并共享给所有已连接 Meta 的系统用户；广告模版只需选择应用名称。</p></div><div className="app-config-privacy"><b>登录后可见</b><span>未连接 Meta 的访问者无法读取或修改配置。</span></div></section>
    {message && <p className="task-form-message app-config-message">{message}</p>}
    <div className="app-config-layout">
      <form className="ad-card app-config-form" onSubmit={save} key={editing?.id || "new"}>
        <div className="card-kicker">01 · 应用资料</div><h2>{editing ? "修改应用配置" : "新增应用配置"}</h2>
        <label>APP 名称<input required name="name" maxLength={100} defaultValue={editing?.name} placeholder="例如：Data_AQ" /></label>
        <label>Meta App ID<input required name="meta_app_id" inputMode="numeric" pattern="[0-9]+" defaultValue={editing?.metaAppId} placeholder="Meta App Dashboard 中的数字 ID" /></label>
        <label>Google Play 链接<input required name="google_play_url" type="url" defaultValue={editing?.googlePlayUrl} placeholder="https://play.google.com/store/apps/details?id=…" /></label>
        <label>Apple App Store 链接 <small>iOS 14+ 配置使用，可选</small><input name="apple_app_store_url" type="url" defaultValue={editing?.appleAppStoreUrl} placeholder="https://apps.apple.com/app/…/id123456789" /></label>
        <p className="field-note">标准应用安装模版使用 Google Play 链接；iOS 14+ 模版会使用 Apple App Store 链接。保存后的广告模版会保留当时的完整快照。</p>
        <div className="app-config-form-actions">{editing && <button type="button" onClick={() => setEditing(null)}>取消修改</button>}<button className="primary-button" type="submit">{editing ? "保存修改" : "保存应用配置"}</button></div>
      </form>
      <section className="app-config-library">
        <div className="panel-head"><div className="step-label"><span>02</span>共享应用配置</div><span>{configs.length} 个应用</span></div>
        {loading ? <div className="empty-results">正在读取服务器配置…</div> : configs.length === 0 ? <div className="empty-results">还没有应用配置。请先在左侧新增。</div> : <div className="app-config-list">{configs.map((config) => <article key={config.id}><div><strong>{config.name}</strong><code>Meta App ID · {config.metaAppId}</code></div><dl><div><dt>Google Play</dt><dd title={config.googlePlayUrl}>{config.googlePlayUrl}</dd></div><div><dt>Apple App Store</dt><dd title={config.appleAppStoreUrl || ""}>{config.appleAppStoreUrl || "未配置"}</dd></div></dl><div className="app-config-actions"><button type="button" onClick={() => setEditing(config)}>修改</button><button className="danger" type="button" onClick={() => void remove(config)}>删除</button></div></article>)}</div>}
      </section>
    </div>
  </main>;
}
