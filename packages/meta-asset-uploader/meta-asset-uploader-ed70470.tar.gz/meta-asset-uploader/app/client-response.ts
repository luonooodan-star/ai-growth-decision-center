export async function readJsonResponse<T>(response: Response, fallback: string): Promise<T> {
  const text = await response.text();
  if (!text.trim()) throw new Error(`${fallback}（HTTP ${response.status}，服务端未返回 JSON）`);
  try { return JSON.parse(text) as T; }
  catch { throw new Error(`${fallback}（HTTP ${response.status}，服务端返回格式异常）`); }
}
