import { PageConfigList } from "./page-list";
export const metadata = { title: "粉丝页配置 | Meta Creative Vault" };
export default function PageConfigsPage() { return <PageConfigList />; }
