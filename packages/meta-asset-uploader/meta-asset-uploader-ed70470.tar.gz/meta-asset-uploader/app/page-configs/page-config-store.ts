export type PageConfigStatus = "active" | "frozen";

export type PageConfig = {
  id: string;
  pageIds: string[];
  pageNames: string[];
  /** Legacy single-Page fields kept optional for existing browser data. */
  pageId?: string;
  pageName?: string;
  accountIds: string[];
  accountNames: string[];
  status: PageConfigStatus;
  createdAt: number;
  updatedAt: number;
};

export type AccountPageStrategy = {
  accountId: string;
  pageIds: string[];
  pageNames: string[];
};

export const PAGE_CONFIG_STORAGE_KEY = "meta-creative-vault-page-configs-v1";

export function readPageConfigs(): PageConfig[] {
  try {
    const stored = JSON.parse(localStorage.getItem(PAGE_CONFIG_STORAGE_KEY) || "[]") as PageConfig[];
    return Array.isArray(stored) ? stored.map(normalizePageConfig) : [];
  } catch { return []; }
}

export function writePageConfigs(configs: PageConfig[]) {
  localStorage.setItem(PAGE_CONFIG_STORAGE_KEY, JSON.stringify(configs));
  window.dispatchEvent(new Event("page-configs-updated"));
}

export function buildAccountPageStrategies(accountIds: string[], configs = readPageConfigs()): AccountPageStrategy[] {
  return accountIds.map((accountId) => {
    const matches = configs.filter((config) => config.status === "active" && config.accountIds.includes(accountId));
    const pages = matches.flatMap((config) => config.pageIds.map((pageId, index) => ({ id: pageId, name: config.pageNames[index] || pageId })));
    const uniquePages = [...new Map(pages.map((page) => [page.id, page])).values()];
    return { accountId, pageIds: uniquePages.map((page) => page.id), pageNames: uniquePages.map((page) => page.name) };
  });
}

function normalizePageConfig(config: PageConfig): PageConfig {
  const pageIds = Array.isArray(config.pageIds) && config.pageIds.length ? config.pageIds : config.pageId ? [config.pageId] : [];
  const pageNames = Array.isArray(config.pageNames) && config.pageNames.length ? config.pageNames : config.pageName ? [config.pageName] : pageIds;
  return { ...config, pageIds, pageNames };
}

export function nextPageAfterFailure(pageIds: string[], failedPageId: string) {
  if (pageIds.length < 2) return pageIds[0] || "";
  const failedIndex = pageIds.indexOf(failedPageId);
  return pageIds[(failedIndex < 0 ? 0 : failedIndex + 1) % pageIds.length];
}
