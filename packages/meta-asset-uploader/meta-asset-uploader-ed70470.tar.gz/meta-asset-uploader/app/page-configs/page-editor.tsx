"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { TaskNavigation } from "../ad-tasks/task-list";
import { PageConfig, readPageConfigs, writePageConfigs } from "./page-config-store";
import "./page-configs.css";

type Account = { id: string; name: string };
type Page = { id: string; name: string };

export function PageConfigEditor() {
  const router = useRouter();
  const params = useSearchParams();
  const editId = params.get("edit") || "";
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [pages, setPages] = useState<Page[]>([]);
  const [configs, setConfigs] = useState<PageConfig[]>([]);
  const [selectedPageIds, setSelectedPageIds] = useState<string[]>([]);
  const [selectedAccountIds, setSelectedAccountIds] = useState<string[]>([]);
  const [pageSearch, setPageSearch] = useState("");
  const [accountSearch, setAccountSearch] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    void Promise.resolve().then(() => {
      const stored = readPageConfigs();
      setConfigs(stored);
      const editing = stored.find((config) => config.id === editId);
      if (editing) { setSelectedPageIds(editing.pageIds); setSelectedAccountIds(editing.accountIds); }
    });
    void fetch("/api/meta/assets", { cache: "no-store" }).then(async (response) => {
      const payload = await response.json() as { accounts?: Account[]; pages?: Page[]; error?: string };
      if (!response.ok) throw new Error(payload.error || "读取 Meta 资产失败");
      setAccounts(payload.accounts || []); setPages(payload.pages || []);
    }).catch((error) => setMessage(error instanceof Error ? error.message : "读取 Meta 资产失败"));
  }, [editId]);

  const selectedPages = useMemo(() => pages.filter((page) => selectedPageIds.includes(page.id)), [pages, selectedPageIds]);
  const selectedAccounts = useMemo(() => accounts.filter((account) => selectedAccountIds.includes(account.id)), [accounts, selectedAccountIds]);
  const pageMatches = useMemo(() => filterAssets(pages, pageSearch), [pages, pageSearch]);
  const accountMatches = useMemo(() => filterAssets(accounts, accountSearch), [accounts, accountSearch]);
  function togglePage(id: string) { setSelectedPageIds((current) => toggleId(current, id)); }
  function toggleAccount(id: string) { setSelectedAccountIds((current) => toggleId(current, id)); }

  function save(event: FormEvent) {
    event.preventDefault();
    if (!selectedPages.length) return setMessage("请至少选择一个粉丝页。");
    if (!selectedAccounts.length) return setMessage("请至少绑定一个广告账户。");
    const existing = configs.find((config) => config.id === editId); const now = Date.now();
    const saved: PageConfig = { id: existing?.id || crypto.randomUUID(), pageIds: selectedPages.map((page) => page.id), pageNames: selectedPages.map((page) => page.name), accountIds: selectedAccounts.map((account) => account.id), accountNames: selectedAccounts.map((account) => account.name), status: existing?.status || "active", createdAt: existing?.createdAt || now, updatedAt: now };
    writePageConfigs(existing ? configs.map((config) => config.id === existing.id ? saved : config) : [saved, ...configs]);
    router.push("/page-configs");
  }

  return <main className="ad-shell"><TaskNavigation active="pages" /><section className="ad-hero compact-hero"><div><p className="eyebrow">PAGE CONFIGURATION</p><h1>{editId ? "编辑" : "新增"}粉丝页，<br /><em>多对多绑定。</em></h1><p>多个粉丝页可以同时绑定多个广告账户；发布时按账户轮换可用粉丝页。</p></div><Link className="back-to-library" href="/page-configs">返回配置列表</Link></section><form className="page-config-form" onSubmit={save}>
    <AssetMultiSelector step="01 · 粉丝页" title="选择粉丝页（可多选）" label="筛选粉丝页" placeholder="输入粉丝页名称或 Page ID" search={pageSearch} onSearch={setPageSearch} matches={pageMatches} selectedIds={selectedPageIds} selected={selectedPages} idPrefix="Page ID " onToggle={togglePage} />
    <AssetMultiSelector step="02 · 广告账户" title="选择绑定账户（可多选）" label="筛选广告账户" placeholder="输入账户名称或 Account ID" search={accountSearch} onSearch={setAccountSearch} matches={accountMatches} selectedIds={selectedAccountIds} selected={selectedAccounts} idPrefix="act_" onToggle={toggleAccount} />
    <section className="page-config-save"><div><strong>保存粉丝页配置</strong><span>{selectedPages.length} 个粉丝页 × {selectedAccounts.length} 个广告账户；仅启用状态的配置进入发布轮换。</span></div><div><Link href="/page-configs">取消</Link><button type="submit">保存配置</button></div></section>{message && <p className="page-config-message">{message}</p>}
  </form></main>;
}

function AssetMultiSelector({ step, title, label, placeholder, search, onSearch, matches, selectedIds, selected, idPrefix, onToggle }: { step: string; title: string; label: string; placeholder: string; search: string; onSearch: (value: string) => void; matches: Array<{ id: string; name: string }>; selectedIds: string[]; selected: Array<{ id: string; name: string }>; idPrefix: string; onToggle: (id: string) => void }) {
  return <section className="ad-card"><div className="card-kicker">{step}</div><h2>{title}</h2><label>{label}<input value={search} onChange={(event) => onSearch(event.target.value)} placeholder={placeholder} /></label>{search.trim() && <div className="task-search-results">{matches.length ? matches.map((item) => <label key={item.id} title={item.name} aria-label={`${item.name} ${idPrefix}${item.id}`}><input type="checkbox" checked={selectedIds.includes(item.id)} onChange={() => onToggle(item.id)} /><span><b>{item.name}</b><small>{idPrefix}{item.id}</small></span></label>) : <p>未找到匹配结果</p>}</div>}{selected.length > 0 && <div className="task-selected-chips">{selected.map((item) => <button type="button" key={item.id} onClick={() => onToggle(item.id)}>{item.name} · {idPrefix}{item.id}<i>×</i></button>)}</div>}</section>;
}
function filterAssets<T extends { id: string; name: string }>(items: T[], search: string) { const query = search.trim().toLowerCase(); return query ? items.filter((item) => item.name.toLowerCase().includes(query) || item.id.includes(query)).slice(0, 15) : []; }
function toggleId(ids: string[], id: string) { return ids.includes(id) ? ids.filter((value) => value !== id) : [...ids, id]; }
