import { Suspense } from "react";
import { PageConfigEditor } from "../page-editor";
export const metadata = { title: "新增粉丝页配置 | Meta Creative Vault" };
export default function NewPageConfigPage() { return <Suspense fallback={<main className="ad-shell" /> }><PageConfigEditor /></Suspense>; }
