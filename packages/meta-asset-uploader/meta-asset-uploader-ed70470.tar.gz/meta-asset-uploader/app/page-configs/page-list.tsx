"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { TaskNavigation } from "../ad-tasks/task-list";
import { PageConfig, readPageConfigs, writePageConfigs } from "./page-config-store";
import "./page-configs.css";

export function PageConfigList() {
  const [configs, setConfigs] = useState<PageConfig[]>([]);
  useEffect(() => { const refresh = () => setConfigs(readPageConfigs()); refresh(); window.addEventListener("page-configs-updated", refresh); return () => window.removeEventListener("page-configs-updated", refresh); }, []);
  function setStatus(id: string, status: PageConfig["status"]) { const next = configs.map((config) => config.id === id ? { ...config, status, updatedAt: Date.now() } : config); writePageConfigs(next); setConfigs(next); }
  return <main className="ad-shell"><TaskNavigation active="pages" /><section className="ad-hero compact-hero task-library-hero"><div><p className="eyebrow">PAGE ACCOUNT ROUTING</p><h1>粉丝页与账户，<br /><em>多对多配对。</em></h1><p>多个粉丝页可绑定多个广告账户；发布广告时依次轮换使用当前启用的粉丝页。</p></div><Link className="new-config-button" href="/page-configs/new">+ 新增粉丝页配置</Link></section><section className="page-config-library"><div className="panel-head"><div className="step-label"><span>01</span>粉丝页配置</div><span>{configs.length} 条</span></div>{configs.length === 0 ? <div className="empty-results">还没有粉丝页配置。点击右上角开始绑定。</div> : <div className="page-config-list">{configs.map((config) => <article className="page-config-item" key={config.id}><div className="page-config-head"><div><strong>{config.pageNames.join("、")}</strong><span>{config.pageIds.length} 个粉丝页 × {config.accountIds.length} 个广告账户</span></div><b className={`page-config-status ${config.status}`}>{config.status === "active" ? "已启用" : "已冻结"}</b></div><div className="page-config-pages">{config.pageNames.map((name, index) => <span key={`${config.pageIds[index]}-${name}`}>{name} · Page ID {config.pageIds[index]}</span>)}</div><div className="page-config-accounts">{config.accountNames.map((name, index) => <span key={`${config.accountIds[index]}-${name}`}>{name} · act_{config.accountIds[index]}</span>)}</div><div className="page-config-actions"><Link href={`/page-configs/new?edit=${config.id}`}>编辑</Link>{config.status === "active" ? <button className="freeze" type="button" onClick={() => setStatus(config.id, "frozen")}>冻结</button> : <button type="button" onClick={() => setStatus(config.id, "active")}>重启</button>}</div></article>)}</div>}</section></main>;
}
