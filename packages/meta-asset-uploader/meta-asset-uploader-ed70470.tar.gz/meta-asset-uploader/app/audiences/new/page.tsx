import { Suspense } from "react";
import { AudienceEditor } from "../audience-editor";
export default function Page(){return <Suspense><AudienceEditor/></Suspense>;}
