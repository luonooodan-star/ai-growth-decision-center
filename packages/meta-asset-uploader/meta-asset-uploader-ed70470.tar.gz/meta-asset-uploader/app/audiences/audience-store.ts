export type AudienceKind = "custom" | "lookalike";
export type AudienceTaskStatus = "queued" | "running" | "complete" | "partial" | "failed";

export type AudienceResult = {
  accountId: string;
  accountName: string;
  audienceId: string;
  audienceName: string;
  kind: AudienceKind;
  status: "success" | "failed";
  error?: string;
};

export type AudienceTask = {
  id: string;
  createdAt: number;
  updatedAt: number;
  status: AudienceTaskStatus;
  kind: AudienceKind;
  accountIds: string[];
  accountNames: string[];
  name: string;
  description: string;
  appId?: string;
  appEvent?: string;
  retentionDays?: number;
  sourceAudiences?: AudienceResult[];
  country?: string;
  ratioPercent?: number;
  results: AudienceResult[];
  error?: string;
};
