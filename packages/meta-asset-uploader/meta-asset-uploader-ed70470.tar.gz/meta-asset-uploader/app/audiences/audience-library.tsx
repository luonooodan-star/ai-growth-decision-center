"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { AudienceTask } from "./audience-store";
import { TaskNavigation } from "../ad-tasks/task-list";
import { readJsonResponse } from "../client-response";
import "./audiences.css";
import "./audience-controls.css";

const labels: Record<AudienceTask["status"], string> = {
  queued: "排队中", running: "创建中", complete: "已完成", partial: "部分完成", failed: "失败",
};

export function AudienceLibrary() {
  const [tasks, setTasks] = useState<AudienceTask[]>([]);
  const [message, setMessage] = useState("");
  const [retryingId, setRetryingId] = useState("");

  useEffect(() => {
    let stopped = false;
    const run = async () => {
      await fetch("/api/meta/audience-tasks/process", { method: "POST" }).catch(() => undefined);
      try {
        const response = await fetch("/api/meta/audience-tasks", { cache: "no-store" });
        const payload = await readJsonResponse<{ tasks?: AudienceTask[]; error?: string }>(response, "读取受众任务失败");
        if (!response.ok) throw new Error(payload.error || "读取受众任务失败");
        if (!stopped) { setTasks(payload.tasks || []); setMessage(""); }
      } catch (error) {
        if (!stopped) setMessage(error instanceof Error ? error.message : "读取失败");
      }
    };
    void run();
    const timer = window.setInterval(() => void run(), 2500);
    return () => { stopped = true; window.clearInterval(timer); };
  }, []);

  async function retry(taskId: string) {
    setRetryingId(taskId); setMessage("");
    try {
      const response = await fetch("/api/meta/audience-tasks", {
        method: "PATCH", headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: taskId, action: "retry" }),
      });
      const payload = await readJsonResponse<{ task?: AudienceTask; error?: string }>(response, "重试受众任务失败");
      if (!response.ok || !payload.task) throw new Error(payload.error || "重试受众任务失败");
      setTasks((current) => current.map((task) => task.id === taskId ? payload.task! : task));
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "重试失败");
    } finally { setRetryingId(""); }
  }

  return <main className="ad-shell">
    <TaskNavigation active="audiences" />
    <section className="ad-hero compact-hero task-library-hero"><div><p className="eyebrow">AUDIENCE LIBRARY</p><h1>受众生成，<br /><em>任务与历史。</em></h1><p>按广告账户创建自定义受众或类似受众；成功结果可直接用于广告发布。</p></div><Link className="new-config-button" href="/audiences/new">+ 新建受众</Link></section>
    <section className="audience-library">
      <div className="panel-head"><div className="step-label"><span>01</span>受众创建任务</div><span>{tasks.length} 个任务</span></div>
      {tasks.length === 0 ? <div className="empty-results">还没有受众创建任务。</div> : <div className="audience-task-list">{tasks.map((task) => <article className="audience-task" key={task.id}>
        <div className="audience-task-head"><div><code>{task.id.slice(0, 8)}</code><strong>{task.name}</strong><span>{task.kind === "custom" ? "自定义受众" : "类似受众"} · {new Date(task.createdAt).toLocaleString("zh-CN", { hour12: false })}</span></div><div className="audience-task-controls"><b className={`audience-state ${task.status}`}>{labels[task.status]}</b>{(task.status === "failed" || task.status === "partial") && <button type="button" disabled={retryingId === task.id} onClick={() => void retry(task.id)}>{retryingId === task.id ? "正在重试…" : "重试失败项"}</button>}</div></div>
        {task.error && <p className="task-form-message">{task.error}</p>}
        <div className="audience-result-table"><table><thead><tr><th>受众名称</th><th>Audience ID</th><th>广告账户</th><th>结果</th></tr></thead><tbody>{task.results.length ? task.results.map((result, index) => <tr key={`${result.accountId}-${index}`}><td>{result.audienceName}</td><td><code>{result.audienceId || "—"}</code></td><td>{result.accountName}<small>act_{result.accountId}</small></td><td className={result.status}>{result.status === "success" ? "成功" : result.error || "失败"}</td></tr>) : <tr><td colSpan={4}>等待后台处理…</td></tr>}</tbody></table></div>
      </article>)}</div>}
      {message && <p className="task-form-message">{message}</p>}
    </section>
  </main>;
}
