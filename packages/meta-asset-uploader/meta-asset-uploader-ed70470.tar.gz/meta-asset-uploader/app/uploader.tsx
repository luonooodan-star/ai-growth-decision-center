"use client";

import { ChangeEvent, DragEvent, useEffect, useMemo, useRef, useState } from "react";
import { CLIENT_RECORD_RETENTION_MS } from "../lib/retention";
import { nextFolderTask, sourceFolderFromParent, sortFolderFiles } from "../lib/upload-folder-order";
import "./folder-upload.css";

type Account = { id: string; name: string; currency?: string; timezone_name?: string };
type Page = { id: string; name: string };
type UploadResult = { filename: string; type: "image" | "video"; media_id: string; video_id?: string; picture_id?: string; image_hash?: string; thumbnail_url?: string; account_id: string; page_id?: string; source_folder?: string; relative_path?: string; completed_at: number; upload_status: "成功" | "失败"; error?: string };
type QueueStatus = "queued" | "uploading" | "stopping" | "cancelled" | "complete" | "partial" | "failed";
type UploadFile = { file: File; sourceFolder: string; relativePath: string };
type QueueTask = { id: string; createdAt: Date; sourceFolder: string; files: UploadFile[]; accountIds: string[]; pageId: string; status: QueueStatus; completed: number; total: number; results: UploadResult[]; errors: string[] };
type WebkitEntry = { isFile: boolean; isDirectory: boolean; name: string; file?: (callback: (file: File) => void, error?: () => void) => void; createReader?: () => { readEntries: (callback: (entries: WebkitEntry[]) => void, error?: () => void) => void } };
type DataTransferItemWithEntry = DataTransferItem & { webkitGetAsEntry?: () => WebkitEntry | null };

const MAX_TASK_BYTES = 400 * 1024 * 1024;
const MAX_TASK_FILES = 50;
// Cloudflare Quick Tunnel rejects requests around 100 MB. Large videos are
// forwarded to Meta using its resumable-upload protocol in small requests.
// Keep all video requests well below the strictest observed Quick Tunnel cap.
// Larger files use Meta's resumable-upload protocol instead of a single POST.
const DIRECT_UPLOAD_LIMIT = 8 * 1024 * 1024;
const VIDEO_CHUNK_BYTES = 8 * 1024 * 1024;
const MAX_PARALLEL_TASKS = 1;
// A request that never returns must not hold one of the three queue slots
// forever. Meta uploads can be slow, especially for video chunks, so keep a
// generous limit and then record a useful, retryable failure.
const UPLOAD_REQUEST_TIMEOUT_MS = 2 * 60 * 1000;
const TASK_STORE_NAME = "meta-creative-vault";
const TASK_STORE_VERSION = 1;

class UploadStoppedError extends Error {}

async function uploadFetch(input: RequestInfo | URL, init: RequestInit, taskSignal?: AbortSignal) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), UPLOAD_REQUEST_TIMEOUT_MS);
  const stopForTask = () => controller.abort();
  taskSignal?.addEventListener("abort", stopForTask, { once: true });
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } catch (error) {
    if (taskSignal?.aborted) throw new UploadStoppedError("已停止上传");
    if (controller.signal.aborted) throw new Error("上传请求超过 2 分钟未响应，已跳过该素材并继续后续任务。请检查本机网络、代理或 Meta 连接后重新上传此素材。");
    throw error;
  } finally {
    window.clearTimeout(timeout);
    taskSignal?.removeEventListener("abort", stopForTask);
  }
}

function openTaskStore() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(TASK_STORE_NAME, TASK_STORE_VERSION);
    request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains("tasks")) request.result.createObjectStore("tasks", { keyPath: "id" }); };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function readStoredTasks(): Promise<QueueTask[]> {
  const database = await openTaskStore();
  return new Promise((resolve, reject) => {
    const request = database.transaction("tasks", "readonly").objectStore("tasks").getAll();
    request.onsuccess = () => { database.close(); resolve(request.result as QueueTask[]); };
    request.onerror = () => { database.close(); reject(request.error); };
  });
}

async function saveStoredTasks(tasks: QueueTask[]) {
  const database = await openTaskStore();
  return new Promise<void>((resolve, reject) => {
    const transaction = database.transaction("tasks", "readwrite");
    const store = transaction.objectStore("tasks");
    store.clear();
    tasks.forEach((task) => store.put(task));
    transaction.oncomplete = () => { database.close(); resolve(); };
    transaction.onerror = () => { database.close(); reject(transaction.error); };
  });
}

export function CreativeUploader() {
  const [connected, setConnected] = useState(false);
  const [profileName, setProfileName] = useState("");
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [pages, setPages] = useState<Page[]>([]);
  const [targetMode, setTargetMode] = useState<"single" | "multiple">("single");
  const [selectedAccountIds, setSelectedAccountIds] = useState<string[]>([]);
  const [accountSearch, setAccountSearch] = useState("");
  const [pageId, setPageId] = useState("");
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [folderCandidates, setFolderCandidates] = useState<UploadFile[]>([]);
  const [selectedFolders, setSelectedFolders] = useState<string[]>([]);
  const [results, setResults] = useState<UploadResult[]>([]);
  const [tasks, setTasks] = useState<QueueTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [dragging, setDragging] = useState(false);
  const [tasksRestored, setTasksRestored] = useState(false);
  const activeTaskIds = useRef(new Set<string>());
  const currentFolder = useRef("");
  const taskAbortControllers = useRef(new Map<string, AbortController>());

  useEffect(() => { void loadConnection(); }, []);
  useEffect(() => {
    void readStoredTasks().then((saved) => {
      const restored = saved.map((task) => ({ ...task, createdAt: new Date(task.createdAt), status: task.status === "uploading" || task.status === "stopping" ? "queued" : task.status }));
      setTasks(restored);
      setResults(restored.flatMap((task) => task.results || []).sort((a, b) => b.completed_at - a.completed_at));
    }).catch(() => setMessage("无法恢复本机任务记录。"))
      .finally(() => setTasksRestored(true));
  }, []);
  useEffect(() => { if (tasksRestored) void saveStoredTasks(tasks).catch(() => setMessage("任务记录保存失败，请检查浏览器存储空间。")); }, [tasks, tasksRestored]);
  useEffect(() => {
    if (!tasksRestored) return;
    const available = MAX_PARALLEL_TASKS - activeTaskIds.current.size;
    if (available <= 0) return;
    const next = nextFolderTask(tasks, currentFolder.current);
    (next ? [next] : []).forEach((task) => {
      currentFolder.current = task.sourceFolder;
      activeTaskIds.current.add(task.id);
      void processTask(task.id).finally(() => {
        activeTaskIds.current.delete(task.id);
        // Deleting from a ref does not itself cause React to run this queue
        // scheduler again. Touch state so the next waiting batch starts.
        setTasks((current) => [...current]);
      });
    });
  }, [tasks, tasksRestored]);

  async function loadConnection() {
    setLoading(true);
    try {
      const statusResponse = await fetch("/api/meta/status", { cache: "no-store" });
      const status = await statusResponse.json() as { connected?: boolean; name?: string };
      setConnected(Boolean(status.connected));
      setProfileName(status.name || "");
      if (!status.connected) return;
      const response = await fetch("/api/meta/assets", { cache: "no-store" });
      const payload = await response.json() as { accounts?: Account[]; pages?: Page[]; error?: string };
      if (!response.ok) throw new Error(payload.error || "读取账户失败");
      const loadedAccounts = payload.accounts || [];
      setAccounts(loadedAccounts);
      setPages(payload.pages || []);
      setSelectedAccountIds([]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "读取连接状态失败");
    } finally { setLoading(false); }
  }

  function makeUploadFile(file: File, relativePath?: string): UploadFile {
    const path = relativePath || (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
    const sourceFolder = path.includes("/") ? path.split("/")[0] : "单个素材";
    return { file, sourceFolder, relativePath: path };
  }

  function acceptFiles(incoming: UploadFile[]) {
    const supported = incoming.filter(({ file }) => file.type.startsWith("image/") || file.type.startsWith("video/"));
    const oversized = supported.filter(({ file }) => file.size > MAX_TASK_BYTES);
    if (oversized.length) { setMessage(`未添加素材：${oversized[0].file.name} 超过单文件 400 MB 限制，请先移除或压缩后重新选择。`); return; }
    const unsupported = incoming.length - supported.length;
    setFiles((current) => {
      const merged = [...current, ...supported].filter((item, index, list) => list.findIndex((candidate) => candidate.sourceFolder === item.sourceFolder && candidate.relativePath === item.relativePath && candidate.file.size === item.file.size && candidate.file.lastModified === item.file.lastModified) === index);
      setMessage(unsupported ? `已忽略 ${unsupported} 个非图片或视频文件。` : "");
      return merged;
    });
  }

  function onFileChange(event: ChangeEvent<HTMLInputElement>) { acceptFiles(Array.from(event.target.files || []).map((file) => makeUploadFile(file))); event.target.value = ""; }

  function onParentFolderChange(event: ChangeEvent<HTMLInputElement>) {
    const incoming = Array.from(event.target.files || []).map((file) => {
      const item = makeUploadFile(file);
      // Keep the full parent/child path as the source key so equal child names
      // from different parents never merge in the downstream material index.
      return { ...item, sourceFolder: sourceFolderFromParent(item.relativePath) };
    }).filter(({ file }) => file.type.startsWith("image/") || file.type.startsWith("video/"));
    setFolderCandidates(incoming);
    setSelectedFolders([...new Set(incoming.map((item) => item.sourceFolder))]);
    if (!incoming.length) setMessage("该目录内没有可上传的图片或视频。");
    event.target.value = "";
  }

  async function readDroppedEntry(entry: WebkitEntry, basePath = ""): Promise<UploadFile[]> {
    if (entry.isFile && entry.file) return new Promise((resolve) => entry.file!((file) => resolve([makeUploadFile(file, `${basePath}${entry.name}`)]), () => resolve([])));
    if (!entry.isDirectory || !entry.createReader) return [];
    const reader = entry.createReader();
    const entries: WebkitEntry[] = [];
    for (;;) {
      const batch = await new Promise<WebkitEntry[]>((resolve) => reader.readEntries!((next) => resolve(next), () => resolve([])));
      if (batch.length === 0) break;
      entries.push(...batch);
    }
    return (await Promise.all(entries.map((child) => readDroppedEntry(child, `${basePath}${entry.name}/`)))).flat();
  }

  async function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setDragging(false);
    if (!connected) return;
    const entries = Array.from(event.dataTransfer.items).map((item) => (item as DataTransferItemWithEntry).webkitGetAsEntry?.()).filter((entry): entry is WebkitEntry => Boolean(entry));
    const incoming = entries.length ? (await Promise.all(entries.map((entry) => readDroppedEntry(entry)))).flat() : Array.from(event.dataTransfer.files).map((file) => makeUploadFile(file));
    acceptFiles(incoming);
  }
  function setSingleAccount(accountId: string) { setTargetMode("single"); setSelectedAccountIds(accountId ? [accountId] : []); }
  function toggleAccount(accountId: string) { setTargetMode("multiple"); setSelectedAccountIds((current) => current.includes(accountId) ? current.filter((id) => id !== accountId) : [...current, accountId]); }

  function createTask() {
    if (!connected || files.length === 0 || selectedAccountIds.length === 0) return;
    const grouped = new Map<string, UploadFile[]>();
    files.forEach((item) => grouped.set(item.sourceFolder, [...(grouped.get(item.sourceFolder) || []), item]));
    const queued: QueueTask[] = [];
    grouped.forEach((folderFiles, sourceFolder) => {
      let batch: UploadFile[] = [];
      let bytes = 0;
      const addBatch = () => { if (batch.length) queued.push({ id: crypto.randomUUID(), createdAt: new Date(), sourceFolder, files: batch, accountIds: selectedAccountIds, pageId, status: "queued", completed: 0, total: batch.length * selectedAccountIds.length, results: [], errors: [] }); };
      sortFolderFiles(folderFiles).forEach((item) => {
        if (batch.length === MAX_TASK_FILES || bytes + item.file.size > MAX_TASK_BYTES) { addBatch(); batch = []; bytes = 0; }
        batch.push(item); bytes += item.file.size;
      });
      addBatch();
    });
    setTasks((current) => [...current, ...queued]);
    setFiles([]);
    setMessage(`已按 ${grouped.size} 个来源文件夹创建 ${queued.length} 个上传任务。`);
  }

  function cancelQueuedTask(taskId: string) {
    setTasks((current) => current.map((task) => task.id === taskId && task.status === "queued" ? { ...task, status: "cancelled" } : task));
    setMessage("已取消该等待任务。");
  }

  function stopUploadingTask(taskId: string) {
    const controller = taskAbortControllers.current.get(taskId);
    if (!controller) return;
    controller.abort();
    setTasks((current) => current.map((task) => task.id === taskId ? { ...task, status: "stopping" } : task));
    setMessage("正在停止当前上传；已完成的素材会保留。");
  }

  function retryFailedItems(taskId: string) {
    setTasks((current) => current.map((task) => {
      if (task.id !== taskId) return task;
      const successfulResults = task.results.filter((result) => result.upload_status === "成功");
      if (successfulResults.length === task.results.length) return task;
      return { ...task, status: "queued", completed: successfulResults.length, results: successfulResults, errors: [] };
    }));
    setMessage("已将失败项目重新加入等待队列；成功项目不会重复上传。历史失败记录会保留在结果表中，便于追踪。");
  }

  async function processTask(taskId: string) {
    const task = tasks.find((item) => item.id === taskId);
    if (!task) return;
    const controller = new AbortController();
    taskAbortControllers.current.set(taskId, controller);
    setTasks((current) => current.map((item) => item.id === taskId ? { ...item, status: "uploading" } : item));
    // Tasks are stored in IndexedDB. When the page is refreshed, keep every
    // previously confirmed file/account pair and continue only with work that
    // did not yet receive a result.
    const completedResults: UploadResult[] = [...(task.results || [])];
    const errors: string[] = [...(task.errors || [])];
    const completedKeys = new Set(completedResults.map((result) => `${result.relative_path || result.filename}\u0000${result.account_id}`));
    let completed = completedResults.length;
    let stopped = false;
    for (const item of task.files) {
      const { file } = item;
      for (const accountId of task.accountIds) {
        if (controller.signal.aborted) { stopped = true; break; }
        if (completedKeys.has(`${item.relativePath}\u0000${accountId}`)) continue;
        const form = new FormData();
        form.set("account_ids", JSON.stringify([accountId]));
        if (task.pageId) form.set("page_id", task.pageId);
        form.append("files", file, file.name);
        try {
          if (file.type.startsWith("video/") && file.size > DIRECT_UPLOAD_LIMIT) {
            const result = await uploadLargeVideo(file, accountId, controller.signal);
            completedResults.push({ ...result, source_folder: item.sourceFolder, relative_path: item.relativePath, completed_at: Date.now(), upload_status: "成功" as const });
          } else {
            const response = await uploadFetch("/api/meta/upload", { method: "POST", body: form }, controller.signal);
            const payload = await readUploadResponse(response);
            if (!response.ok) throw new Error(payload.error || `${file.name} 上传失败`);
            completedResults.push(...(payload.results || []).map((result) => ({ ...result, source_folder: item.sourceFolder, relative_path: item.relativePath, completed_at: Date.now(), upload_status: "成功" as const })));
          }
        } catch (error) {
          if (error instanceof UploadStoppedError || controller.signal.aborted) { stopped = true; break; }
          const failure = error instanceof Error ? error.message : "上传失败";
          errors.push(`${file.name} · act_${accountId}：${failure}`);
          completedResults.push({ filename: file.name, type: file.type.startsWith("video/") ? "video" : "image", media_id: "", account_id: accountId, source_folder: item.sourceFolder, relative_path: item.relativePath, completed_at: Date.now(), upload_status: "失败", error: failure });
        }
        completed += 1;
        setTasks((current) => current.map((item) => item.id === taskId ? { ...item, completed, results: [...completedResults], errors: [...errors] } : item));
      }
      if (stopped) break;
    }
    taskAbortControllers.current.delete(taskId);
    setResults((current) => [...completedResults, ...current.filter((result) => !completedResults.some((completedResult) => completedResult.completed_at === result.completed_at && completedResult.account_id === result.account_id))].sort((a, b) => b.completed_at - a.completed_at));
    setTasks((current) => current.map((item) => item.id === taskId ? { ...item, completed, results: completedResults, errors, status: stopped ? "cancelled" : errors.length === 0 ? "complete" : completedResults.length ? "partial" : "failed" } : item));
  }

  async function readUploadResponse(response: Response) {
    const text = await response.text();
    try { return JSON.parse(text) as { results?: UploadResult[]; error?: string }; }
    catch { return { error: response.status === 413 ? "文件超过公网通道的单次上传限制" : (text || `上传失败（${response.status}）`) }; }
  }

  async function uploadLargeVideo(file: File, accountId: string, signal: AbortSignal): Promise<UploadResult> {
    const startForm = new FormData();
    startForm.set("action", "start");
    startForm.set("account_id", accountId);
    startForm.set("file_size", String(file.size));
    const startResponse = await uploadFetch("/api/meta/upload-video-chunk", { method: "POST", body: startForm }, signal);
    const start = await readUploadResponse(startResponse) as { session_id?: string; video_id?: string; start_offset?: string; end_offset?: string; error?: string };
    if (!startResponse.ok || !start.session_id) throw new Error(start.error || "无法创建视频上传会话");
    let offset = Number(start.start_offset || 0);
    while (offset < file.size) {
      const suggestedEnd = Number(start.end_offset || 0);
      const end = suggestedEnd > offset ? Math.min(suggestedEnd, file.size) : Math.min(offset + VIDEO_CHUNK_BYTES, file.size);
      const chunkForm = new FormData();
      chunkForm.set("action", "transfer");
      chunkForm.set("account_id", accountId);
      chunkForm.set("session_id", start.session_id);
      chunkForm.set("start_offset", String(offset));
      chunkForm.set("chunk", file.slice(offset, end), `${file.name}.part`);
      const transferResponse = await uploadFetch("/api/meta/upload-video-chunk", { method: "POST", body: chunkForm }, signal);
      const transfer = await readUploadResponse(transferResponse) as { start_offset?: string; end_offset?: string; error?: string };
      if (!transferResponse.ok) throw new Error(transfer.error || "视频分片上传失败");
      const nextOffset = Number(transfer.start_offset || end);
      if (!Number.isFinite(nextOffset) || nextOffset <= offset) throw new Error("Meta 未确认视频分片，请重新上传");
      offset = nextOffset;
      start.end_offset = transfer.end_offset || String(Math.min(offset + VIDEO_CHUNK_BYTES, file.size));
    }
    const finishForm = new FormData();
    finishForm.set("action", "finish");
    finishForm.set("account_id", accountId);
    finishForm.set("session_id", start.session_id);
    finishForm.set("video_id", start.video_id || "");
    finishForm.set("title", file.name);
    const finishResponse = await uploadFetch("/api/meta/upload-video-chunk", { method: "POST", body: finishForm }, signal);
    const finish = await readUploadResponse(finishResponse) as { result?: UploadResult; error?: string };
    if (!finishResponse.ok || !finish.result) throw new Error(finish.error || "Meta 未确认视频上传");
    return finish.result;
  }

  const selectedAccounts = useMemo(() => accounts.filter((account) => selectedAccountIds.includes(account.id)), [accounts, selectedAccountIds]);
  const accountSearchMatches = useMemo(() => {
    const query = accountSearch.trim().toLowerCase();
    if (!query) return [];
    return accounts.filter((account) => account.name.toLowerCase().includes(query) || account.id.includes(query)).slice(0, 8);
  }, [accounts, accountSearch]);
  const taskBytes = files.reduce((total, item) => total + item.file.size, 0);
  const historyCutoff = Date.now() - CLIENT_RECORD_RETENTION_MS;
  // Keep the complete IndexedDB history as the permanent material index used
  // by ad-task search. Only the visible record lists are limited to 7 days.
  const visibleResults = results.filter((result) => result.completed_at >= historyCutoff);
  const visibleTasks = tasks.filter((task) => task.status === "queued" || task.status === "uploading" || task.status === "stopping" || task.createdAt.getTime() >= historyCutoff);

  return <main className="shell">
    <header className="topbar"><div className="brand"><span className="brand-mark">M</span><span>Meta Creative Vault</span></div><nav className="top-nav"><a className="active" href="/">素材库</a><a href="/app-configs">应用配置</a><a href="/ad-upload">广告配置模版</a><a href="/page-configs">粉丝页配置</a><a href="/audiences">受众生成库</a><a href="/ad-tasks">广告发布任务</a></nav><div className={`connection ${connected ? "online" : ""}`}><span className="status-dot" />{connected ? `已连接 ${profileName}` : "未连接 Meta"}</div></header>
    <section className="hero"><div><p className="eyebrow">AD ASSET WORKSPACE</p><h1>素材一次上传，<br /><em>ID 即刻归档。</em></h1><p className="hero-copy">连接你的个人 Meta 账户，选择单个或多个广告账户。每次提交都会成为独立任务，依序完成并保留原始文件名。</p></div><div className="hero-stat"><strong>{accounts.length || "—"}</strong><span>可访问广告账户</span></div></section>
    <section className="workspace">
      <aside className="control-panel"><div className="step-label"><span>01</span>授权与目标</div>
        {!connected ? <div className="connect-card"><div className="meta-glyph">f</div><h2>连接 Meta 账户</h2><p>授权广告账户、粉丝页及素材管理权限。</p><a className="primary-button" href="/api/meta/connect">使用 Meta 登录</a></div> : <div className="fields">
          <div className="target-mode"><span>本次任务投放至</span><div><button className={targetMode === "single" ? "selected" : ""} onClick={() => setTargetMode("single")}>单个账户</button><button className={targetMode === "multiple" ? "selected" : ""} onClick={() => setTargetMode("multiple")}>多个账户</button></div></div>
          {targetMode === "single" ? <div className="single-account-search"><label><span>筛选广告账户</span><input value={accountSearch} onChange={(event) => setAccountSearch(event.target.value)} placeholder="输入账户名称或 Account ID" disabled={loading} /></label>{accountSearch.trim() && <div className="search-results">{accountSearchMatches.length ? accountSearchMatches.map((account) => <button key={account.id} title={account.name} onClick={() => { setSingleAccount(account.id); setAccountSearch(""); }}><strong title={account.name}>{account.name}</strong><small>act_{account.id}</small></button>) : <p>未找到匹配的广告账户</p>}</div>}{selectedAccounts[0] && <div className="selected-account" title={selectedAccounts[0].name}><div><strong>{selectedAccounts[0].name}</strong><small>act_{selectedAccounts[0].id}</small></div><button onClick={() => setSelectedAccountIds([])} aria-label="清除已选账户">×</button></div>}</div> : <div className="multi-account-search"><label><span>筛选广告账户 <small>可多选</small></span><input value={accountSearch} onChange={(event) => setAccountSearch(event.target.value)} placeholder="输入账户名称或 Account ID" disabled={loading} /></label>{accountSearch.trim() && <div className="search-results multi-search-results">{accountSearchMatches.length ? accountSearchMatches.map((account) => <label key={account.id} title={account.name}><input type="checkbox" checked={selectedAccountIds.includes(account.id)} onChange={() => toggleAccount(account.id)} /><strong title={account.name}>{account.name}</strong><small>act_{account.id}</small></label>) : <p>未找到匹配的广告账户</p>}</div>}{selectedAccounts.length > 0 && <div className="selected-account-list">{selectedAccounts.map((account) => <div className="selected-account" key={account.id} title={account.name}><div><strong>{account.name}</strong><small>act_{account.id}</small></div><button onClick={() => toggleAccount(account.id)} aria-label={`移除 ${account.name}`}>×</button></div>)}</div>}</div>}
          <label><span>关联粉丝页 <small>可选</small></span><select value={pageId} onChange={(event) => setPageId(event.target.value)}><option value="">不关联粉丝页</option>{pages.map((page) => <option key={page.id} value={page.id}>{page.name}</option>)}</select></label>
          <div className="account-note"><span>本次任务目标</span><strong>{selectedAccounts.length ? selectedAccounts.map((account) => account.name).join("、") : "请选择账户"}</strong><small>{selectedAccounts.length ? `${selectedAccounts.length} 个广告账户` : ""}</small></div><a className="text-link" href="/api/meta/disconnect">断开并更换 Meta 账户</a>
        </div>}
      </aside>
      <div className="upload-panel"><div className="panel-head"><div className="step-label"><span>02</span>上传素材</div><span>{files.length} 个 · {(taskBytes / 1024 / 1024).toFixed(1)} MB · {new Set(files.map((item) => item.sourceFolder)).size} 个来源文件夹</span></div>
        <div className={`dropzone ${dragging ? "dragging" : ""} ${!connected ? "disabled" : ""}`} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={onDrop}><div className="upload-icon">↑</div><h2>拖入多个文件夹、图片或视频</h2><p>按文件夹依次上传，文件夹内按路径和文件名排序；超过 50 个或 400 MB 自动拆批，不丢弃素材。</p><div className="browse-actions"><label className="browse">选择本地文件<input type="file" accept="image/*,video/*" multiple onChange={onFileChange} disabled={!connected} /></label><label className="browse">追加一个文件夹<input type="file" accept="image/*,video/*" multiple webkitdirectory="" onChange={onFileChange} disabled={!connected} /></label><label className="browse">批量选择文件夹<input type="file" accept="image/*,video/*" multiple webkitdirectory="" onChange={onParentFolderChange} disabled={!connected} /></label></div><p>批量选择：先打开包含这些文件夹的父目录，再勾选需要上传的子文件夹。也可以在 Finder 中多选文件夹一起拖入。</p></div>
        {folderCandidates.length > 0 && <section className="folder-selection"><div className="panel-head"><strong>选择要添加的文件夹</strong><button type="button" onClick={() => setSelectedFolders([...new Set(folderCandidates.map((item) => item.sourceFolder))])}>全选</button><button type="button" onClick={() => setSelectedFolders([])}>清空选择</button></div><div className="folder-selection-list">{[...new Set(folderCandidates.map((item) => item.sourceFolder))].map((folder) => <label key={folder}><input type="checkbox" checked={selectedFolders.includes(folder)} onChange={() => setSelectedFolders((current) => current.includes(folder) ? current.filter((value) => value !== folder) : [...current, folder])} /><span>{folder}</span><small>{folderCandidates.filter((item) => item.sourceFolder === folder).length} 个素材</small></label>)}</div><div className="folder-selection-actions"><button type="button" onClick={() => { setFolderCandidates([]); setSelectedFolders([]); }}>取消</button><button type="button" disabled={!connected || !selectedFolders.length} onClick={() => { acceptFiles(folderCandidates.filter((item) => selectedFolders.includes(item.sourceFolder))); setFolderCandidates([]); setSelectedFolders([]); }}>添加选中的 {selectedFolders.length} 个文件夹</button></div></section>}
        {files.length > 0 && <div className="folder-upload-order">上传顺序：{[...new Set(files.map((item) => item.sourceFolder))].join(" → ")}。同一文件夹的拆分批次会连续处理；失败项记录后继续，后续重试会重新排队。</div>}
        {files.length > 0 && <div className="file-list">{files.map((item, index) => <FileRow key={`${item.relativePath}-${item.file.size}-${item.file.lastModified}`} item={item} onRemove={() => setFiles((current) => current.filter((_, itemIndex) => itemIndex !== index))} />)}</div>}
        <button className="upload-button" onClick={createTask} disabled={!connected || selectedAccountIds.length === 0 || files.length === 0}>{`创建上传任务${files.length ? ` · ${files.length} 个素材` : ""}`}</button>{message && <p className="message">{message}</p>}
      </div>
    </section>
    <section className="results-section"><div className="panel-head"><div className="step-label"><span>03</span>上传结果</div><span>{visibleResults.length ? `${visibleResults.length} 条结果 · 仅展示近 7 天` : "等待上传"}</span></div>{visibleResults.length === 0 ? <div className="empty-results">上传完成后，近 7 天的来源文件夹、素材原文件名、素材 ID、账户 ID 与上传结果会显示在这里；完整素材索引仍可用于广告任务筛选。</div> : <div className="result-table-wrap"><table className="result-table"><thead><tr><th>完成时间</th><th>来源文件夹</th><th>素材原文件名</th><th>素材 ID</th><th>账户 ID</th><th>上传结果</th></tr></thead><tbody>{visibleResults.map((result, index) => <ResultRow key={`${result.account_id}-${result.media_id || result.filename}-${result.completed_at}-${index}`} result={result} />)}</tbody></table></div>}</section>
    <section className="queue-section"><div className="panel-head"><div className="step-label"><span>04</span>等待队列</div><span>{visibleTasks.some((task) => task.status === "queued" || task.status === "uploading" || task.status === "stopping") ? "按文件夹顺序处理 · 同时上传 1 条素材任务" : "近 7 天暂无等待任务"}</span></div>{visibleTasks.length === 0 ? <div className="empty-results">同一个文件夹的素材及拆分批次依次处理完毕后，再处理下一个文件夹。页面只展示近 7 天记录，历史素材仍可被筛选。</div> : <div className="task-list">{visibleTasks.map((task) => <TaskCard key={task.id} task={task} accounts={accounts} onCancelQueue={cancelQueuedTask} onStop={stopUploadingTask} onRetryFailed={retryFailedItems} />)}</div>}</section>
  </main>;
}

function FileRow({ item, onRemove }: { item: UploadFile; onRemove: () => void }) { const preview = useMemo(() => URL.createObjectURL(item.file), [item.file]); return <div className="file-row"><div className="file-thumb">{item.file.type.startsWith("image/") ? <img src={preview} alt="" /> : <video src={preview} muted />}</div><div><strong title={item.relativePath}>{item.file.name}</strong><span title={item.relativePath}>{item.relativePath} · {item.file.type.startsWith("video/") ? "视频" : "图片"} · {(item.file.size / 1024 / 1024).toFixed(2)} MB</span></div><button aria-label={`移除 ${item.file.name}`} onClick={onRemove}>×</button></div>; }
function TaskCard({ task, accounts, onCancelQueue, onStop, onRetryFailed }: { task: QueueTask; accounts: Account[]; onCancelQueue: (taskId: string) => void; onStop: (taskId: string) => void; onRetryFailed: (taskId: string) => void }) { const labels = accounts.filter((account) => task.accountIds.includes(account.id)).map((account) => account.name).join("、"); const progress = task.total ? Math.round(task.completed / task.total * 100) : 0; const hasFailures = task.results.some((result) => result.upload_status === "失败"); const statusText: Record<QueueStatus, string> = { queued: "等待中", uploading: "上传中", stopping: "正在停止", cancelled: "已取消", complete: "已完成", partial: "部分完成", failed: "失败" }; return <article className="task-card"><div className="task-top"><div><strong>任务 {task.createdAt.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}</strong><span title={task.sourceFolder}>来源文件夹：{task.sourceFolder} · {task.files.length} 个素材 → {labels || `${task.accountIds.length} 个账户`}</span></div><b className={`task-status ${task.status}`}>{statusText[task.status]}</b></div><div className="progress-track"><i style={{ width: `${progress}%` }} /></div><div className="task-bottom"><span>{task.completed} / {task.total} 个上传项</span><span>{progress}%</span></div><div className="task-actions">{task.status === "queued" && <button onClick={() => onCancelQueue(task.id)}>取消排队</button>}{task.status === "uploading" && <button className="danger" onClick={() => onStop(task.id)}>停止上传</button>}{hasFailures && task.status !== "uploading" && task.status !== "stopping" && <button onClick={() => onRetryFailed(task.id)}>重试失败项</button>}</div>{task.errors.length > 0 && <p className="task-error">{task.errors[task.errors.length - 1]}</p>}</article>; }
function ResultRow({ result }: { result: UploadResult }) { const id = result.video_id || result.picture_id || result.media_id; return <tr><td>{new Date(result.completed_at).toLocaleString("zh-CN", { hour12: false })}</td><td title={result.relative_path || result.source_folder}>{result.source_folder || "单个素材"}</td><td title={result.relative_path || result.filename}>{result.filename}</td><td>{id ? <button className="id-copy" onClick={() => navigator.clipboard.writeText(id)} title="点击复制素材 ID">{id}</button> : "—"}</td><td>act_{result.account_id}</td><td><span className={`upload-result ${result.upload_status === "成功" ? "success" : "failed"}`}>{result.upload_status}</span>{result.error && <small title={result.error}>{result.error}</small>}</td></tr>; }
