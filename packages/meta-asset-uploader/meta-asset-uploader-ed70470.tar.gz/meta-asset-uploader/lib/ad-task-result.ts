import type { AdPublishTask } from "../app/ad-tasks/task-store";

type ExecutionResult = NonNullable<AdPublishTask["result"]>;

export function normalizeAdTaskResult(task: Pick<AdPublishTask, "materials" | "result">): ExecutionResult {
  const current = task.result;
  const totalAds = Array.isArray(task.materials) ? task.materials.length : 0;
  return {
    campaignIds: Array.isArray(current?.campaignIds) ? current.campaignIds : [],
    adSetIds: Array.isArray(current?.adSetIds) ? current.adSetIds : [],
    creativeIds: Array.isArray(current?.creativeIds) ? current.creativeIds : [],
    adIds: Array.isArray(current?.adIds) ? current.adIds : [],
    completedAds: Number.isFinite(current?.completedAds) ? current!.completedAds : 0,
    totalAds,
    completedMaterialKeys: Array.isArray(current?.completedMaterialKeys) ? current.completedMaterialKeys : [],
    logs: Array.isArray(current?.logs) ? current.logs : [],
  };
}
