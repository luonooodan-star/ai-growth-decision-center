import type { AdPublishTask } from "../app/ad-tasks/task-store";

export function plannedAdTaskSteps(task: { accountIds?: string[]; materials?: { accountId: string }[]; adSetsPerCampaign: number; adsPerAdSet: number }) {
  const adsPerAdSet = Math.max(1, Number(task.adsPerAdSet) || 1);
  const adSetsPerCampaign = Math.max(1, Number(task.adSetsPerCampaign) || 1);
  let campaigns = 0;
  let adSets = 0;
  let ads = 0;
  for (const accountId of task.accountIds || []) {
    const accountAds = (task.materials || []).filter((material) => material.accountId === accountId).length;
    if (!accountAds) continue;
    const accountAdSets = Math.ceil(accountAds / adsPerAdSet);
    ads += accountAds;
    adSets += accountAdSets;
    campaigns += Math.ceil(accountAdSets / adSetsPerCampaign);
  }
  return { campaigns, adSets, ads, total: campaigns + adSets + ads };
}

export function adTaskProgress(task: Pick<AdPublishTask, "accountIds" | "materials" | "adSetsPerCampaign" | "adsPerAdSet" | "result" | "progressAttempt">) {
  const attempt = task.progressAttempt;
  const planned = attempt
    ? { campaigns: attempt.campaigns, adSets: attempt.adSets, ads: attempt.ads, total: attempt.total }
    : plannedAdTaskSteps(task);
  const completed = Math.min(planned.total, attempt
    ? Math.max(0, (task.result?.campaignIds?.length || 0) - attempt.baselineCampaigns)
      + Math.max(0, (task.result?.adSetIds?.length || 0) - attempt.baselineAdSets)
      + Math.max(0, (task.result?.completedAds || 0) - attempt.baselineAds)
    : (task.result?.campaignIds?.length || 0) + (task.result?.adSetIds?.length || 0) + (task.result?.completedAds || 0));
  return { ...planned, completed, percent: planned.total ? Math.round(completed / planned.total * 100) : 0 };
}

function materialKey(material: AdPublishTask["materials"][number]) {
  return `${material.accountId}:${material.mediaType}:${material.mediaId}`;
}

export function prepareAdTaskRetry(task: AdPublishTask, now = Date.now()): AdPublishTask {
  const current = task.result;
  const result = {
    campaignIds: Array.isArray(current?.campaignIds) ? current.campaignIds : [],
    adSetIds: Array.isArray(current?.adSetIds) ? current.adSetIds : [],
    creativeIds: Array.isArray(current?.creativeIds) ? current.creativeIds : [],
    adIds: Array.isArray(current?.adIds) ? current.adIds : [],
    completedAds: Number.isFinite(current?.completedAds) ? current!.completedAds : 0,
    totalAds: task.materials.length,
    completedMaterialKeys: Array.isArray(current?.completedMaterialKeys) ? current.completedMaterialKeys : [],
    logs: Array.isArray(current?.logs) ? current.logs : [],
  };
  const completedKeys = new Set(result.completedMaterialKeys);
  const remainingMaterials = task.materials.filter((material) => !completedKeys.has(materialKey(material)));
  const planned = plannedAdTaskSteps({ ...task, materials: remainingMaterials });
  return {
    ...task,
    status: "queued",
    error: undefined,
    priority: now,
    updatedAt: now,
    result,
    progressAttempt: {
      baselineCampaigns: result.campaignIds.length,
      baselineAdSets: result.adSetIds.length,
      baselineAds: result.completedAds,
      ...planned,
    },
  };
}
