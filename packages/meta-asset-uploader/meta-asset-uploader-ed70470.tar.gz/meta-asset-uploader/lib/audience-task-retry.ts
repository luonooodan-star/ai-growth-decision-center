import type { AudienceTask } from "../app/audiences/audience-store";

export function prepareAudienceTaskRetry(task: AudienceTask, updatedAt = Date.now()): AudienceTask {
  return {
    ...task,
    status: "queued",
    updatedAt,
    results: (task.results || []).filter((result) => result.status === "success" && result.audienceId),
    error: undefined,
  };
}
