import { env } from "cloudflare:workers";
import type { AudienceResult, AudienceTask } from "../app/audiences/audience-store";
import { SERVER_RECORD_RETENTION_MS } from "./retention";

type StoredAudienceTask = AudienceTask & { encryptedToken: string };
type Row = { id:string; status:AudienceTask["status"]; created_at:number; updated_at:number; payload:string; result:string; error:string|null; encrypted_token:string };
const memory = new Map<string, StoredAudienceTask>();
let initialized: Promise<void> | null = null;
let lastPrunedAt = 0;

function database() { return (env as unknown as { DB?: D1Database }).DB; }
async function ensureTable(db:D1Database) {
  initialized ||= db.prepare(`CREATE TABLE IF NOT EXISTS audience_tasks (
    id TEXT PRIMARY KEY, status TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
    payload TEXT NOT NULL, result TEXT NOT NULL DEFAULT '[]', error TEXT, encrypted_token TEXT NOT NULL
  )`).run().then(async () => {
    await db.prepare("CREATE INDEX IF NOT EXISTS audience_tasks_queue_idx ON audience_tasks(status, created_at ASC)").run();
  });
  await initialized;
}
async function pruneExpiredTasks(db?:D1Database) {
  const now=Date.now(); if(now-lastPrunedAt<60*60*1000)return; lastPrunedAt=now;
  const cutoff=now-SERVER_RECORD_RETENTION_MS;
  if(db) await db.prepare("DELETE FROM audience_tasks WHERE created_at < ?").bind(cutoff).run();
  else for(const [id,task] of memory) if(task.createdAt<cutoff) memory.delete(id);
}
function fromRow(row:Row):StoredAudienceTask { return { ...(JSON.parse(row.payload) as AudienceTask), status:row.status, createdAt:row.created_at, updatedAt:row.updated_at, results:JSON.parse(row.result || "[]") as AudienceResult[], ...(row.error ? { error:row.error } : {}), encryptedToken:row.encrypted_token }; }
function visible(task:StoredAudienceTask):AudienceTask { const copy:Partial<StoredAudienceTask> = {...task}; delete copy.encryptedToken; return copy as AudienceTask; }

export async function listAudienceTasks(since?:number): Promise<AudienceTask[]> {
  const db=database();
  if (!db) { await pruneExpiredTasks(); return [...memory.values()].filter((task)=>!since||task.createdAt>=since).sort((a,b)=>b.createdAt-a.createdAt).map(visible); }
  await ensureTable(db); await pruneExpiredTasks(db);
  const rows=since
    ? await db.prepare("SELECT * FROM audience_tasks WHERE created_at >= ? ORDER BY created_at DESC").bind(since).all<Row>()
    : await db.prepare("SELECT * FROM audience_tasks ORDER BY created_at DESC").all<Row>();
  return rows.results.map(fromRow).map(visible);
}
export async function getAudienceTask(id:string) {
  const db=database(); if (!db) return memory.get(id)||null;
  await ensureTable(db); const row=await db.prepare("SELECT * FROM audience_tasks WHERE id = ?").bind(id).first<Row>(); return row ? fromRow(row) : null;
}
export async function saveAudienceTask(task:StoredAudienceTask) {
  const db=database(); if (!db) { memory.set(task.id,task); return; }
  await ensureTable(db); const {encryptedToken,results,error,...payload}=task;
  await db.prepare(`INSERT INTO audience_tasks (id,status,created_at,updated_at,payload,result,error,encrypted_token) VALUES (?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at,payload=excluded.payload,result=excluded.result,error=excluded.error,encrypted_token=excluded.encrypted_token`)
    .bind(task.id,task.status,task.createdAt,task.updatedAt,JSON.stringify(payload),JSON.stringify(results||[]),error||null,encryptedToken).run();
}
export async function listAudienceHistory() {
  const tasks=await listAudienceTasks();
  return tasks.flatMap((task:AudienceTask)=>task.results||[]).filter((result:AudienceResult)=>result.status==="success" && result.audienceId);
}
