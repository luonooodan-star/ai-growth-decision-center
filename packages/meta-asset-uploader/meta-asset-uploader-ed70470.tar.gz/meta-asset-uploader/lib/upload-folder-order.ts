/** Preserve the parent path to disambiguate equal folder names. */
export function sourceFolderFromParent(relativePath: string) {
  const parts = relativePath.split("/");
  return parts.length > 2 ? parts.slice(0, 2).join("/") : parts[0];
}

/** Finish all queued batches for the current folder before switching folders. */
export function nextFolderTask<T extends { status: string; sourceFolder: string }>(tasks: T[], currentFolder: string): T | undefined {
  const queued = tasks.filter((task) => task.status === "queued");
  return queued.find((task) => task.sourceFolder === currentFolder) || queued[0];
}

export function sortFolderFiles<T extends { relativePath: string }>(files: T[]): T[] {
  return [...files].sort((a, b) => a.relativePath.localeCompare(b.relativePath, "zh-CN", { numeric: true }));
}
