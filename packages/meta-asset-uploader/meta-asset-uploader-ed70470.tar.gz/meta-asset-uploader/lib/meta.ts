import { env } from "cloudflare:workers";

const COOKIE_NAME = "meta_session";
const GRAPH_VERSION_FALLBACK = "v26.0";

type RuntimeEnv = Record<string, string | undefined>;

function runtime(): RuntimeEnv {
  return env as unknown as RuntimeEnv;
}

export function metaConfig() {
  const values = runtime();
  return {
    appId: values.META_APP_ID || "",
    appSecret: values.META_APP_SECRET || "",
    sessionSecret: values.META_SESSION_SECRET || "",
    graphVersion: values.META_GRAPH_VERSION || GRAPH_VERSION_FALLBACK,
  };
}

export function metaConfigured() {
  const config = metaConfig();
  return Boolean(config.appId && config.appSecret && config.sessionSecret);
}

function parseCookies(request: Request) {
  return Object.fromEntries((request.headers.get("cookie") || "").split(";").map((part) => part.trim()).filter(Boolean).map((part) => {
    const index = part.indexOf("=");
    return [part.slice(0, index), decodeURIComponent(part.slice(index + 1))];
  }));
}

function encodeBase64Url(bytes: Uint8Array) {
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function decodeBase64Url(value: string) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  const binary = atob(normalized);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function sessionKey() {
  const secret = metaConfig().sessionSecret;
  if (!secret) throw new Error("META_SESSION_SECRET is not configured");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", digest, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function encryptToken(token: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await sessionKey(), new TextEncoder().encode(token));
  const combined = new Uint8Array(iv.length + encrypted.byteLength);
  combined.set(iv);
  combined.set(new Uint8Array(encrypted), iv.length);
  return encodeBase64Url(combined);
}

export async function decryptToken(value: string) {
  try {
    const combined = decodeBase64Url(value);
    const iv = combined.slice(0, 12);
    const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, await sessionKey(), combined.slice(12));
    return new TextDecoder().decode(decrypted);
  } catch {
    return null;
  }
}

export async function getMetaToken(request: Request) {
  const value = parseCookies(request)[COOKIE_NAME];
  return value ? decryptToken(value) : null;
}

export function sessionCookie(value: string) {
  return `${COOKIE_NAME}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=5184000`;
}

export function clearSessionCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}

export async function graph(path: string, token: string, params: Record<string, string> = {}, init?: RequestInit) {
  const url = new URL(`https://graph.facebook.com/${metaConfig().graphVersion}/${path}`);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
  url.searchParams.set("access_token", token);
  const response = await fetch(url, init);
  const raw = await response.text();
  let payload: Record<string, unknown> = {};
  if (raw) {
    try { payload = JSON.parse(raw) as Record<string, unknown>; }
    catch { throw new Error(`Meta API 返回了无法解析的响应（HTTP ${response.status}）`); }
  }
  if (!response.ok) {
    const graphError = payload.error as { message?: string; error_user_title?: string; error_user_msg?: string; code?: number; error_subcode?: number; fbtrace_id?: string; is_transient?: boolean } | undefined;
    const code = graphError?.code ? `#${graphError.code}${graphError.error_subcode ? `/${graphError.error_subcode}` : ""} ` : "";
    const title = graphError?.error_user_title ? `${graphError.error_user_title}：` : "";
    const trace = graphError?.fbtrace_id ? `（Meta Trace: ${graphError.fbtrace_id}）` : "";
    throw new Error(`${code}${title}${graphError?.error_user_msg || graphError?.message || `Meta API 请求失败（HTTP ${response.status}）`}${trace}`);
  }
  if (!raw) throw new Error(`Meta API 返回空响应（HTTP ${response.status}）`);
  return payload;
}

export async function graphAll(path: string, token: string, fields: string) {
  const rows: Record<string, unknown>[] = [];
  let after = "";
  for (let page = 0; page < 20; page += 1) {
    const payload = await graph(path, token, { fields, limit: "100", ...(after ? { after } : {}) });
    rows.push(...((payload.data as Record<string, unknown>[] | undefined) || []));
    const paging = payload.paging as { next?: string; cursors?: { after?: string } } | undefined;
    after = paging?.cursors?.after || "";
    if (!paging?.next || !after) break;
  }
  return rows;
}

export function requestOrigin(request: Request) {
  const configuredOrigin = runtime().META_OAUTH_ORIGIN?.replace(/\/$/, "");
  if (configuredOrigin) return configuredOrigin;
  const forwarded = request.headers.get("x-forwarded-host");
  const host = forwarded || request.headers.get("host");
  const protocol = request.headers.get("x-forwarded-proto") || "https";
  // Vite's local Workers runtime keeps request.url on localhost even when a
  // LAN device accessed the server by IP. Preserve the browser's Host header
  // so OAuth always returns to the same LAN address.
  return host ? `${protocol}://${host}` : new URL(request.url).origin;
}

export function safeError(error: unknown) {
  return error instanceof Error ? error.message : "未知错误";
}
