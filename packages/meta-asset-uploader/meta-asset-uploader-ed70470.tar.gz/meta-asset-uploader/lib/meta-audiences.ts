import type { AudienceResult, AudienceTask } from "../app/audiences/audience-store";
import { graph, safeError } from "./meta";

async function create(path:string, token:string, fields:Record<string,unknown>) {
  const body=new URLSearchParams();
  Object.entries(fields).forEach(([key,value])=>body.set(key,typeof value==="string"?value:JSON.stringify(value)));
  const payload=await graph(path,token,{}, {method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},body});
  const id=String(payload.id||""); if (!id) throw new Error("Meta 创建受众后未返回 Audience ID"); return id;
}

export async function executeAudienceTask(task:AudienceTask,token:string,onProgress:(task:AudienceTask)=>Promise<void>) {
  task.results=task.results||[];
  for (let index=0;index<task.accountIds.length;index+=1) {
    const accountId=task.accountIds[index];
    if (task.results.some((result)=>result.accountId===accountId && result.status==="success")) continue;
    const accountName=task.accountNames[index]||`act_${accountId}`;
    try {
      let audienceId="";
      if (task.kind==="custom") {
        if (!task.appId || !task.appEvent || !task.retentionDays) throw new Error("自定义受众缺少 Meta App ID、投放事件或保留天数");
        const rule={inclusions:{operator:"or",rules:[{event_sources:[{id:task.appId,type:"app"}],retention_seconds:task.retentionDays*86400,filter:{operator:"and",filters:[{field:"event",operator:"eq",value:task.appEvent}]}}]}};
        audienceId=await create(`act_${accountId}/customaudiences`,token,{
          name:task.name,
          description:task.description,
          subtype:"CUSTOM",
          customer_file_source:"USER_PROVIDED_ONLY",
          prefill:true,
          rule,
        });
      } else {
        const source=task.sourceAudiences?.find((item)=>item.accountId===accountId);
        if (!source?.audienceId || !task.country || !task.ratioPercent) throw new Error("类似受众必须为每个账户选择同账户来源受众，并填写国家和比例");
        audienceId=await create(`act_${accountId}/customaudiences`,token,{name:task.name,subtype:"LOOKALIKE",origin_audience_id:source.audienceId,lookalike_spec:{type:"similarity",country:task.country,ratio:task.ratioPercent/100}});
      }
      task.results.push({accountId,accountName,audienceId,audienceName:task.name,kind:task.kind,status:"success"});
    } catch (error) {
      task.results.push({accountId,accountName,audienceId:"",audienceName:task.name,kind:task.kind,status:"failed",error:safeError(error)});
    }
    task.updatedAt=Date.now(); await onProgress(task);
  }
  const success=task.results.filter((item)=>item.status==="success").length;
  task.status=success===task.accountIds.length?"complete":success?"partial":"failed";
  return task;
}
