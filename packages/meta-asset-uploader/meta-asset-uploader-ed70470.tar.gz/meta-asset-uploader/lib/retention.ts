export const DAY_MS = 24 * 60 * 60 * 1000;
export const CLIENT_RECORD_RETENTION_MS = 7 * DAY_MS;
export const SERVER_RECORD_RETENTION_MS = 90 * DAY_MS;

