import { env } from "cloudflare:workers";
import type { SharedAppConfig } from "./app-config";

type AppConfigRow = {
  id: string;
  name: string;
  meta_app_id: string;
  google_play_url: string;
  apple_app_store_url: string | null;
  created_at: number;
  updated_at: number;
};

const memoryConfigs = new Map<string, SharedAppConfig>();
let initialized: Promise<void> | null = null;

function database() {
  return (env as unknown as { DB?: D1Database }).DB;
}

async function ensureTable(db: D1Database) {
  initialized ||= db.prepare(`CREATE TABLE IF NOT EXISTS shared_app_configs (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL COLLATE NOCASE,
    meta_app_id TEXT NOT NULL,
    google_play_url TEXT NOT NULL,
    apple_app_store_url TEXT,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`).run().then(async () => {
    await db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS shared_app_configs_name_idx ON shared_app_configs(name COLLATE NOCASE)").run();
    await db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS shared_app_configs_meta_id_idx ON shared_app_configs(meta_app_id)").run();
  });
  await initialized;
}

function fromRow(row: AppConfigRow): SharedAppConfig {
  return {
    id: row.id,
    name: row.name,
    metaAppId: row.meta_app_id,
    googlePlayUrl: row.google_play_url,
    ...(row.apple_app_store_url ? { appleAppStoreUrl: row.apple_app_store_url } : {}),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listAppConfigs() {
  const db = database();
  if (!db) return [...memoryConfigs.values()].sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
  await ensureTable(db);
  const rows = await db.prepare("SELECT * FROM shared_app_configs ORDER BY name COLLATE NOCASE ASC").all<AppConfigRow>();
  return rows.results.map(fromRow);
}

export async function saveAppConfig(config: SharedAppConfig) {
  const db = database();
  if (!db) { memoryConfigs.set(config.id, config); return config; }
  await ensureTable(db);
  await db.prepare(`INSERT INTO shared_app_configs
    (id, name, meta_app_id, google_play_url, apple_app_store_url, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET name=excluded.name, meta_app_id=excluded.meta_app_id,
      google_play_url=excluded.google_play_url, apple_app_store_url=excluded.apple_app_store_url,
      updated_at=excluded.updated_at`)
    .bind(config.id, config.name, config.metaAppId, config.googlePlayUrl, config.appleAppStoreUrl || null, config.createdAt, config.updatedAt).run();
  return config;
}

export async function deleteAppConfig(id: string) {
  const db = database();
  if (!db) return memoryConfigs.delete(id);
  await ensureTable(db);
  const result = await db.prepare("DELETE FROM shared_app_configs WHERE id = ?").bind(id).run();
  return Boolean(result.meta.changes);
}

