type Config = Record<string, string | string[]>;

function value(config: Config, key: string, fallback = "") {
  const raw = config[key];
  return Array.isArray(raw) ? raw[0] || fallback : raw || fallback;
}

export function advantageAudienceTargeting(config: Config) {
  const raw = value(config, "advantage_audience", "0");
  if (raw !== "0" && raw !== "1") throw new Error("赋能型受众必须明确选择启用或禁用");
  if (raw === "0") return { targeting_automation: { advantage_audience: 0 } };
  return {
    targeting_automation: { advantage_audience: 1, individual_setting: { age: 1, gender: 1 } },
    age_range: [Number(value(config, "age_min", "18")), Number(value(config, "age_max", "65"))],
  };
}
