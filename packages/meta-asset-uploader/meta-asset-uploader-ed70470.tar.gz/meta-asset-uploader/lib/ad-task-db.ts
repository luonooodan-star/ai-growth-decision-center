import { env } from "cloudflare:workers";
import type { AdPublishTask } from "../app/ad-tasks/task-store";
import { normalizeAdTaskResult } from "./ad-task-result";
import { SERVER_RECORD_RETENTION_MS } from "./retention";

type StoredTask = AdPublishTask & { encryptedToken: string; ownerId: string };
type D1Row = {
  id: string;
  status: AdPublishTask["status"];
  priority: number;
  created_at: number;
  updated_at: number;
  payload: string;
  result: string;
  error: string | null;
  encrypted_token: string;
  owner_id: string;
};

const memoryTasks = new Map<string, StoredTask>();
let initialized: Promise<void> | null = null;
let lastPrunedAt = 0;

function database() {
  return (env as unknown as { DB?: D1Database }).DB;
}

async function ensureTable(db: D1Database) {
  initialized ||= db.prepare(`CREATE TABLE IF NOT EXISTS ad_publish_tasks (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    payload TEXT NOT NULL,
    result TEXT NOT NULL DEFAULT '{}',
    error TEXT,
    encrypted_token TEXT NOT NULL,
    owner_id TEXT NOT NULL DEFAULT ''
  )`).run().then(async () => {
    const columns = await db.prepare("PRAGMA table_info(ad_publish_tasks)").all<{ name: string }>();
    if (!columns.results.some((column) => column.name === "owner_id")) {
      await db.prepare("ALTER TABLE ad_publish_tasks ADD COLUMN owner_id TEXT NOT NULL DEFAULT ''").run();
    }
    await db.prepare("CREATE INDEX IF NOT EXISTS ad_publish_tasks_queue_idx ON ad_publish_tasks(status, priority DESC, created_at ASC)").run();
    await db.prepare("CREATE INDEX IF NOT EXISTS ad_publish_tasks_owner_idx ON ad_publish_tasks(owner_id, created_at DESC)").run();
  });
  await initialized;
}

async function pruneExpiredTasks(db?: D1Database) {
  const now = Date.now();
  if (now - lastPrunedAt < 60 * 60 * 1000) return;
  lastPrunedAt = now;
  const cutoff = now - SERVER_RECORD_RETENTION_MS;
  if (db) await db.prepare("DELETE FROM ad_publish_tasks WHERE created_at < ?").bind(cutoff).run();
  else for (const [id, task] of memoryTasks) if (task.createdAt < cutoff) memoryTasks.delete(id);
}

function publicTask(task: StoredTask): AdPublishTask {
  const visible: Partial<StoredTask> = { ...task };
  delete visible.encryptedToken;
  delete visible.ownerId;
  return visible as AdPublishTask;
}

function fromRow(row: D1Row): StoredTask {
  const payload = JSON.parse(row.payload) as AdPublishTask;
  const storedResult = JSON.parse(row.result || "{}") as AdPublishTask["result"];
  return {
    ...payload,
    status: row.status,
    priority: row.priority,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    result: normalizeAdTaskResult({ materials: payload.materials || [], result: storedResult }),
    ...(row.error ? { error: row.error } : {}),
    encryptedToken: row.encrypted_token,
    ownerId: row.owner_id || "",
  };
}

export async function listStoredTasks(options: { ownerId?: string; since?: number } = {}) {
  const db = database();
  if (!db) {
    await pruneExpiredTasks();
    return [...memoryTasks.values()]
      .filter((task) => (!options.ownerId || task.ownerId === options.ownerId) && (!options.since || task.createdAt >= options.since))
      .map(publicTask).sort((a, b) => b.priority - a.priority || b.createdAt - a.createdAt);
  }
  await ensureTable(db);
  await pruneExpiredTasks(db);
  const clauses: string[] = [];
  const bindings: (string | number)[] = [];
  if (options.ownerId) { clauses.push("owner_id = ?"); bindings.push(options.ownerId); }
  if (options.since) { clauses.push("created_at >= ?"); bindings.push(options.since); }
  const where = clauses.length ? ` WHERE ${clauses.join(" AND ")}` : "";
  const statement = db.prepare(`SELECT * FROM ad_publish_tasks${where} ORDER BY priority DESC, created_at DESC`);
  const rows = bindings.length ? await statement.bind(...bindings).all<D1Row>() : await statement.all<D1Row>();
  return rows.results.map(fromRow).map(publicTask);
}

export async function getStoredTask(id: string, ownerId?: string) {
  const db = database();
  if (!db) {
    const task = memoryTasks.get(id) || null;
    return task && (!ownerId || task.ownerId === ownerId) ? task : null;
  }
  await ensureTable(db);
  const row = ownerId
    ? await db.prepare("SELECT * FROM ad_publish_tasks WHERE id = ? AND owner_id = ?").bind(id, ownerId).first<D1Row>()
    : await db.prepare("SELECT * FROM ad_publish_tasks WHERE id = ?").bind(id).first<D1Row>();
  return row ? fromRow(row) : null;
}

/** Existing rows predate per-user isolation. They remain hidden until their
 * encrypted token proves which Meta user owns them. */
export async function listLegacyStoredTasks() {
  const db = database();
  if (!db) return [...memoryTasks.values()].filter((task) => !task.ownerId);
  await ensureTable(db);
  const rows = await db.prepare("SELECT * FROM ad_publish_tasks WHERE owner_id = '' ORDER BY created_at DESC").all<D1Row>();
  return rows.results.map(fromRow);
}

export async function assignStoredTaskOwner(id: string, ownerId: string) {
  const task = await getStoredTask(id);
  if (!task || task.ownerId) return;
  await saveStoredTask({ ...task, ownerId });
}

export async function saveStoredTask(task: StoredTask) {
  const db = database();
  if (!db) {
    memoryTasks.set(task.id, task);
    return;
  }
  await ensureTable(db);
  const { encryptedToken, result, error, ...payload } = task;
  await db.prepare(`INSERT INTO ad_publish_tasks
    (id, status, priority, created_at, updated_at, payload, result, error, encrypted_token, owner_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET status=excluded.status, priority=excluded.priority,
      updated_at=excluded.updated_at, payload=excluded.payload, result=excluded.result,
      error=excluded.error, encrypted_token=excluded.encrypted_token, owner_id=excluded.owner_id`)
    .bind(task.id, task.status, task.priority, task.createdAt, task.updatedAt, JSON.stringify(payload), JSON.stringify(result || {}), error || null, encryptedToken, task.ownerId)
    .run();
}

export async function updateStoredTask(id: string, update: (task: StoredTask) => StoredTask, ownerId?: string) {
  const task = await getStoredTask(id, ownerId);
  if (!task) return null;
  const next = update(task);
  await saveStoredTask(next);
  return next;
}

export async function nextRunnableTask() {
  const tasks = await listStoredTasks();
  const candidate = tasks.find((task: AdPublishTask) => task.status === "running") || tasks.find((task: AdPublishTask) => task.status === "queued");
  return candidate ? getStoredTask(candidate.id) : null;
}
