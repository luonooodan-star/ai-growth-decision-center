import type { AdPublishTask, AdTaskMaterial } from "../app/ad-tasks/task-store";
import { normalizeAdTaskResult } from "./ad-task-result";
import { advantageAudienceTargeting } from "./advantage-audience";
import { normalizeMetaCta } from "./meta-ad-options";
import { graph } from "./meta";

type Config = Record<string, string | string[]>;
type ExecutionResult = NonNullable<AdPublishTask["result"]>;

function value(config: Config, key: string, fallback = "") {
  const raw = config[key];
  return Array.isArray(raw) ? raw[0] || fallback : raw || fallback;
}

function values(config: Config, key: string) {
  const raw = config[key];
  return (Array.isArray(raw) ? raw : raw ? [raw] : []).map((item) => item.trim()).filter(Boolean);
}

function csv(raw: string) {
  return raw.split(/[，,\s]+/).map((item) => item.trim()).filter(Boolean);
}

function minorUnits(raw: string) {
  const amount = Number(raw);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error(`金额 ${raw || "为空"} 无效`);
  return String(Math.round(amount * 100));
}

async function postEdge(path: string, token: string, fields: Record<string, unknown>) {
  const body = new URLSearchParams();
  Object.entries(fields).forEach(([key, raw]) => {
    if (raw === undefined || raw === null || raw === "") return;
    body.set(key, typeof raw === "string" ? raw : JSON.stringify(raw));
  });
  let payload: Record<string, unknown>;
  try {
    payload = await graph(path, token, {}, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body });
  } catch (error) {
    throw new Error(`${path}：${error instanceof Error ? error.message : "Meta API 请求失败"}`);
  }
  const id = String(payload.id || "");
  if (!id) throw new Error(`Meta 创建 ${path} 后未返回 ID`);
  return id;
}

function campaignName(task: AdPublishTask, accountId: string, serial: number) {
  const config = task.template.config;
  const now = new Date();
  const date = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
  const accountName = task.accountNames[task.accountIds.indexOf(accountId)] || `act_${accountId}`;
  const replacements: Record<string, string> = {
    APP名称: value(config, "app_name"), 日期: date, 三位序号: String(serial).padStart(3, "0"),
    账户ID: accountId, 账户名称: accountName, 配置名称: task.template.name,
    营销目标: value(config, "objective", task.template.objective === "app" ? "OUTCOME_APP_PROMOTION" : "OUTCOME_SALES"),
    平台: value(config, "template_type") === "ios14" ? "ios14" : value(config, "user_os", "all"),
    国家: csv(value(config, "countries")).join("-"),
  };
  let name = value(config, "campaign_name_pattern", "Campaign_{日期}_{三位序号}");
  Object.entries(replacements).forEach(([field, replacement]) => { name = name.replaceAll(`{${field}}`, replacement); });
  const unresolved = name.match(/\{[^{}]+\}/g);
  if (unresolved?.length) throw new Error(`广告系列名称包含不支持的动态字段：${[...new Set(unresolved)].join("、")}`);
  return name;
}

async function resolveLocales(config: Config, token: string) {
  const requested = csv(value(config, "languages"));
  const ids: number[] = [];
  for (const language of requested) {
    if (/^\d+$/.test(language)) {
      ids.push(Number(language));
      continue;
    }
    const payload = await graph("search", token, { type: "adlocale", q: language, limit: "100" });
    const options = (payload.data as { key?: number; name?: string }[] | undefined) || [];
    const normalized = language.toLowerCase();
    const match = options.find((option) => String(option.name || "").toLowerCase().startsWith(normalized)) || options[0];
    if (!match?.key) throw new Error(`找不到语言 ${language} 对应的 Meta Locale ID`);
    ids.push(Number(match.key));
  }
  return [...new Set(ids)];
}

async function targeting(config: Config, token: string, task: AdPublishTask, accountId: string) {
  const countries = csv(value(config, "countries")).map((country) => country.toUpperCase());
  if (!countries.length || countries.some((country) => !/^[A-Z]{2}$/.test(country))) throw new Error("国家必须使用两位国家缩写，例如 US,GB,AU");
  const locales = await resolveLocales(config, token);
  const os = value(config, "user_os", "Android");
  const min = value(config, "os_min", "none");
  const max = value(config, "os_max", "none");
  const devicePlatform = value(config, "device_platforms", "mobile");
  if (!["mobile", "desktop", "connected_tv"].includes(devicePlatform)) throw new Error(`设备范围 ${devicePlatform} 不是 Meta 支持的 device_platforms 值`);
  const userOs = min === "none" && max === "none" ? [os]
    : [max === "none" ? `${os}_ver_${min}_and_above` : min === "none" ? os : `${os}_ver_${min}_to_${max}`];
  const gender = value(config, "genders", "all");
  const included = (task.includedAudiences || []).filter((item) => item.accountId === accountId).map((item) => ({ id: item.audienceId }));
  const excluded = (task.excludedAudiences || []).filter((item) => item.accountId === accountId).map((item) => ({ id: item.audienceId }));
  return {
    geo_locations: { countries, location_types: csv(value(config, "location_types", "home,recent")) },
    age_min: Number(value(config, "age_min", "18")),
    age_max: Number(value(config, "age_max", "65")),
    ...advantageAudienceTargeting(config),
    ...(gender === "all" ? {} : { genders: [Number(gender)] }),
    ...(locales.length ? { locales } : {}),
    device_platforms: [devicePlatform],
    ...(devicePlatform === "mobile" ? { user_os: userOs } : {}),
    ...(value(config, "wireless_carrier", "all") === "Wifi" ? { wireless_carrier: ["Wifi"] } : {}),
    ...(included.length ? { custom_audiences: included } : {}),
    ...(excluded.length ? { excluded_custom_audiences: excluded } : {}),
  };
}

function promotedObject(task: AdPublishTask) {
  const config = task.template.config;
  const event = value(config, "app_event", "PURCHASE");
  const goal = optimizationGoal(task);
  const eventField = promotedEvent(event);
  return task.template.objective === "app"
    ? { application_id: value(config, "app_id"), object_store_url: value(config, "store_url"), ...(goal === "APP_INSTALLS" ? {} : eventField) }
    : { pixel_id: value(config, "data_source_id"), ...eventField };
}

const STANDARD_EVENTS = new Set([
  "ACHIEVEMENT_UNLOCKED", "ADD_PAYMENT_INFO", "ADD_TO_CART", "ADD_TO_WISHLIST", "COMPLETE_REGISTRATION",
  "CONTACT", "CONTENT_VIEW", "CUSTOMIZE_PRODUCT", "DONATE", "FIND_LOCATION", "INITIATED_CHECKOUT", "LEAD",
  "LEVEL_ACHIEVED", "LISTING_INTERACTION", "PURCHASE", "RATE", "SCHEDULE", "SEARCH", "SPENT_CREDITS",
  "START_TRIAL", "SUBMIT_APPLICATION", "SUBSCRIBE", "TUTORIAL_COMPLETION",
]);

function promotedEvent(raw: string) {
  const event = raw.trim();
  return STANDARD_EVENTS.has(event.toUpperCase()) ? { custom_event_type: event.toUpperCase() } : { custom_event_str: event };
}

function optimizationGoal(task: AdPublishTask) {
  const config = task.template.config;
  const goal = task.template.objective === "app" ? value(config, "app_performance_goal", "APP_INSTALLS") : value(config, "sales_performance_goal", "OFFSITE_CONVERSIONS");
  return goal === "APP_EVENTS" ? "APP_INSTALLS_AND_OFFSITE_CONVERSIONS" : goal;
}

function creativeFields(task: AdPublishTask, material: AdTaskMaterial, pageId: string) {
  const config = task.template.config;
  const link = task.template.objective === "app" ? value(config, "store_url") : value(config, "destination_url");
  const configuredBodies = values(config, "creative_bodies");
  const configuredTitles = values(config, "creative_titles");
  const configuredDescriptions = values(config, "creative_descriptions");
  const cta = normalizeMetaCta(value(config, "call_to_action_type"), task.template.objective);
  if (!link) throw new Error("广告创意缺少 link：请在广告配置中填写应用商店链接或销量落地页网址");
  const hasMultipleCreativeAssets = configuredBodies.length > 1 || configuredTitles.length > 1 || configuredDescriptions.length > 1;
  const setting = value(config, "dynamic_creative", "auto");
  const dynamicCreative = setting === "1" || (setting === "auto" && hasMultipleCreativeAssets);
  if (dynamicCreative && !hasMultipleCreativeAssets) throw new Error("动态素材组合已开启，但正文、广告标题和描述都只有一条；请增加至少一组多文案或关闭动态素材组合");
  const bodies = dynamicCreative ? configuredBodies : configuredBodies.slice(0, 1);
  const titles = dynamicCreative ? configuredTitles : configuredTitles.slice(0, 1);
  const descriptions = dynamicCreative ? configuredDescriptions : configuredDescriptions.slice(0, 1);
  // For multi-text creative, Meta expects the media, destination and CTA in
  // object_story_spec. asset_feed_spec carries only the fields that actually
  // have multiple degrees of freedom. Duplicating the single media/link in
  // both objects is rejected as malformed dynamic parameters (#1443048).
  const assetFeedSpec: Record<string, unknown> = {
    optimization_type: "DEGREES_OF_FREEDOM",
    ...(bodies.length ? { bodies: bodies.map((text) => ({ text })) } : {}),
    ...(titles.length ? { titles: titles.map((text) => ({ text })) } : {}),
    ...(descriptions.length ? { descriptions: descriptions.map((text) => ({ text })) } : {}),
  };
  const callToAction = { type: cta, value: { link } };
  const objectStorySpec = material.mediaType === "video"
    ? {
        page_id: pageId,
        video_data: {
          video_id: material.videoId || material.mediaId,
          ...(material.thumbnailUrl ? { image_url: material.thumbnailUrl } : {}),
          call_to_action: callToAction,
          ...(bodies[0] ? { message: bodies[0] } : {}),
          ...(titles[0] ? { title: titles[0] } : {}),
          ...(descriptions[0] ? { link_description: descriptions[0] } : {}),
        },
      }
    : {
        page_id: pageId,
        link_data: {
          image_hash: material.imageHash || material.mediaId,
          link,
          call_to_action: callToAction,
          ...(bodies[0] ? { message: bodies[0] } : {}),
          ...(titles[0] ? { name: titles[0] } : {}),
          ...(descriptions[0] ? { description: descriptions[0] } : {}),
        },
      };
  return {
    name: `${material.adName} Creative`,
    object_story_spec: objectStorySpec,
    ...(dynamicCreative ? { asset_feed_spec: assetFeedSpec } : {}),
  };
}

async function hydrateVideoThumbnail(material: AdTaskMaterial, token: string) {
  if (material.mediaType !== "video" || material.thumbnailUrl) return;
  const videoId = material.videoId || material.mediaId;
  try {
    const video = await graph(videoId, token, { fields: "id,picture,thumbnails{uri,height,width}" });
    const thumbnail = String(video.picture || ((video.thumbnails as { data?: { uri?: string }[] } | undefined)?.data?.[0]?.uri || ""));
    if (thumbnail) material.thumbnailUrl = thumbnail;
  } catch {
    // A freshly uploaded video can still be processing. Meta may create the
    // creative without an explicit thumbnail, so preserve that fallback.
  }
}

function creativeDiagnostic(task: AdPublishTask, material: AdTaskMaterial, pageId: string) {
  const config = task.template.config;
  const multipleTextAssets = values(config, "creative_bodies").length > 1
    || values(config, "creative_titles").length > 1
    || values(config, "creative_descriptions").length > 1;
  const setting = value(config, "dynamic_creative", "auto");
  const dynamic = setting === "1" || (setting === "auto" && multipleTextAssets);
  return `诊断：page_id=${pageId}，Instagram身份=由 Meta 默认使用 Facebook 公共主页，CTA=${normalizeMetaCta(value(config, "call_to_action_type"), task.template.objective)}，${material.mediaType === "video" ? "video_id" : "image_hash"}=${material.mediaId}，缩略图=${material.thumbnailUrl ? "有" : "无"}，动态多文案=${dynamic ? "开启" : "关闭"}，落地链接=${task.template.objective === "app" ? "应用商店" : "网页"}`;
}

function emptyResult(task: AdPublishTask): ExecutionResult {
  return normalizeAdTaskResult(task);
}

function materialKey(material: AdTaskMaterial) {
  return `${material.accountId}:${material.mediaType}:${material.mediaId}`;
}

export function validateTaskCapacity(task: AdPublishTask) {
  if (!Array.isArray(task.accountIds) || !task.accountIds.length) throw new Error("广告任务没有可用的广告账户");
  if (!Array.isArray(task.materials) || !task.materials.length) throw new Error("广告任务没有可用素材");
  if (task.materials.some((material) => !material.accountId || !material.mediaId || !Array.isArray(material.pageCandidateIds) || !material.pageCandidateIds.length)) throw new Error("素材缺少账户、素材 ID 或可用粉丝页，请重新创建广告任务");
  if (![task.campaignCount, task.adSetsPerCampaign, task.adsPerAdSet].every((item) => Number.isInteger(item) && item >= 1 && item <= 100)) throw new Error("广告结构数字必须是 1–100 的整数");
  const config = task.template.config;
  advantageAudienceTargeting(config);
  minorUnits(value(config, "daily_budget"));
  if (task.template.objective === "app" && (!value(config, "app_id") || !value(config, "store_url"))) throw new Error("应用安装配置缺少 Meta App ID 或应用商店链接");
  if (task.template.objective === "sales" && (!value(config, "data_source_id") || !value(config, "destination_url"))) throw new Error("销量配置缺少数据集/像素或落地页网址");
  if (!value(config, "dsa_beneficiary")) throw new Error("广告配置缺少“广告推广受益方”，请修改配置后重新创建广告任务");
  if (value(config, "template_type") === "ios14") {
    if (task.template.objective !== "app" || value(config, "objective") !== "OUTCOME_APP_PROMOTION") throw new Error("iOS 14+ 配置只能使用 OUTCOME_APP_PROMOTION 营销目标");
    if (!/^https:\/\/apps\.apple\.com\//i.test(value(config, "store_url"))) throw new Error("iOS 14+ 配置必须使用完整 Apple App Store 链接");
    if (value(config, "user_os") !== "iOS" || value(config, "os_min") !== "14.0" || value(config, "device_platforms") !== "mobile") throw new Error("iOS 14+ 配置的操作系统或设备字段不完整");
  }
}

export async function executeMetaTask(task: AdPublishTask, token: string, onProgress: (task: AdPublishTask) => Promise<void>) {
  validateTaskCapacity(task);
  const config = task.template.config;
  const result = emptyResult(task);
  task.result = result;
  const budgetMode = value(config, "budget_mode", "CBO");
  const dailyBudget = minorUnits(value(config, "daily_budget"));
  const bidStrategy = value(config, "bid_strategy", "LOWEST_COST_WITHOUT_CAP");
  const bidAmount = value(config, "bid_amount");
  const objective = value(config, "objective", task.template.objective === "app" ? "OUTCOME_APP_PROMOTION" : "OUTCOME_SALES");
  let campaignSerial = result.campaignIds.length;

  for (const accountId of task.accountIds) {
    const target = await targeting(config, token, task, accountId);
    const materials = task.materials.filter((material) => material.accountId === accountId && !result.completedMaterialKeys.includes(materialKey(material)));
    const adsPerCampaign = task.adSetsPerCampaign * task.adsPerAdSet;
    const campaignLimit = Math.max(task.campaignCount, Math.ceil(materials.length / adsPerCampaign));
    let materialIndex = 0;
    for (let campaignIndex = 0; campaignIndex < campaignLimit && materialIndex < materials.length; campaignIndex += 1) {
      if (task.status === "interrupted" || task.status === "cancelled") return task;
      campaignSerial += 1;
      const campaignId = await postEdge(`act_${accountId}/campaigns`, token, {
        name: campaignName(task, accountId, campaignSerial), objective, status: task.creationStatus,
        special_ad_categories: [],
        ...(value(config, "is_skadnetwork_attribution") === "true" ? { is_skadnetwork_attribution: true } : {}),
        ...(budgetMode === "CBO" ? { daily_budget: dailyBudget, bid_strategy: bidStrategy } : {}),
      });
      result.campaignIds.push(campaignId);
      result.logs.push(`act_${accountId} 创建 Campaign ${campaignId}`);
      await onProgress(task);

      for (let adSetIndex = 0; adSetIndex < task.adSetsPerCampaign && materialIndex < materials.length; adSetIndex += 1) {
        const adSetId = await postEdge(`act_${accountId}/adsets`, token, {
          name: task.adSetName, campaign_id: campaignId, status: task.creationStatus,
          billing_event: "IMPRESSIONS", optimization_goal: optimizationGoal(task),
          destination_type: task.template.objective === "app" ? "APP" : "WEBSITE",
          dsa_beneficiary: value(config, "dsa_beneficiary"),
          dsa_payor: value(config, "dsa_payor") || value(config, "dsa_beneficiary"),
          ...(budgetMode === "ABO" ? { daily_budget: dailyBudget, bid_strategy: bidStrategy } : {}),
          ...(bidStrategy !== "LOWEST_COST_WITHOUT_CAP" ? { bid_amount: minorUnits(bidAmount) } : {}),
          targeting: target, promoted_object: promotedObject(task),
        });
        result.adSetIds.push(adSetId);
        result.logs.push(`act_${accountId} 创建 Ad Set ${adSetId}`);
        await onProgress(task);

        for (let adIndex = 0; adIndex < task.adsPerAdSet && materialIndex < materials.length; adIndex += 1) {
          const material = materials[materialIndex++];
          await hydrateVideoThumbnail(material, token);
          await onProgress(task);
          let creativeId = "";
          let lastError: unknown;
          for (const pageId of material.pageCandidateIds) {
            try {
              creativeId = await postEdge(`act_${accountId}/adcreatives`, token, creativeFields(task, material, pageId));
              material.assignedPageId = pageId;
              break;
            } catch (error) {
              lastError = error;
              const reason = error instanceof Error ? error.message : "Meta API 请求失败";
              result.logs.push(`${material.filename} 使用粉丝页 ${pageId} 创建创意失败：${reason}`);
              result.logs.push(creativeDiagnostic(task, material, pageId));
            }
          }
          if (!creativeId) throw lastError instanceof Error ? lastError : new Error(`${material.filename} 的所有粉丝页均创建失败`);
          result.creativeIds.push(creativeId);
          await onProgress(task);
          const adId = await postEdge(`act_${accountId}/ads`, token, { name: material.adName, adset_id: adSetId, creative: { creative_id: creativeId }, status: task.creationStatus });
          result.adIds.push(adId);
          result.completedAds += 1;
          result.completedMaterialKeys.push(materialKey(material));
          result.logs.push(`${material.filename} 创建 Ad ${adId}`);
          await onProgress(task);
        }
      }
    }
  }
  return task;
}
