export type MetaCtaOption = {
  value: string;
  label: string;
  objectives: Array<"app" | "sales">;
};

// Meta does not expose a Graph edge that lists CTA enums. Keep this list on
// the server and version it with the Marketing API. Values come from the
// current Business SDK AdCreative.CallToActionType enum, narrowed to the
// destinations supported by this application.
export const META_CTA_OPTIONS: MetaCtaOption[] = [
  { value: "INSTALL_MOBILE_APP", label: "安装应用", objectives: ["app"] },
  { value: "USE_MOBILE_APP", label: "使用应用", objectives: ["app"] },
  { value: "DOWNLOAD", label: "下载", objectives: ["app", "sales"] },
  { value: "LEARN_MORE", label: "了解更多", objectives: ["app", "sales"] },
  { value: "GET_STARTED", label: "开始使用", objectives: ["app", "sales"] },
  { value: "SHOP_NOW", label: "立即购买", objectives: ["sales"] },
  { value: "BUY_NOW", label: "立即购买", objectives: ["sales"] },
  { value: "ADD_TO_CART", label: "加入购物车", objectives: ["sales"] },
  { value: "ORDER_NOW", label: "立即下单", objectives: ["sales"] },
  { value: "GET_OFFER", label: "领取优惠", objectives: ["sales"] },
  { value: "SIGN_UP", label: "注册", objectives: ["app", "sales"] },
  { value: "CONTACT_US", label: "联系我们", objectives: ["sales"] },
  { value: "BOOK_NOW", label: "立即预订", objectives: ["sales"] },
  { value: "NO_BUTTON", label: "无按钮", objectives: ["app", "sales"] },
];

export function normalizeMetaCta(raw: string, objective: "app" | "sales") {
  const migrated = objective === "app" && raw === "INSTALL_APP" ? "INSTALL_MOBILE_APP" : raw;
  const allowed = META_CTA_OPTIONS.some((option) => option.value === migrated && option.objectives.includes(objective));
  return allowed ? migrated : objective === "app" ? "INSTALL_MOBILE_APP" : "LEARN_MORE";
}
