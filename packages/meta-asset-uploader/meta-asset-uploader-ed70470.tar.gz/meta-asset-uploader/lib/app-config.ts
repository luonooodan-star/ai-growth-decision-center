export type SharedAppConfig = {
  id: string;
  name: string;
  metaAppId: string;
  googlePlayUrl: string;
  appleAppStoreUrl?: string;
  createdAt: number;
  updatedAt: number;
};

