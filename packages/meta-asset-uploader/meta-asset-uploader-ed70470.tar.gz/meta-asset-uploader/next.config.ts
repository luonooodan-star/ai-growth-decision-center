import type { NextConfig } from "next";
import { loadEnv } from "vite";

const localEnv = loadEnv(process.env.NODE_ENV || "development", process.cwd(), "");
const oauthOrigin = localEnv.META_OAUTH_ORIGIN || process.env.META_OAUTH_ORIGIN || "";
const lanHost = (() => {
  try { return oauthOrigin ? new URL(oauthOrigin).hostname : ""; }
  catch { return ""; }
})();

const nextConfig: NextConfig = {
  // Read the LAN host from .env.local so the same codebase can move between
  // computers without committing a machine-specific IP address.
  allowedDevOrigins: lanHost ? [lanHost] : [],
  experimental: {
    serverActions: {
      // Route uploads are multipart requests. Permit the trusted LAN origin
      // and retain the product's 400 MB per-task allowance.
      allowedOrigins: lanHost ? [`${lanHost}:3001`] : [],
      bodySizeLimit: "450mb",
    },
  },
};

export default nextConfig;
