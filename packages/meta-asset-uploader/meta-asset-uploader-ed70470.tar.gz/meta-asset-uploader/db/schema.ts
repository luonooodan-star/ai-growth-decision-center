import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const adPublishTasks = sqliteTable("ad_publish_tasks", {
  id: text("id").primaryKey(),
  status: text("status").notNull(),
  priority: integer("priority").notNull().default(0),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
  payload: text("payload").notNull(),
  result: text("result").notNull().default("{}"),
  error: text("error"),
  encryptedToken: text("encrypted_token").notNull(),
});

export const audienceTasks = sqliteTable("audience_tasks", {
  id: text("id").primaryKey(), status: text("status").notNull(), createdAt: integer("created_at").notNull(), updatedAt: integer("updated_at").notNull(),
  payload: text("payload").notNull(), result: text("result").notNull().default("[]"), error: text("error"), encryptedToken: text("encrypted_token").notNull(),
});
