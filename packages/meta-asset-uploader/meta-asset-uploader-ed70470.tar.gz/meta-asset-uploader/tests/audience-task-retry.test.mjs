import assert from "node:assert/strict";
import test from "node:test";
import { prepareAudienceTaskRetry } from "../lib/audience-task-retry.ts";

test("audience retry preserves successes and removes failed attempts", () => {
  const task = {
    id: "task-1", createdAt: 1, updatedAt: 2, status: "partial", kind: "custom",
    accountIds: ["1", "2"], accountNames: ["one", "two"], name: "60D INS", description: "",
    results: [
      { accountId: "1", accountName: "one", audienceId: "aud-1", audienceName: "60D INS", kind: "custom", status: "success" },
      { accountId: "2", accountName: "two", audienceId: "", audienceName: "60D INS", kind: "custom", status: "failed", error: "temporary" },
    ],
    error: "partial failure",
  };
  const retried = prepareAudienceTaskRetry(task, 99);
  assert.equal(retried.status, "queued");
  assert.equal(retried.updatedAt, 99);
  assert.equal(retried.error, undefined);
  assert.deepEqual(retried.results.map((result) => result.accountId), ["1"]);
});
