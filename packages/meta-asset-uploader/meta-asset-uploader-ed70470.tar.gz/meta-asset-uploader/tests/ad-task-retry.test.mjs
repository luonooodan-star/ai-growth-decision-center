import assert from "node:assert/strict";
import test from "node:test";
import { adTaskProgress, prepareAdTaskRetry } from "../lib/ad-task-progress.ts";

test("ad retry starts a fresh visible attempt without forgetting successful ads", () => {
  const task = {
    id: "task-1",
    status: "failed",
    priority: 1,
    updatedAt: 1,
    accountIds: ["1"],
    adSetsPerCampaign: 1,
    adsPerAdSet: 5,
    materials: [
      { accountId: "1", mediaType: "video", mediaId: "v1" },
      { accountId: "1", mediaType: "video", mediaId: "v2" },
    ],
    result: {
      campaignIds: ["c1"], adSetIds: ["s1"], creativeIds: ["cr1"], adIds: ["a1"],
      completedAds: 1, totalAds: 2, completedMaterialKeys: ["1:video:v1"], logs: [],
    },
  };
  const retried = prepareAdTaskRetry(task, 10);
  assert.equal(retried.result.completedAds, 1);
  assert.deepEqual(retried.result.adIds, ["a1"]);
  assert.deepEqual(adTaskProgress(retried), { campaigns: 1, adSets: 1, ads: 1, total: 3, completed: 0, percent: 0 });
  retried.result.campaignIds.push("c2");
  assert.equal(adTaskProgress(retried).completed, 1);
});
