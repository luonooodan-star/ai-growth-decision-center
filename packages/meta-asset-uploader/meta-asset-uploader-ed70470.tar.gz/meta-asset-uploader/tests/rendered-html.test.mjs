import assert from "node:assert/strict";
import test from "node:test";

async function render(pathname = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}-${pathname}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${pathname}`, { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the Meta Creative Vault navigation", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /Meta Creative Vault/);
  assert.match(html, /素材库/);
  assert.match(html, /广告配置模版/);
  assert.match(html, /粉丝页配置/);
  assert.match(html, /受众生成库/);
  assert.match(html, /广告发布任务/);
});

test("server-renders every primary workflow page", async () => {
  const routes = [
    ["/ad-upload", "广告配置"],
    ["/page-configs", "粉丝页"],
    ["/audiences", "受众"],
    ["/ad-tasks", "广告发布"],
  ];

  for (const [pathname, expectedText] of routes) {
    const response = await render(pathname);
    assert.equal(response.status, 200, `${pathname} should render successfully`);
    assert.match(await response.text(), new RegExp(expectedText));
  }
});
