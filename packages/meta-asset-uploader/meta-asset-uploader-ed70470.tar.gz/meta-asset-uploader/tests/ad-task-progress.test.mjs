import assert from "node:assert/strict";
import test from "node:test";
import { adTaskProgress, plannedAdTaskSteps } from "../lib/ad-task-progress.ts";

function materials(count, accountId = "1") {
  return Array.from({ length: count }, (_, index) => ({ accountId, mediaId: String(index) }));
}

test("1-1-5 with five materials has seven visible progress steps", () => {
  const task = { accountIds: ["1"], materials: materials(5), adSetsPerCampaign: 1, adsPerAdSet: 5 };
  assert.deepEqual(plannedAdTaskSteps(task), { campaigns: 1, adSets: 1, ads: 5, total: 7 });
  assert.deepEqual(adTaskProgress({ ...task, result: { campaignIds: ["c1"], adSetIds: [], completedAds: 0 } }), {
    campaigns: 1, adSets: 1, ads: 5, total: 7, completed: 1, percent: 14,
  });
});

test("1-1-3 with five materials expands to two campaigns and nine steps", () => {
  const task = { accountIds: ["1"], materials: materials(5), adSetsPerCampaign: 1, adsPerAdSet: 3 };
  assert.deepEqual(plannedAdTaskSteps(task), { campaigns: 2, adSets: 2, ads: 5, total: 9 });
});

test("progress totals are calculated independently for multiple accounts", () => {
  const task = { accountIds: ["1", "2"], materials: [...materials(5, "1"), ...materials(2, "2")], adSetsPerCampaign: 1, adsPerAdSet: 5 };
  assert.deepEqual(plannedAdTaskSteps(task), { campaigns: 2, adSets: 2, ads: 7, total: 11 });
});
