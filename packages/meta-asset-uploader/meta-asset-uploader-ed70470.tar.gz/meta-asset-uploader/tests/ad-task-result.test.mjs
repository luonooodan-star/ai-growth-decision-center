import assert from "node:assert/strict";
import test from "node:test";

import { normalizeAdTaskResult } from "../lib/ad-task-result.ts";

test("normalizes a new D1 task result stored as an empty object", () => {
  const result = normalizeAdTaskResult({ materials: [{}, {}, {}], result: {} });

  assert.deepEqual(result, {
    campaignIds: [],
    adSetIds: [],
    creativeIds: [],
    adIds: [],
    completedAds: 0,
    totalAds: 3,
    completedMaterialKeys: [],
    logs: [],
  });
});

test("preserves partial progress while filling missing arrays", () => {
  const result = normalizeAdTaskResult({
    materials: [{}, {}],
    result: { campaignIds: ["campaign-1"], completedAds: 1 },
  });

  assert.deepEqual(result.campaignIds, ["campaign-1"]);
  assert.deepEqual(result.adSetIds, []);
  assert.deepEqual(result.completedMaterialKeys, []);
  assert.equal(result.completedAds, 1);
  assert.equal(result.totalAds, 2);
});
