import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { advantageAudienceTargeting } from "../lib/advantage-audience.ts";

test("audience requests declare the Meta customer file source", async () => {
  const source = await readFile(new URL("../lib/meta-audiences.ts", import.meta.url), "utf8");
  assert.match(source, /customer_file_source:\s*"USER_PROVIDED_ONLY"/);
});

test("ad sets declare a destination type for app and website flows", async () => {
  const source = await readFile(new URL("../lib/meta-ads.ts", import.meta.url), "utf8");
  assert.match(source, /destination_type:\s*task\.template\.objective === "app" \? "APP" : "WEBSITE"/);
  assert.match(source, /dsa_beneficiary:\s*value\(config, "dsa_beneficiary"\)/);
  assert.match(source, /dsa_payor:\s*value\(config, "dsa_payor"\) \|\| value\(config, "dsa_beneficiary"\)/);
  assert.match(source, /video_data:\s*\{/);
  assert.match(source, /video_id:\s*material\.videoId \|\| material\.mediaId/);
  assert.match(source, /link_data:\s*\{/);
  assert.match(source, /image_hash:\s*material\.imageHash \|\| material\.mediaId/);
  assert.match(source, /object_story_spec:\s*objectStorySpec/);
  assert.match(source, /normalizeAdTaskResult\(task\)/);
});

test("ad sets explicitly enable or disable Advantage+ audience", () => {
  assert.deepEqual(advantageAudienceTargeting({ advantage_audience: "0" }), {
    targeting_automation: { advantage_audience: 0 },
  });
  assert.deepEqual(advantageAudienceTargeting({ advantage_audience: "1", age_min: "21", age_max: "55" }), {
    targeting_automation: { advantage_audience: 1, individual_setting: { age: 1, gender: 1 } },
    age_range: [21, 55],
  });
  assert.throws(() => advantageAudienceTargeting({ advantage_audience: "unexpected" }), /必须明确选择/);
});

test("creative freedom is enabled only when a text field has multiple assets", async () => {
  const source = await readFile(new URL("../lib/meta-ads.ts", import.meta.url), "utf8");
  const workspace = await readFile(new URL("../app/ad-upload/workspace.tsx", import.meta.url), "utf8");
  assert.match(source, /configuredBodies\.length > 1 \|\| configuredTitles\.length > 1 \|\| configuredDescriptions\.length > 1/);
  assert.match(source, /optimization_type: "DEGREES_OF_FREEDOM"/);
  assert.match(source, /dynamicCreative \? \{ asset_feed_spec: assetFeedSpec \} : \{\}/);
  assert.doesNotMatch(source, /assetFeedSpec[\s\S]{0,500}link_urls/);
  assert.match(source, /material\.thumbnailUrl \? \{ image_url: material\.thumbnailUrl \}/);
  assert.match(source, /dynamic_creative/);
  assert.match(workspace, /动态素材组合/);
  assert.match(workspace, /name="dynamic_creative"/);
});

test("app creatives migrate legacy CTA and let Meta use the Facebook Page identity", async () => {
  const source = await readFile(new URL("../lib/meta-ads.ts", import.meta.url), "utf8");
  const options = await readFile(new URL("../lib/meta-ad-options.ts", import.meta.url), "utf8");
  assert.match(options, /INSTALL_MOBILE_APP/);
  assert.match(options, /raw === "INSTALL_APP" \? "INSTALL_MOBILE_APP"/);
  assert.doesNotMatch(source, /page_backed_instagram_accounts/);
  assert.doesNotMatch(source, /instagram_user_id/);
  assert.match(source, /Instagram身份=由 Meta 默认使用 Facebook 公共主页/);
});

test("completed ad tasks can be copied into the editable task form", async () => {
  const list = await readFile(new URL("../app/ad-tasks/task-list.tsx", import.meta.url), "utf8");
  const form = await readFile(new URL("../app/ad-tasks/new-task.tsx", import.meta.url), "utf8");
  const route = await readFile(new URL("../app/api/meta/ad-tasks/route.ts", import.meta.url), "utf8");
  assert.match(list, /\/ad-tasks\/new\?copy=\$\{task\.id\}/);
  assert.match(form, /params\.get\("copy"\)/);
  assert.match(form, /setCampaignCount\(source\.campaignCount\)/);
  assert.match(form, /setSelectedAccountIds\(source\.accountIds\)/);
  assert.match(route, /searchParams\.get\("id"\)/);
});

test("ad publishing expands campaigns for excess materials and keeps three workers", async () => {
  const ads = await readFile(new URL("../lib/meta-ads.ts", import.meta.url), "utf8");
  const processor = await readFile(new URL("../app/api/meta/ad-tasks/process/route.ts", import.meta.url), "utf8");
  assert.match(ads, /Math\.ceil\(materials\.length \/ adsPerCampaign\)/);
  assert.match(ads, /campaignIndex < campaignLimit/);
  assert.match(processor, /MAX_PARALLEL_TASKS = 3/);
});
