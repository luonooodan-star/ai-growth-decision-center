import assert from "node:assert/strict";
import test from "node:test";
import { nextFolderTask, sourceFolderFromParent, sortFolderFiles } from "../lib/upload-folder-order.ts";

test("parent selection retains separate folders, nested paths and duplicate basenames", () => {
  assert.equal(sourceFolderFromParent("素材/A/nested/video.mp4"), "素材/A");
  assert.equal(sourceFolderFromParent("素材/B/video.mp4"), "素材/B");
  assert.equal(sourceFolderFromParent("其他/A/video.mp4"), "其他/A");
  assert.equal(sourceFolderFromParent("素材/root.mp4"), "素材");
});

test("all batches of one folder precede other folders, skipping cancelled batches", () => {
  const tasks = [
    { id:1, status:"complete", sourceFolder:"A" },
    { id:2, status:"queued", sourceFolder:"B" },
    { id:3, status:"cancelled", sourceFolder:"A" },
    { id:4, status:"queued", sourceFolder:"A" },
  ];
  assert.equal(nextFolderTask(tasks, "A").id, 4);
  tasks[3].status = "complete";
  assert.equal(nextFolderTask(tasks, "A").id, 2);
  tasks[1].status = "complete";
  assert.equal(nextFolderTask(tasks, "A"), undefined);
});

test("files are sorted naturally without changing names or paths", () => {
  const files = ["A/video10.mp4", "A/video2.mp4", "A/video1.mp4"].map(relativePath => ({relativePath}));
  const sorted = sortFolderFiles(files);
  assert.deepEqual(sorted.map(item => item.relativePath), ["A/video1.mp4", "A/video2.mp4", "A/video10.mp4"]);
  assert.equal(files[0].relativePath, "A/video10.mp4");
});
