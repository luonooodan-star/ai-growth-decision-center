CREATE TABLE `ad_publish_tasks` (
	`id` text PRIMARY KEY NOT NULL,
	`status` text NOT NULL,
	`priority` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`payload` text NOT NULL,
	`result` text DEFAULT '{}' NOT NULL,
	`error` text,
	`encrypted_token` text NOT NULL
);
